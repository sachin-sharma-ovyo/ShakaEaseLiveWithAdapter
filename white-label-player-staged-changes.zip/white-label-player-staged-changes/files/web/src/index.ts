import '@white-label/ui-react/tokens.css';
import '@white-label/ui-react/styles.css';
import './app.css';
import { runDemo } from './demo/runDemo';
import { readDemoOptions } from './demo/options';
import { errorMessage, readPlayerMarkup } from './utils';

const players = {
  shaka: () => import('./demo/players/shaka'),
  bitmovin: () => import('./demo/players/bitmovin'),
};

async function main(): Promise<void> {
  const markup = readPlayerMarkup();
  const page = new URL(window.location.href);
  const player = page.searchParams.get('player');
  if (player !== 'shaka' && player !== 'bitmovin') return;
  const heading = document.querySelector('h1');
  if (heading) heading.textContent = `${player === 'shaka' ? 'Shaka' : 'Bitmovin'} with Ease Live`;
  try {
    const { createDemoPlayer } = await players[player]();
    await runDemo(markup, readDemoOptions(page), createDemoPlayer);
  } catch (error) {
    markup.status.textContent = errorMessage(error, 'Failed to load the stream.');
  }
}

void main();
