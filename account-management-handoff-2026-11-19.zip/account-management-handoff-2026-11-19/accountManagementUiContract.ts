import type { ComponentProps, FormEventHandler } from 'react';
import type { InputProps, PersonalInformation, PersonalInformationFieldProps } from '@white-label/ui-react';

/** Forward-compatible contract for the pending UI-library update.
 * Keep these names aligned with docs/account-management-ui-library-handoff.md.
 * Current PersonalInformation ignores the additions; no library code is patched.
 */
export type AccountFieldProps = PersonalInformationFieldProps &
    Pick<
        InputProps,
        | 'type'
        | 'id'
        | 'name'
        | 'label'
        | 'placeholder'
        | 'autoComplete'
        | 'readOnly'
        | 'disabled'
        | 'min'
        | 'max'
        | 'required'
        | 'endIcon'
        | 'onEndIconTap'
        | 'endIconAccessibilityLabel'
        | 'aria-label'
    >;

type ExistingProps = ComponentProps<typeof PersonalInformation>;
type FieldName = 'firstName' | 'lastName' | 'password' | 'confirmPassword' | 'dateOfBirth' | 'email' | 'phone';

export type AccountInformationProps = Omit<ExistingProps, FieldName | 'gender'> &
    Record<FieldName, AccountFieldProps> & {
        mode: 'view' | 'edit';
        disabled: boolean;
        saving: boolean;
        showActions: boolean;
        showEditAction: boolean;
        editLabel: string;
        onEdit: () => void;
        showPasswordFields: boolean;
        showConfirmPassword: boolean;
        showChangePassword: boolean;
        changePasswordLabel: string;
        onChangePassword: () => void;
        showDeleteAccount: boolean;
        deleteAccountLabel: string;
        onDeleteAccount: () => void;
        onSubmit: FormEventHandler<HTMLFormElement>;
        gender: NonNullable<ExistingProps['gender']> & {
            id: string;
            label: string;
            placeholder: string;
            disabled: boolean;
            readOnly: boolean;
            'aria-label': string;
        };
    };
