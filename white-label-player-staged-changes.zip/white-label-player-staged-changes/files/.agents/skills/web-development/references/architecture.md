# Architecture and contracts

Use this reference to locate code, identify consumers, or change configuration,
public APIs, dependencies, or packaging. Paths written in backticks are relative
to the repository root. Descriptions below are existing source behavior unless
explicitly marked as a limitation or proposal; recheck them when code changes.

## Ownership and dependency direction

```text
Demo: web/index.html + web/src/index.ts
  -> demo/options.ts + mocks/ -> movie/series content and configuration
  -> demo/runDemo.ts -> ContentNavigation + ContentPlaybackSession + overlay
                    -> demo/players/{shaka,bitmovin} -> SDK, bridge, controls, tracks
                    -> ShakaContentAds -> AdController (Shaka only)

Reusable host -> player subpath -> playback bridge -> player wrapper -> SDK
              -> Controls -> bridge commands/subscriptions + settings adapter
              -> easelive subpath -> EaseLiveComponent + WebPlayerPlugin
                                                        -> IWebPlayer

web/src -> packages/shared-sdk/web/{content,plugininterface,easelive}
web/src -> external player SDKs, React, vendored ui-react
shared-sdk/web/easelive -> Ease Live SDK
```

The bridges adapt SDK/media state to host UI; wrappers implement playback and
the `IWebPlayer` overlay surface. Controls do not own player mounting. There is
no global Web store, router, backend, or content-service client in this source.
React hook state belongs to each controls component; bridges/wrappers/ad
controller keep their own state and listener sets.

| Location | Responsibility / useful search starting point |
| --- | --- |
| [web/src/index.ts](../../../../web/src/index.ts), [web/index.html](../../../../web/index.html) | Demo markup and lazy player selection |
| [options.ts](../../../../web/src/demo/options.ts), [runDemo.ts](../../../../web/src/demo/runDemo.ts) | Query parameters, shared page startup, subtitle fallback, URL updates, overlay and teardown |
| [shaka.ts](../../../../web/src/demo/players/shaka.ts), [bitmovin.tsx](../../../../web/src/demo/players/bitmovin.tsx), [DemoPlayer.ts](../../../../web/src/demo/DemoPlayer.ts) | Demo adapter contract and SDK-specific construction, controls and subtitle calls |
| [PlaybackContent.ts](../../../../web/src/content/PlaybackContent.ts), [ContentNavigation.ts](../../../../web/src/content/ContentNavigation.ts), [ContentPlaybackSession.ts](../../../../web/src/player/ContentPlaybackSession.ts) | Movie/series types, episode metadata/callbacks, common startup and restart lifecycle |
| [web/src/player/PlaybackBridge.ts](../../../../web/src/player/PlaybackBridge.ts) | Host, controls, settings, time and configuration types |
| [web/src/player/IWebPlayer.ts](../../../../web/src/player/IWebPlayer.ts) | Player capabilities consumed by the overlay adapter |
| `web/src/shaka/`, `web/src/bitmovin/` | SDK wrappers, bridges, settings, React controls, CSS; Bitmovin caption renderer |
| [web/src/plugin/WebPlayerPlugin.ts](../../../../web/src/plugin/WebPlayerPlugin.ts) | Ease Live event translation, timecode mapping, visibility arbitration |
| [web/src/ads/AdController.ts](../../../../web/src/ads/AdController.ts), [adBreaks.ts](../../../../web/src/ads/adBreaks.ts) | Shaka/IMA requests and pure cue/marker transformations |
| `web/src/mocks/`, `web/src/utils/` | All demo fixtures and VTT assets; DOM, cancellable gesture, media-end and error helpers |
| [ShakaContentAds.ts](../../../../web/src/shaka/ShakaContentAds.ts), [AdvertisingState.ts](../../../../web/src/ads/AdvertisingState.ts) | Shaka ad lifecycle/markers; SDK-independent ad state observed by the overlay |
| [ContentMetadata.ts](../../../../packages/shared-sdk/web/content/ContentMetadata.ts), [plugininterface/index.ts](../../../../packages/shared-sdk/web/plugininterface/index.ts) | Web-consumed service fields and shared typed event contract |
| [EaseLiveComponent.ts](../../../../packages/shared-sdk/web/easelive/EaseLiveComponent.ts) | SDK construction, pre-init error/status listeners, overlay destruction |
| [web/package.json](../../../../web/package.json), [tsup.config.ts](../../../../web/tsup.config.ts), [webpack.config.js](../../../../web/webpack.config.js) | Public package versus demo build boundaries |

Import shared event types through `packages/shared-sdk/web/plugininterface/index.ts`.
Keep Web-specific SDK events and objects out of the cross-platform-shaped
`PlayerPluginEvents` contract. Its source deliberately fixes six events;
extensions need a Web-local boundary or an explicitly scoped contract decision.
No native contract edits are implied by a Web requirement.

## Public interfaces and exports

`IPlaybackBridge` has asynchronous `mount(container, streamUrl, drmLicenseUrl?,
startTime?)` and `destroy()`, synchronous `getTime()` (null before mount/after
destroy), commands `play`, `pause`, percentage `seekTo`, percentage `setVolume`,
and unsubscribe-returning play/time/volume/buffering/ended subscriptions.
`onEnded` is an edge notification, not replayed. Both current bridges expose
`settings`, although it is optional in the interface. Settings provide snapshot
subscriptions and setters for speed, quality, subtitles, audio; `null` means
Auto quality or Off subtitles, and IDs must come from the advertised options.

`IPlaybackTime` contains seconds `currentTime`/`duration`, percentage
`positionPercent`, and `isLive`. Live reports duration 0 and percent 100. Shaka
uses seek-window length and relative percentage; Bitmovin uses VOD duration and
relative SDK time. See [playback](playback-controls.md) for conversion pitfalls.

`IWebPlayer` is a separate interface: promise-returning `play`, relative
`seekBy`, media seconds, date/seek-window/live/end queries, SDK/container access,
scaling, controls visibility, playback-state listeners, readiness and destruction.
Its callback registration methods do **not** return unsubscribers. Do not infer
the playback-bridge subscription semantics from this different interface.

Error reporting is not unified by `IPlaybackBridge`: mount/load rejects, bridge
play commands log rejected playback, and wrappers expose their own `onError`
listeners used by the demos. Hosts have no standard bridge `onError` subscription.
The overlay's fatal handler concerns Ease Live, not content/SDK playback errors.
An error-reporting extension must account for these separate consumers and avoid
silently swallowing failures or tearing down content for an overlay-only error.

`PlayerConfig` is supplied by the host: `licenseKey`, `autoplay` (default true),
and Bitmovin `subtitleBottomPercent` (default 25). Both current wrappers load at
most once: subsequent `load` calls return the first promise, even after failure.
Source replacement/retry therefore needs a deliberate lifecycle design.

| Public subpath | Actual exports / boundary |
| --- | --- |
| `@white-label/player-web/shaka` | `createBridge`, `Controls`/`ShakaControls`, `ShakaPlaybackBridge`, `ShakaSettings`, `mountShakaControls`, controls and common types |
| `@white-label/player-web/bitmovin` | `createBridge`, `Controls`/`BitmovinControls`, controls/common types and UI `Episode` type; bridge/wrapper classes are not exported here |
| `@white-label/player-web/easelive` | `attachEaseLive`, attachment/handler/config/status/common types; demo configs and demo stream URL |
| `@white-label/player-web/shaka.css`, `@white-label/player-web/bitmovin.css` | Emitted local control styles, not all surrounding host layout or UI token styles |
| `@white-label/player-web/package.json` | Package metadata |

There is no root `@white-label/player-web` export. `PlayerModule` describes a
common `createBridge`/`Controls` shape, with `Controls: unknown`; it does not
prove prop compatibility. In particular, Shaka's factory returns
`IPlaybackBridge` while `ShakaControlsProps.bridge` requires the concrete
`ShakaPlaybackBridge`. A generic host's JSX can therefore fail to typecheck.
Test public consumer usage instead of trusting only the internal build.

Some contract comments still say Shaka draws its own controls or lacks settings.
Both entry files actually export React controls and both bridges have settings.
The old `web/src/shaka/playercontrols/PlayerControls.ts` DOM bar is not wired by
the current demo or public player entry. Do not route active UI fixes there.

## Configuration and representative startup

The entry selects `player`; [demo/options.ts](../../../../web/src/demo/options.ts)
parses content, stream, start position, episode and overlay parameters:

- Only explicit `?player=shaka` and `?player=bitmovin` run a player branch. Missing
  or unknown `player` leaves the page at its initial loading state.
- `content=movie` selects the movie fixture; series is the default. The shared
  navigation checks the content type, omits movie episode metadata/panels, and
  supplies no Previous/Next callbacks for movies. Series starts at episode 1;
  `episode=<number>` selects a valid mock episode, otherwise the first is used.
- `autoplayNext` enables automatic episode progression for both players by default;
  `autoplayNext=false` disables it without disabling manual navigation. Genuine
  VOD completion advances only when a next callback exists. The shared session
  waits on optional `finishContent` advertising cleanup before advancing, ignores
  duplicate completions while waiting, and invalidates pending progression on
  manual navigation/disposal. Movies, live and unlisted custom streams do not advance.
- `stream` overrides the fixture URL; positive numeric `start` is passed as VOD
  seconds. A custom stream disables mock navigation and sample captions.
- Previous/Next update the URL and metadata, remove `start`, seek to zero and
  autoplay within the same player. First/last boundaries omit the corresponding
  callback. All mock episodes reuse the same sample video; this is not support
  for replacing arbitrary sources in wrappers that load only once.
- `easelive=ads` selects the ads overlay fixture, otherwise football. This
  chooses graphics, not ad scheduling or the player engine. `brand` is unused.
- [mocks/content.ts](../../../../web/src/mocks/content.ts) contains movie/series
  fixtures, not a service fetch. Its supporting stream, episodes, subtitle tracks
  and VTT assets also live under `mocks/`. Shared subtitle fallback adds English
  and Spanish samples only to the default VOD when no real tracks are available.
- [mocks/advertising.ts](../../../../web/src/mocks/advertising.ts) holds service-shaped
  cues (pre 0, mid 90, post 0/end), sample tags and timeout. Pre/mid use single
  skippable VAST tags; changing `easelive` does not enable ads on Bitmovin.
- [easeLiveConfig.ts](../../../../web/src/mocks/easeLiveConfig.ts) contains demo
  programs; football has a fixed `startTimeCode`, ads does not. The demo and
  attachment use `Date.now()` when it is absent. These are demo time anchors,
  not proof of production stream synchronization.
- `web/.env.example` documents the webpack demo's `BITMOVIN_KEY`. Webpack reads
  an optional local `web/.env`, then the
  environment, and inlines it into the demo. The library does not read
  environment variables; hosts pass configuration.

Both adapters use `runDemo` and `ContentPlaybackSession`. Shaka creates its
wrapper/controls first, derives ads/markers, waits for an accepted gesture and
prerolls, then loads content. Bitmovin checks its key, replaces the HTML video
with its SDK host and loads without that ad gate. In both cases the overlay is
initialized after loading starts and waits on that same promise. SDK-specific
track APIs stay in adapters; subtitle policy and content navigation are shared.
Shaka restarts rearm ad cues/markers and await a fresh preroll before autoplay.
Missing IMA still lets content proceed. Cached `pagehide` preserves the session;
non-cached navigation disposes it. See [lifecycle](lifecycle.md).

## Dependencies, builds, and distribution

Root [package.json](../../../../package.json) delegates to `web`; the directories
use separate installs/lockfiles rather than npm workspaces. Root `install:deps`
installs shared-sdk Web then Web. Do not install during a documentation-only task.

The lockfile snapshot has Shaka 4.16.51, Bitmovin 8.279.0, Ease Live 1.22.0,
React/React DOM 18.3.1, TypeScript 5.9.3, tsup 8.5.1. These are observations,
not upgrade targets. The manifests use ranges for many packages; inspect
lockfiles **and** installed package metadata for a task's actual versions.

ui-react is a development dependency from
`vendor/white-label-ui/react/white-label-ui-react-0.1.1-f6f0399.tgz`; React,
React DOM and ui-react are optional peers in the package manifest. Current entry
modules nevertheless import controls, so a consumer of those entries needs the
peers resolved. Their styles require UI `tokens.css` and `styles.css` as well as
the chosen player CSS. Inspect installed/vendored UI declarations for available
props; do not edit dependency files to reconcile them.

tsup builds three entries into ignored `web/dist/`, ESM `.mjs`, CommonJS `.js`,
declarations and source maps, plus entry CSS. Dependencies/peers remain external
except Ease Live (`noExternal`), resolved from `packages/shared-sdk/web/` and
bundled for the overlay entry. Shared SDK exports raw TypeScript source via its
own package metadata; local Web imports use relative source paths. Webpack builds
the HTML/demo bundle into ignored `web/dist-demo/`; it is a separate delivery.
Both output directories are generated and ignored.
`web/tsconfig.json` extends `tsconfig.base.json` (strict, bundler resolution).
Its `../shared/**/*.ts` include is not `packages/shared-sdk/web`; imported shared
TS files are checked transitively, but the unimported example is not included by
that glob. Do not repeat its comment claiming it is checked with the app.

[scripts/pack-web.sh](../../../../scripts/pack-web.sh) refuses a dirty `web/` or
`packages/shared-sdk/web/` (including documentation), builds and packs the library
to `build/web-pack/` by default with version/SHA in the tarball name. It may install
dependencies when absent. Do not clear someone else's work to satisfy that gate.
See [consumer checks](verification.md#package-consumer-checks).

[scripts/sync-white-label-ui.sh](../../../../scripts/sync-white-label-ui.sh) also
deletes/copies native vendor trees and updates shared provenance. Do not execute
it for Web-only work. A needed React dependency refresh should be scoped to its
React artifact, metadata and lockfile under the task's authorization.
