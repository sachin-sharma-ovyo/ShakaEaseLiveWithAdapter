/** Content service fields consumed by the web player. Times are content seconds. */
export interface AdvertisingCuePoint {
  customSlotId: string;
  sequence: number;
  timePositionClass: 'PREROLL' | 'MIDROLL' | 'POSTROLL';
  contentEndTimePosition: number;
  adFormat: string;
  timeToNextAdUnit: number;
  contentTimePosition: number;
}

export interface AdvertisingInfo {
  advertisingContentId: string;
  networkID: string;
  cuePointList: AdvertisingCuePoint[];
}

export interface ContentMetadata {
  streamUrl: string;
  /** Unix epoch milliseconds corresponding to media position 0. */
  startTimecode?: number;
  advertisingInfoList: AdvertisingInfo[];
}
