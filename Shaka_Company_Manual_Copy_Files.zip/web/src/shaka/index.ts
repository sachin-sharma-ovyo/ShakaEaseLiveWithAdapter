/** Public Shaka module: same export shape as bitmovin/index.ts. */
import type { IPlaybackBridge, PlayerConfig } from '../player/PlaybackBridge';
import { ShakaControls } from './ShakaControls';
import { ShakaPlaybackBridge } from './ShakaPlaybackBridge';

export function createBridge(config: PlayerConfig = {}): IPlaybackBridge {
  return new ShakaPlaybackBridge(config);
}

export const Controls = ShakaControls;
export { ShakaControls, ShakaPlaybackBridge };
export { ShakaSettings } from './ShakaSettings';
export { mountShakaControls } from './mountShakaControls';
export type { ShakaControlsLabels, ShakaControlsProps } from './ShakaControls';
export type {
  IPlaybackBridge, IPlaybackOption, IPlaybackSettings,
  IPlaybackSettingsState, IPlaybackTime, PlayerConfig,
  PlayerModule, Unsubscribe,
} from '../player/PlaybackBridge';
