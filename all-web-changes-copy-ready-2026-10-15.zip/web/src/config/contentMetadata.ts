/** Mock response from a content service, with no IMA-specific settings. */
export interface AdvertisingInfo {
  advertisingContentId: string;
  networkID: string;
  adBreaks: AdvertisingBreak[];
}

export interface AdvertisingBreak {
  name: string;
  sequence: number;
  position: 'PREROLL' | 'MIDROLL' | 'POSTROLL';
  contentEndTimePosition: number;
  adFormat: 'EMBEDDED' | 'CLEAN';
  timeToNextAdUnit: number;
  contentTimePosition: number;
}

export interface ContentMetadata {
  streamUrl: string;
  advertisingInfoList: AdvertisingInfo[];
}

export const contentMetadata: ContentMetadata = {
  streamUrl: 'https://vz-d1c9ca6b-f40.b-cdn.net/0d6ae227-bc97-4080-ae53-7b8e9a07ba4e/playlist.m3u8',
  advertisingInfoList: [{
    advertisingContentId: '1',
    networkID: '1',
    adBreaks: [
      { name: 'intro', sequence: 1, position: 'PREROLL', contentEndTimePosition: 0, adFormat: 'EMBEDDED', timeToNextAdUnit: 0, contentTimePosition: 0 },
      { name: 'mid-roll-1', sequence: 0, position: 'MIDROLL', contentEndTimePosition: 0, adFormat: 'CLEAN', timeToNextAdUnit: 0, contentTimePosition: 3600 },
      { name: 'end_credits', sequence: 0, position: 'POSTROLL', contentEndTimePosition: 4, adFormat: 'CLEAN', timeToNextAdUnit: 0, contentTimePosition: 7200 },
    ],
  }],
};
