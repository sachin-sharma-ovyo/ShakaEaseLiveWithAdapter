# Transfer the PR formatting fixes

Correct reference: `Downloads/white-label-player 5`.
This archive supersedes the earlier archive compared with folder 4.

## Changes included

- `web/src/index.ts`: restored the reference's two-space indentation.
- `web/src/bitmovin/BitmovinControls.tsx`: restored settings, slider and episode-panel
  ternary indentation and spacing inside empty callback bodies.
- `web/src/demo/bitmovinDemo.tsx`: restored multiline metadata parameters and JSX props.

Two other complete files are included because they were named in the PR comments:
`web/src/shaka/ShakaControls.tsx` already has the correct interface semicolon, and
`web/src/app.css` already has its final newline. Neither required another source edit.

All current behavior from folder 3 is preserved: 30-second seeking, genres, season and
episode labels, Back callbacks, pointer handling and existing device/license configuration.
Bookmarks remain removed. Folder 5 was only read, and source line endings were retained.

## Contents

The `web/` directory contains five complete source files, not partial snippets. Each
relative path maps directly to the same path under your other repository's root.
The archive also contains `formatting-only.patch`, `COMPARISON.md`, `VERIFICATION.json`
and `SHA256SUMS.txt`.

## Option A: apply only the formatting patch

This option preserves the other repository's code and configuration.

1. Extract the ZIP into a temporary folder outside the target repository.
2. Open a terminal in the target repository root. Inspect `git status --short` and
   back up any local work in the affected files.
3. Replace the example extracted path below and check the patch:

```sh
git apply --check /path/to/extracted/formatting-only.patch
```

4. If the check succeeds, apply it:

```sh
git apply /path/to/extracted/formatting-only.patch
```

5. If it fails because the target revision or line endings differ, use Option B's editor
   comparison process. Avoid forcing a patch over different code.

The patch contains only the three files actually edited during this formatting task.
The Shaka semicolon and CSS final newline were already correct locally, so a target that
still has those two defects needs the small manual corrections in Option B.

## Option B: copy the complete files

1. Extract the ZIP into a temporary folder.
2. Compare each extracted file with the same relative path in the target repository:

| Extracted file | Target path |
| --- | --- |
| `web/src/index.ts` | `web/src/index.ts` |
| `web/src/bitmovin/BitmovinControls.tsx` | `web/src/bitmovin/BitmovinControls.tsx` |
| `web/src/demo/bitmovinDemo.tsx` | `web/src/demo/bitmovinDemo.tsx` |
| `web/src/shaka/ShakaControls.tsx` | `web/src/shaka/ShakaControls.tsx` |
| `web/src/app.css` | `web/src/app.css` |

3. If the target has the same functional PR version, replace each matching file or
   copy its complete contents. Preserve the final newline when saving.
4. If it has different functional code or configuration, copy only formatting using the
   editor's comparison view. In particular, keep the target's existing license expression,
   device selection, callbacks, metadata mappings and CSS declarations. Complete-file
   replacement would replace that code too.
5. In `ShakaControlsProps`, the Back callback member should end with a semicolon:

```ts
onBack?: () => void;
```

6. Ensure `app.css` ends with a newline after its final closing brace.
7. If the target has `process.env.BITMOVIN_KEY ;`, remove the stray space before the
   semicolon while retaining the assigned expression and its existing configuration.

Keep the target's matching metadata types, demo metadata, Shaka mount helper and styles;
this archive contains only the five files named in the formatting comments. The older
folder 5 has different device/license configuration, which was deliberately preserved
from the current folder 3 code rather than copied from the reference.

## Check the result in the target repository

```sh
git diff --check
git diff -- web/src/index.ts web/src/bitmovin/BitmovinControls.tsx web/src/demo/bitmovinDemo.tsx web/src/shaka/ShakaControls.tsx web/src/app.css
git diff -w -- web/src/index.ts web/src/bitmovin/BitmovinControls.tsx web/src/demo/bitmovinDemo.tsx web/src/shaka/ShakaControls.tsx web/src/app.css
npm run typecheck
npm run build
npm run build:demo
```

`git diff -w` hides spaces but can still show line-wrapping changes. Inspect the result:
no values, expressions, callback bodies, metadata mapping or CSS declarations should
change during this transfer. Existing functional changes already in your working tree
will also appear in a diff against HEAD. An interface comma-to-semicolon correction
can remain visible even though it has no runtime effect.

Check the five extracted source files' integrity inside the extracted folder:

```sh
shasum -a 256 -c SHA256SUMS.txt
```

## Verification completed in folder 3

- Non-whitespace source text unchanged by this formatting task.
- TypeScript syntax/type structures unchanged.
- Emitted JavaScript identical before and after formatting.
- Typecheck, library build and demo build passed.
- Demo build retains three webpack size/performance warnings.
- Diff whitespace check passed with CRLF line endings respected.
- Existing staged changes preserved; this task did not stage, commit or push anything.

Playback, real ads, DRM, Ease Live programs and physical devices were not rerun for
this whitespace-only change. Runtime code was checked for identical compiler output.
