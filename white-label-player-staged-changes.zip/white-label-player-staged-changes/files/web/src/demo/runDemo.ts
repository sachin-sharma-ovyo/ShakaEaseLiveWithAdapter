import { EaseLiveComponent } from '../../../packages/shared-sdk/web/easelive';
import { createContentNavigation } from '../content/ContentNavigation';
import { ContentPlaybackSession } from '../player/ContentPlaybackSession';
import { createWebPlayerPlugin } from '../plugin/WebPlayerPlugin';
import { errorMessage } from '../utils/error';
import type { PlayerMarkup } from '../utils/dom';
import type { DemoPlayerFactory } from './DemoPlayer';
import type { DemoOptions } from './options';

/** Shared page orchestration; adding a player requires only a DemoPlayer adapter. */
export async function runDemo(
  markup: PlayerMarkup,
  options: DemoOptions,
  createPlayer: DemoPlayerFactory,
): Promise<void> {
  const { wrapper, status, view } = markup;
  const { content, streamUrl, startTime, easeLiveConfig } = options;
  const adapter = createPlayer(markup, content);
  const session = new ContentPlaybackSession(
    adapter.bridge,
    () => adapter.getPlayer()?.play() ?? Promise.resolve(),
    adapter.advertising,
    () => { status.textContent = 'Advertisement'; },
  );
  const setStatus = (message: string) => {
    if (session.isActive) status.textContent = message;
  };
  const navigation = createContentNavigation({
    content,
    episodeNumber: options.episodeNumber,
    enabled: options.hasEpisodePlaylist,
    canNavigate: () => session.canNavigate,
    onNavigate(state) {
      const url = new URL(window.location.href);
      url.searchParams.set('episode', String(state.episodeNumber));
      url.searchParams.delete('start');
      window.history.replaceState(window.history.state, '', url);
      adapter.updateControls(state);
      void session.restart()
        .then((completed) => { if (completed) setStatus('Player ready'); })
        .catch((error: unknown) => setStatus(errorMessage(error, 'Could not start the episode.')));
    },
  });
  adapter.updateControls(navigation.getState());

  const unsubscribeEnded = adapter.bridge.onEnded(() => {
    if (!session.isActive || adapter.getPlayer()?.isLive()) return;
    setStatus('Playback ended');
    void session.onContentEnded(options.autoplayNext
      ? () => navigation.getState().onNext?.() : undefined)
      .catch((error: unknown) => setStatus(errorMessage(error, 'Could not finish the episode.')));
  });
  let overlay: EaseLiveComponent | null = null;
  window.addEventListener('pagehide', function onPageHide(event) {
    // Cached documents resume this session on Back/Forward without rerunning main().
    if (event.persisted) return;
    window.removeEventListener('pagehide', onPageHide);
    session.dispose();
    unsubscribeEnded();
    void (async () => {
      try { await overlay?.destroy(); }
      finally { await adapter.destroy(); }
    })().catch((error: unknown) => console.warn('[demo] Could not dispose player:', error));
  });

  await session.start({
    startTime,
    gestureTarget: wrapper,
    shouldStart: isPlaybackGesture,
    onWaiting: () => setStatus('Click the video to start'),
    onLoading: () => setStatus('Loading stream...'),
    async load(position) {
      // Start loading before attaching the overlay, which waits on this same load.
      const loadPromise = adapter.load(streamUrl, position);
      const player = adapter.getPlayer();
      if (player) {
        overlay = new EaseLiveComponent(
          view,
          createWebPlayerPlugin(player, adapter.advertising ?? null,
            easeLiveConfig.startTimeCode ?? Date.now()),
          easeLiveConfig,
          {
            onStatus: (next) => setStatus(`Overlay ${next}`),
            onFatal: setStatus,
          },
        );
        overlay.init();
      }
      await loadPromise;
      if (!session.isActive) return;
      // The policy is shared; each adapter only translates its SDK's track API.
      if (options.useMockTracks && player && !player.isLive() && !adapter.hasSubtitles()) {
        await Promise.all((content.subtitleTracks ?? []).map((track) => adapter.addSubtitle(track)
          .catch((error: unknown) => console.warn('[demo] Could not add sample subtitles:', error))));
      }
    },
  });
  setStatus('Player ready');
}

/** Menu browsing does not start prerolls; navigation starts the session explicitly. */
function isPlaybackGesture(event: Event): boolean {
  if (event instanceof KeyboardEvent && event.key !== 'Enter' && event.keyCode !== 13) return true;
  const target = event.target;
  return !(target instanceof Element) || !target.closest('.wlp-controls')
    || !!target.closest('.wl-playback-control__slot--play-pause');
}
