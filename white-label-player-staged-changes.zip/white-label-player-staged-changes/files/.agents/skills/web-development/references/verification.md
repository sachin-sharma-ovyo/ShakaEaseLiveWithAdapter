# Verification and work preservation

Choose checks by what the change can break. Do not install dependencies or add
tooling merely to verify a documentation edit. Bare source paths are relative
to the repository root. All commands below assume that root unless stated.

## Actual available commands

| Command | What it checks / does | What it does not prove |
| --- | --- | --- |
| `npm run typecheck` | Delegates to Web `tsc --noEmit -p tsconfig.json`; strict TS/JSX and transitively imported shared TS | Emitted exports, browser behavior, all unimported shared TS examples |
| `npm run build` | Web tsup library: JS, declarations, maps, CSS for exported entries in `web/dist/` | Demo startup, consumer resolution in another TS/bundler setup, runtime playback |
| `npm run build:demo` | Production webpack/ts-loader HTML demo in `web/dist-demo/` | Package exports or an observed SDK/network/browser session |
| `npm start` | Webpack dev server on port 8080 | A passing automated test; browser scenarios must actually be exercised |
| `npm run install:deps` | Installs shared-sdk Web and Web dependencies using separate directories/lockfiles | A verification check; use only when needed and authorized |
| `npm run pack:web` | Runs `scripts/pack-web.sh`: clean Web-tree gate, possible installs, library build, SHA-named tarball | A harmless dry run; it writes artifacts and may remove a same-named prior artifact |

There are no configured Web `test`, `lint`, or browser automation scripts and no
Web test sources in the inspected tree. Do not invent `npm test`/Playwright
coverage, imply native hooks verify Web, or run Gradle/Xcode for Web checks.
The root manifest's Node engine is >=18.12; actual dependency engine requirements
may be stricter, so inspect the lockfile/tool package on environment failures.

### Observed baseline on 2026-11-03

`npm run typecheck` exited 2: TS2322 at
`web/src/bitmovin/BitmovinControls.tsx:364` and
`web/src/shaka/ShakaControls.tsx:298`; installed UI declarations reject `onBack`
on `PlaybackControlProps`. Installed ui-react metadata says 0.0.0, while the
manifest/lockfile and committed React tarball are 0.1.1; the tarball's declarations
include `onBack`. This is a checkout-specific dependency mismatch, not proof the
committed artifact lacks that API. Dependencies and source were not repaired in
the documentation task. Re-run after environment/source changes; do not treat
this snapshot as a permanent expected failure or bypass type errors with casts.

Library/demo builds and browser playback were not run in this documentation
task. SDK-source inspection of restoration is static evidence, not observation
of IMA, ad blockers, network timing, content licensing or Ease Live programs.

## Select checks proportional to risk

- **Documentation only:** validate skill YAML/name/description; resolve local
  Markdown links and anchors; confirm source paths, symbols, commands and
  behavior claims. Check scope and contradictions. No product rebuild required.
- **Local visual/text edit:** inspect the relevant UI state/viewport and CSS
  containment. Typecheck when JSX/props/TS changed. Add a build only for affected
  asset/build delivery. No new test framework for a spacing or label edit.
- **Behavioral change:** typecheck plus a focused state/event regression test
  when it can prove the fix; exercise the affected demo or host browser path.
- **Lifecycle, ad, overlay or settings change:** add relevant pending/failure/
  teardown cases below; a happy-path SDK stub is insufficient.
- **Public API/dependency/build change:** library build and package-consumer
  checks; demo build if its wiring changed; browser scenarios for promised
  capabilities. A large feature may need all categories, not every scenario.

After required checks pass, repeat or broaden them only for new edits, failures
or unresolved risks. Report each check's scope and exact failure; distinguish
unavailable prerequisites from code failures. A static or simulated result
cannot be described as successful browser playback.

## Focused state and lifecycle tests

There is no repository Web runner today. For a change needing regression tests,
use existing authorized tooling if available or a small isolated harness with
controlled SDK/event/media stand-ins. If durable tooling is needed, make it an
explicit part of the task rather than silently adding dependencies. Test public
state transitions and ownership invariants, not source strings or private code
shape. Label mocked tests as simulations and retain their limitations.

Choose cases relevant to the edit:

| Area | Meaningful cases / assertions |
| --- | --- |
| Bridge state | Subscribe before/after mount; current snapshot and ended edge; unsubscribe; live/unknown duration; nonzero seek-window start; percent/seconds and mute conversions |
| Settings/captions | Before source load, changing track availability, invalid/stale IDs, Auto/Off, audio-label dedupe, live speed availability, cue enter/exit/disable/unload, video replacement |
| Ease Live | No ready before load; load rejection; integer ms conversion/precedence; first seek ignored; subthreshold seeks; SDK-only listeners don't echo; visibility+scale+ad arbitration |
| Ads | Forward seek over multiple cues, backward seek, positive/end post offsets, serialized requests, missing SDK, init throw, timeout, late loaded/start/stop/error, duplicate complete/skip, marker retention/removal |
| Ownership | Destroy while loading or awaiting gesture, double/concurrent destroy, rejected destroy, stale ready/SDK callbacks, overlay-only destroy/re-attach, repeated mounts/StrictMode-like effects; no surviving listeners/timers/observers/DOM |

Use controlled clocks/promises to prove the specific race. Stubbed IMA events
cannot establish real media restoration or browser user-gesture acceptance.

## Package-consumer checks

Read `web/package.json` and `web/tsup.config.ts` together. For affected public
entries, verify ESM/CJS entry targets, declaration paths and `typesVersions`,
CSS exports, included files, external SDK/peer resolution and bundled Ease Live.
An internal source import is not a public package check.

After an authorized library build, `npm pack ./web --dry-run --json --ignore-scripts`
can inspect the package file list; it does not build missing output. For a
consumer test, pack to a disposable directory and use the package by its public
subpaths in an isolated fixture, or exercise an available real host. Keep any
installs/cache/output out of the user's tracked source and obey environment
permissions. Do not install or alter the user's host project without scope.

Check applicable module-resolution modes, including a CommonJS TypeScript
consumer when affected (the package's `typesVersions` supports that use case).
Compile realistic JSX: Shaka's `createBridge(): IPlaybackBridge` and concrete
`ShakaControlsProps.bridge` can expose a consumer type mismatch that an internal
build misses. Check controls peers and all three CSS imports, package-based
loading, and no runtime dependency on a sibling repository for bundled shared
code. Public overlay attachment requires `getPlayer`, despite that method not
being part of `IPlaybackBridge`.

The SHA-naming helper refuses any dirty Web/shared-sdk Web tree, including
`web/AGENTS.md`. Do not stage, commit or stash someone else's work to make it run.
Use an isolated source copy and plain build/pack for investigation when suitable,
and describe it as a test artifact, not a clean-SHA release package.

## Browser scenarios

Use explicit demo URLs such as `http://localhost:8080/?player=shaka` or
`http://localhost:8080/?player=bitmovin`. There is no working default player
branch currently. URL-encode a `stream` override and use `start` only for VOD.
Bitmovin needs a configured key valid for the host; IMA and Ease Live require
external network/programs. Do not claim those prerequisites were satisfied
unless exercised.

Check only scenarios relevant to changed behavior:

- Play/pause/rejection, VOD resume/seek/30s steps/restart/end; live detection,
  window/edge behavior and disabled public slider.
- Series defaults to episode 1, explicit/invalid episode queries, automatic
  progression enabled/disabled on both players, final-episode stop, duplicate end
  events, Shaka postroll-before-next-preroll ordering, and teardown during that wait.
- Settings availability/selection, observed video quality versus selected menu,
  audio switching, subtitle Off/text/CC and cue cleanup.
- Keyboard slider Left/Right/Home/End, tab/focus and accessible labels, menus,
  narrow layouts, hit targets, pointer pass-through and overlay stage clicks.
- Fullscreen enter/exit, Escape/external changes, close while pending, rejected
  request and repeated opening without a leftover surface.
- Ease Live ready/status/fatal/warning paths, configured versus manifest time
  anchor, seek requests, hidden/enabled/disabled scenes and scale reset.
- IMA gesture init; pre/timed/end breaks; ad skip/pause controls and keyboard
  ownership; blocked/missing/slow SDK/tag, timeout and late events; content
  position/play intent restoration, overlay/controls and marker state afterward.
- Close during load/ad/overlay init and repeat mount. Look for duplicate SDK
  callbacks, videos, intervals, observers, retained fullscreen or stranded locks.
- Navigate away and return through Back/Forward with `pageshow.persisted=true`;
  repeat the cached cycle, then leave without caching. Cached exits must retain
  the player/controls and final exit must still perform cleanup exactly once.

Record browser/version, URL/config and observed result without exposing keys.
An unavailable live/DRM/image-caption fixture is a remaining gap, not a pass.

## Preserve work and safely shelve experiments

At entry record `git status --short`, relevant staged and unstaged diff, and
untracked paths. Review the final diff against that baseline. Keep user hunks,
staged state, lockfiles and unrelated formatting intact. Use path-limited reads
and edits; do not use blanket `git restore`, `reset --hard`, `clean` or stash.

For an experiment, identify its exact paths/hunks before changing them and keep
a reversible patch/copy outside the tracked tree when needed. Separate useful
documentation from experimental code. Shelve only agent-owned changes, restoring
individual hunks to the **recorded starting state**, not blindly to HEAD. If user
and experiment edits overlap, preserve them and clarify only the ambiguous hunk.
An isolated worktree/copy may help a large experiment, subject to permissions;
it does not authorize commits or manipulation of the user's index.

After shelving, inspect status/diffs and remove stale exports, config, dependency
references, feature claims and tests that describe removed code. Keep accurate
architectural discoveries and documentation improvements. Recheck the remaining
source: a documented capability must still exist, and any speculative option
must remain labeled as proposed. Do not stage/commit/push or publish unless
the user asked for it.
