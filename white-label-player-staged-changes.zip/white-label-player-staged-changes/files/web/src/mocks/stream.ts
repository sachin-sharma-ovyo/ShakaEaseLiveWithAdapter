export const demoStreamUrl: string = 'https://vz-d1c9ca6b-f40.b-cdn.net/0d6ae227-bc97-4080-ae53-7b8e9a07ba4e/playlist.m3u8';
