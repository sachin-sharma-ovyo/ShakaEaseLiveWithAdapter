# White Label Player

Minimal clone of the `white-label-multiplatform` repo's Bitmovin Player + ads
integration — and nothing else. It exists to verify and demo that one
integration (Bitmovin Player SDK + Google IMA/native VAST pre/mid/post-roll
ads + an AdMob banner where the platform supports it) in isolation, across a
phone app, an Android TV app, a native iOS app, and a native tvOS app,
sharing one small Kotlin Multiplatform `:shared` module.

## Scope

**Included:** Bitmovin Player playback (Android + iOS + tvOS SDKs), IMA
(iOS/Android) or native VAST (tvOS) pre/mid/post-roll ad scheduling, an AdMob
banner ad (Android + iOS only — no tvOS SDK exists for it), and just enough
of a KMP `:shared` module (player domain model + repository + view model,
plus an Apple-facing `PlayerHelper` facade) to drive all four app modules.

**Not included** — all of these live in the full `white-label-multiplatform`
repo and were deliberately left out of this clone:
auth, TV guide / EPG, search, favorites, bookmarks/resume, analytics events,
the music mini-player, and moko-resources. (`white-label-ui-compose`
design-system tokens *are* now included — see "Consuming
`white-label-ui-compose`" in
[`.claude/skills/bitmovin-player-ads-integration/SKILL.md`](.claude/skills/bitmovin-player-ads-integration/SKILL.md)
— unlike the rest of this list.)

## Modules

| Module | applicationId / namespace / bundle ID | Description |
|---|---|---|
| `:shared` | `com.accenture.player.shared` | KMP module — Android + iOS + tvOS targets. Player domain model (`VideoContent`, `AdsContent`), `PlayerRepository` / `FetchVideoUrlUseCase`, `PlayerViewModel`, `AdsConfigProvider` (Android: loads the bundled `whitelabelplayer-ads-config.json` asset; Apple: mirrors the same values as a hardcoded `AdsContent`). Apple platforms also get `PlayerHelper`, a Swift-facing facade over the same use case, and a `UIDevice`-based `DeviceInfoProvider` — both live in `appleMain`, shared verbatim by `iosApp` and `tvOSApp`. |
| `:androidApp` | `com.accenture.player.android` | Phone app. Jetpack Compose UI, plain Material3 theme. |
| `:androidTvApp` | `com.accenture.player.androidtv` | Android TV app. Same integration as the phone app, adapted for D-pad/Leanback navigation (adaptive AdMob banner sizing, overscan-safe margins). |
| `iosApp` | `com.accenture.player.ios` | Native SwiftUI iOS app (not a Gradle module — a separate Xcode project). Same integration as the Android apps: Bitmovin iOS SDK + Google IMA ads + AdMob banner, consuming `:shared`'s iOS framework directly. |
| `tvOSApp` | `com.accenture.player.tvos` | Native SwiftUI tvOS app (not a Gradle module — a separate Xcode project). Same Bitmovin SDK + `:shared` pipeline as `iosApp`, but pre/mid/post-roll ads use Bitmovin's own native VAST module (`AdSourceType.bitmovin`) instead of Google IMA, and there's **no AdMob banner** — neither Google IMA nor Google Mobile Ads ship a tvOS SDK. |

Both Android app modules mirror the same internal package layout (`MainActivity`,
`MyApp`/`MyTvApp`, `di/KoinModule.kt`,
`presentation/player/{BitmovinPlayerScreen,AdConfigHelper,PlayerDemoScreen}.kt`,
`presentation/ads/BannerAdView.kt`) — see
[`.claude/skills/bitmovin-player-ads-integration/SKILL.md`](.claude/skills/bitmovin-player-ads-integration/SKILL.md)
for the full file-by-file breakdown and step-by-step instructions for adding
this integration to a new module/platform.

`iosApp/` mirrors the same shape natively: `iOSApp.swift` (entry point),
`PlayerDemoScreen.swift` (demo screen with "Play sample" + a `BannerAdView`),
`presentation/player/{VideoPlayerView,AdConfigHelper}.swift`, and
`presentation/ads/BannerAdView.swift`.

`tvOSApp/` mirrors `iosApp/`'s shape minus the AdMob banner: `tvOSApp.swift`
(entry point), `PlayerDemoScreen.swift` (demo screen with just "Play
sample" — no banner), and `presentation/player/{VideoPlayerView,
AdConfigHelper}.swift` (same ad-scheduling logic as iOS, but `AdSource(...,
ofType: .bitmovin)` instead of `.ima`).

## Getting started

See [CONTRIBUTING.md](./CONTRIBUTING.md) for full dev setup, pre-commit/pre-push hook
behaviour, ktlint config, and hook bypass policy.

## Setup

1. Copy `local.properties.example` → `local.properties` and set `sdk.dir` to
   your Android SDK path.
2. **Required for `androidApp`/`androidTvApp` to sync at all:** set
   `bitbucketUsername`/`bitbucketToken` in your **user-level**
   `~/.gradle/gradle.properties` (or `BITBUCKET_USERNAME`/`BITBUCKET_TOKEN`
   env vars) — needed to resolve the `white-label-ui-compose` Maven
   dependency from Bitbucket Server's raw-file API. See
   [CONTRIBUTING.md](./CONTRIBUTING.md#bitbucket-credentials-white-label-ui-compose-dependency)
   for details. Without this, Gradle sync fails with a 401.
3. *(Optional)* Override `BITMOVIN_PLAYER_LICENSE_KEY`,
   `BITMOVIN_ANALYTICS_LICENSE_KEY`, and/or `ADMOB_APPLICATION_ID` in
   `local.properties` — see the comments in `local.properties.example` for
   details. **Both app modules read the same `local.properties` file**, so a
   custom Bitmovin key must be registered (in the Bitmovin dashboard) for
   *both* `com.accenture.player.android` and `com.accenture.player.androidtv`,
   or supplied per-build via a Gradle `-P` property instead.
4. Without any key overrides, the project builds and runs using working
   fallback keys already baked into each module's `build.gradle.kts`.

**iOS:** `iosApp/` has no `local.properties` equivalent — its Bitmovin/AdMob
keys live directly in `iosApp/iosApp/Info.plist` (`BitmovinPlayerLicenseKey`,
`GADApplicationIdentifier`), same fallback-key caveat applies (see the
license key note below, bundle ID `com.accenture.player.ios`).

**tvOS:** same story, keys live in `tvOSApp/tvOSApp/Info.plist`
(`BitmovinPlayerLicenseKey` only — no `GADApplicationIdentifier`/AdMob key,
since `tvOSApp` has no banner ad), bundle ID `com.accenture.player.tvos`.

> **Bitmovin license keys are validated per `applicationId`.** If playback
> reports **"license request denied,"** the key in use isn't registered for
> the app's package name in the Bitmovin dashboard — check that first before
> assuming it's a code bug.

## Web player library (`web/`)

`web/` is the npm package `@white-label/player-web` (private, never published).
white-label-react installs it from a sibling checkout:
`"@white-label/player-web": "file:../white-label-player/web"`.

Each player is a subpath entry with the same shape (`PlayerModule` in
`web/src/player/PlaybackBridge.ts`): `createBridge(config)` returns an
`IPlaybackBridge` (`mount`/`destroy`/`play`/`pause`/`seekTo`/`setVolume`,
`getTime` and `on*` events, including `onEnded`), and `Controls` is the control
overlay the app renders, or
`undefined` when the player draws its own.

| Entry | Player | `Controls` |
|---|---|---|
| `@white-label/player-web/shaka` | Shaka Player with its built-in controls disabled | `ShakaControls`: ui-react controls driven by the bridge |
| `@white-label/player-web/bitmovin` | Bitmovin Player with its stock UI off (`ui: false`) | `BitmovinControls`: ui-react `PlaybackControl` driven by the bridge |

Config (license key, autoplay) is passed to `createBridge`; the library never
reads environment variables. `typesVersions` is set so TypeScript consumers on
`"module": "commonjs"` (white-label-react) still find the subpath types.

The Ease Live adapter `createWebPlayerPlugin` (`web/src/plugin/`) takes any
`IWebPlayer` (`web/src/player/IWebPlayer.ts`), so every player wrapper can use it.

### Web demo configuration

Run `npm start` from the repository root. Use `?player=shaka` for Shaka or
`?player=bitmovin` for the Bitmovin demo (which needs `BITMOVIN_KEY` in
`web/.env`). Use `?easeLive=football` (the default) or `?easeLive=ads` to choose
an Ease Live demo at runtime. `?stream=<url>`, `?start=<seconds>`, and
`?timecode=<epoch-ms>` override the stream, starting position, and Unix timecode
at media position 0. The old `?brand=` parameter is no longer used.

The demo's two Ease Live configs are in `web/src/config/easeLiveConfig.ts`.
`web/src/config/contentMetadata.ts` holds a mock stream URL and the
stream's optional `startTimecode` (the Unix epoch time at media position 0), plus the
`advertisingInfoList` shape supplied by the content service. The screenshot
sample has a pre-roll at 0 seconds, a mid-roll at 3600, and a post-roll at
7200. Shaka turns those cue points into IMA requests using
`web/src/ads/adBreaks.ts`; sample VAST tags and the request timeout are kept
separately in `web/src/ads/adRequestConfig.ts`. Set a post-roll's
`contentTimePosition` to `0` to play it when content ends. A positive value
plays when the content playhead reaches that second. Use a stream long enough
to reach the sample offsets, or shorten the mock offsets when trying those
timed breaks locally.

### Bitmovin entry

```tsx
import '@white-label/ui-react/tokens.css';
import '@white-label/ui-react/styles.css';
import '@white-label/player-web/bitmovin.css';
import { createBridge, Controls } from '@white-label/player-web/bitmovin';

const bridge = createBridge({ licenseKey });   // Bitmovin needs a key
await bridge.mount(hostElement, streamUrl, drmLicenseUrl, resumeAtSeconds); // last arg optional, VOD
const stopEnded = bridge.onEnded(() => clearBookmark());
// on close, before bridge.destroy(): bridge.getTime()?.currentTime → save the position
// ...
<Controls bridge={bridge} title={title} seriesTitle={series} episodes={episodes}
          device="desktop" labels={{ play: t('Play') /* ... */ }} fullscreenTarget={rootRef} />
```

- `Controls` covers the control bar only: play/pause, ±10s, scrubbing, volume,
  settings, episodes, fullscreen. The app owns the dialog around it (back button,
  focus trap, Escape), stream sessions, i18n (pass `labels`) and device detection.
- Settings lists the speed, quality, subtitle and audio language choices the
  stream actually offers (through the optional `bridge.settings`,
  `IPlaybackSettings`). Rows with no choice are hidden, and so is the button
  when nothing is left.
- **A quality change is not visible straight away, by design.** Bitmovin
  downloads the new quality at once but first plays out its buffer (40 s by
  default) in the old one, the same as with its stock UI. Check
  `getPlaybackVideoData()` or the network requests to confirm a switch. An
  immediate switch (a hidden Bitmovin tweak plus a small backward seek) was
  tried and dropped; the reasons are on `BitmovinSettings.setQuality`.
- Subtitles: Bitmovin's own UI is off, so the bridge passes the active cues to
  a text track on the `<video>` and the **browser** draws them. No player CSS
  is involved; the design system has no subtitle component (on Android and iOS
  the Bitmovin SDK draws subtitles too). `createBridge({ subtitleBottomPercent })`
  sets how far up the text sits, as a percentage of the video height (default
  25, clear of the control bar in a full-screen player). Image subtitles
  aren't shown. This is the cue text only; the subtitle *menu* is ui-react's
  `VideoConfig type="subtitles"`. UX design specs for the cue text have been
  requested; when the UI library gets a component for it, `BitmovinSubtitles`
  should feed that instead of the browser text track.
- The bridge creates its own wrapper inside `hostElement` and removes it on
  `destroy`. Listeners added after `mount` get the current state straight away.
- `react`, `react-dom` and `@white-label/ui-react` are **optional** peer
  dependencies of the package; both control overlays use them. In this repo
  ui-react comes from the vendored tarball (see below).
- **Consuming through `file:`:** npm symlinks the package and bundlers/TypeScript
  follow the real path, so `react`, `react-dom` and `@white-label/ui-react` would
  also resolve from `web/node_modules` (duplicate React, "invalid hook call",
  duplicate `@types/react`). The app must point them at its own copies: webpack
  `resolve.alias`, and tsconfig `paths` for the types.

```bash
npm run install:deps   # once: installs packages/shared-sdk/web and web
npm run build          # library -> web/dist (tsup)
npm start              # Shaka + Ease Live demo page on http://localhost:8080
                       #   add ?player=bitmovin for Bitmovin + BitmovinControls
                       #   ?stream=<url> overrides the mock content stream,
                       #   ?start=<seconds> starts a VOD there (resume)
npm run build:demo     # demo page -> web/dist-demo (webpack)
npm run typecheck
```

After changing the library, run `npm run build` again; the consuming app picks
up `web/dist` through the `file:` link.

The Bitmovin demo needs a license key that allows `localhost`: copy
`web/.env.example` to `web/.env` (gitignored) and set `BITMOVIN_KEY`. Webpack
inlines it into the demo bundle only, so never publish `web/dist-demo` built with
a real key.

## Vendored third-party builds (`vendor/`)

`vendor/white-label-ui/` contains pre-built outputs of the
[`white-label-ui`](https://rit.accenture.com/avs-bitbucket/scm/wla/white-label-ui.git)
design-system repo, committed here so contributors without access to that repo
can still build and run the web player.

| Path | Contents |
|---|---|
| `vendor/white-label-ui/react/white-label-ui-react-0.0.0-<sha>.tgz` | `npm pack` output of `@white-label/ui-react` |
| `vendor/white-label-ui/VERSION` | Source commit SHA, date, and version per platform |

**To re-sync** (requires a `../white-label-ui` checkout on `main` and npm on PATH):

```bash
bash scripts/sync-white-label-ui.sh
```

The script builds, packs, replaces the old tarball, updates `VERSION`, and
prints the follow-up `npm install` command. Commit the result and open a PR.
The filename includes the source SHA so npm's lockfile integrity check stays
consistent across the rename.

## Publishing `:shared` for cross-repo consumption

`:shared` is published as a versioned Maven artifact so other repos (e.g.
`white-label-multiplatform`) can depend on it by a pinned version instead of
copy-pasting the player/ads code. There's no dedicated Artifactory/Nexus
server for this yet, so it's published into a `maven-repo/` folder committed
to *this* git repo and served over HTTPS via Bitbucket Server's raw-file API.

**Publishing a new version (maintainers of this repo):**

1. Bump `version` in `shared/build.gradle.kts`.
2. `./gradlew :shared:publish` — regenerates `maven-repo/com/accenture/player/...`.
3. `git add maven-repo shared/build.gradle.kts && git commit && git push` to `master`.
4. Tag the commit to match the Gradle version: `git tag -a vX.Y.Z -m "shared vX.Y.Z"`
   then `git push origin vX.Y.Z` (e.g. `v1.0.0`). The tag is for traceability
   only — Gradle resolves the artifact from the `maven-repo/` folder path, not
   the tag, so keep the tag and the published `maven-repo/` content in sync on
   the same commit.

This publishes two coordinates (same version each time):
- `com.accenture.player:shared-android:<version>` — the Android AAR directly.
- `com.accenture.player:shared:<version>` — the umbrella KMP publication;
  resolves to `shared-android` automatically via Gradle Module Metadata when
  consumed from another Kotlin Multiplatform project. **Prefer this one** from
  a KMP consumer like `white-label-multiplatform`; use `shared-android`
  directly only from a plain (non-KMP) Android module.

**Consuming from another repo** (e.g. `white-label-multiplatform`), add a
repository and dependency pinned to an exact version — dynamic/`+`/SNAPSHOT
versions won't resolve, since Bitbucket's raw-file API serves individual
files by exact path and doesn't support directory listing:

```kotlin
// settings.gradle.kts or the consuming module's build.gradle.kts
repositories {
    maven {
        url = uri(
            "https://rit.accenture.com/avs-bitbucket/rest/api/1.0/projects/WLA" +
                "/repos/white-label-player/raw/maven-repo",
        )
        credentials {
            username = providers.gradleProperty("bitbucketUsername").orNull
                ?: System.getenv("BITBUCKET_USERNAME")
            password = providers.gradleProperty("bitbucketToken").orNull
                ?: System.getenv("BITBUCKET_TOKEN") // Bitbucket HTTP access token / app password
        }
    }
}
```

```kotlin
// KMP consumer (recommended):
androidMain.dependencies {
    implementation("com.accenture.player:shared:1.0.0")
}

// Plain Android module consumer:
dependencies {
    implementation("com.accenture.player:shared-android:1.0.0")
}
```

Use a Bitbucket **HTTP access token** (Personal settings → HTTP access tokens,
repo-read scope) as the password, not your login password. Never commit the
token — pass it via `~/.gradle/gradle.properties` (untracked) or an
environment variable in CI.

## Publishing iOS/tvOS for cross-repo consumption (Swift Package Manager)

The Apple-side Bitmovin player + ads code (`PlayerHelper`, `AdsConfigProvider`,
`VideoPlayerView`/`AdConfigHelper` Swift wrappers, the tvOS VAST Companion Ad
banner, etc.) can also be pinned by another repo — the same way that repo's
own `iosApp`/`tvOSApp` already pin `white-label-ui`:

```
repositoryURL = "https://rit.accenture.com/avs-bitbucket/scm/wla/white-label-player.git"
requirement   = { kind = exactVersion; version = <tag, e.g. 1.0.0> }
```

Root `Package.swift` wraps a pre-built, committed `Frameworks/
WhiteLabelPlayerShared.xcframework` as a `.binaryTarget` (SwiftPM can't compile
Kotlin/Native source directly). It's a *separate*, distinctly-named framework
from the plain `shared.framework` that `iosApp`/`tvOSApp` embed locally in
this repo — a consumer that already has its own `:shared` module (like
`white-label-multiplatform`) can't link two frameworks both named `shared`
into the same Xcode target, so `shared/build.gradle.kts`'s `XCFramework(...)`
block registers a second, separately-named framework binary
(`WhiteLabelPlayerShared`) per Apple target purely for this purpose — the
existing local `shared.framework` embed is untouched.

**Publishing a new version (maintainers of this repo):**

1. Bump `version` in `shared/build.gradle.kts` (kept in sync with the Maven
   flow above, for traceability — SwiftPM itself only cares about the git tag).
2. `./gradlew :shared:assembleWhiteLabelPlayerSharedReleaseXCFramework` —
   rebuilds `shared/build/XCFrameworks/release/WhiteLabelPlayerShared.xcframework`.
3. Copy it over the committed copy: `rm -rf Frameworks/WhiteLabelPlayerShared.xcframework
   && cp -R shared/build/XCFrameworks/release/WhiteLabelPlayerShared.xcframework Frameworks/`.
4. `git add Frameworks Package.swift shared/build.gradle.kts && git commit && git push`
   to `master`.
5. Tag the commit to match: `git tag -a vX.Y.Z -m "WhiteLabelPlayerShared vX.Y.Z"`
   then `git push origin vX.Y.Z` (e.g. `v1.0.0`). SwiftPM resolves an
   `exactVersion` pin purely from the git tag (unlike the Maven flow, there's
   no separate raw-file API involved) — keep the tag and the committed
   `Frameworks/` content in sync on the same commit.

**Consuming from another repo's Xcode project** (e.g.
`white-label-multiplatform`'s `iosApp.xcodeproj`/`tvOSApp.xcodeproj`): add a
Swift Package dependency the same way `white-label-ui` is added — File → Add
Package Dependencies… → paste the repo URL above → "Exact Version" → the pinned
tag → add the `WhiteLabelPlayer` product to the target(s) that need it. In
Swift: `import WhiteLabelPlayerShared`, then use `PlayerHelper()` exactly as
this repo's own `VideoPlayerView.swift`/`PlayerDemoScreen.swift` do. Since the
consumer's own `:shared` module likely already has identically-named classes
(`PlayerHelper`, `AdsConfigProvider`, etc. in the same
`com.accenture.player.shared.*` package), adopting this dependency means
**replacing**, not merely adding — remove/redirect the consumer's own
overlapping player+ads Swift/Kotlin files rather than keeping both.

## Build & run

```bash
./gradlew :androidApp:assembleDebug     # Phone app
./gradlew :androidTvApp:assembleDebug   # Android TV app
./gradlew :shared:build                 # Shared module only
./gradlew assembleDebug                 # Everything
```

**iOS** (separate Xcode project, not part of the Gradle build):

```bash
open iosApp/iosApp.xcodeproj
# or from the command line:
xcodebuild -project iosApp/iosApp.xcodeproj -scheme iosApp \
  -destination 'generic/platform=iOS Simulator' build
```

The first build resolves three Swift Package Manager dependencies (Bitmovin
`player-ios`, Google IMA, Google Mobile Ads) and runs a "Compile Kotlin
Framework" build phase that shells out to
`./gradlew :shared:embedAndSignAppleFrameworkForXcode` — this requires
`JAVA_HOME` to be resolvable (falls back to `/usr/libexec/java_home` or
Android Studio's bundled JBR if unset) and network access for the first SPM
resolve.

**tvOS** (separate Xcode project, not part of the Gradle build):

```bash
open tvOSApp/tvOSApp.xcodeproj
# or from the command line:
xcodebuild -project tvOSApp/tvOSApp.xcodeproj -scheme tvOSApp \
  -destination 'generic/platform=tvOS Simulator' build
```

Same first-build caveats as `iosApp` above, but only one SPM dependency
resolves (Bitmovin `player-ios`) — no Google IMA/Mobile Ads packages, since
neither ships a tvOS SDK.


## Architecture

```
UI (Compose) → PlayerViewModel → FetchVideoUrlUseCase → PlayerRepository
                                                              │
                                                              ▼
                                                   Bitmovin Player SDK
                                              (+ IMA ads, AdMob banner)
```

- **`BitmovinPlayerScreen.kt`** — the only file that touches the Bitmovin SDK
  directly; builds the player + advertising config and renders `PlayerView`.
- **`AdConfigHelper.kt`** — pure Kotlin pre/mid/post-roll ad scheduling logic,
  identical between the phone and TV app modules.
- **`BannerAdView.kt`** — AdMob banner; sized differently per form factor
  (fixed `AdSize.BANNER` on phone, adaptive orientation-anchored sizing on TV).
- **`whitelabelplayer-ads-config.json`** (`shared/src/androidMain/assets/`) — the
  pre/mid/post-roll VAST tag config, shared by every app module automatically
  via AGP asset merging. Deliberately **not** named `ads-config.json`: the
  sibling `white-label-multiplatform` repo's own `:shared` module bundles an
  asset at that exact path, and since this module is published for that repo
  to add as a *dependency* alongside its own local `:shared`, an identical
  asset path across two different libraries would collide during Android's
  asset merge (silently picked by dependency order, or a hard build failure,
  depending on AGP version). Keep this filename unique if you ever rename it.

## Reference

Full-featured original: sibling `white-label-multiplatform` repo
(`androidApp`, `androidtvapp` modules, plus iOS/tvOS targets) — has
everything this clone intentionally omits (bookmarks, TV guide, search,
analytics, and more).
