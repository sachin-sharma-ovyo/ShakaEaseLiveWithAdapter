# Ease Live

Use for synchronization, overlay control, readiness, layout, event or lifecycle
changes. The implementation is
[WebPlayerPlugin.ts](../../../../web/src/plugin/WebPlayerPlugin.ts), backed by
[IWebPlayer.ts](../../../../web/src/player/IWebPlayer.ts),
[the shared event contract](../../../../packages/shared-sdk/web/plugininterface/PlayerPlugin.ts),
[EaseLiveComponent.ts](../../../../packages/shared-sdk/web/easelive/EaseLiveComponent.ts),
and [the public attachment](../../../../web/src/easelive/index.ts).

## Construction and readiness

The shared component constructs the Ease Live SDK with account, program,
optional project, environment (default `prod`), view container and player plugin.
It registers status/error listeners **before** `init`. The SDK type is re-exported
by `packages/shared-sdk/web/easelive/index.ts`; Web code need not import the SDK
package directly. That layer must not import the Web player implementation.

Start playback loading before initializing the overlay. The plugin waits on
`player.whenReady()` (the same load promise), emits `player.ready` with the SDK
instance/container on success, then starts a 250ms time interval. Rejected load
produces no ready event or timer; the demo/host is responsible for reporting
playback load failure. Readiness means successful stream load, not necessarily
first rendered frame or accepted autoplay.

Reusable host order, illustrated with the public API:

```ts
const loading = bridge.mount(hostElement, streamUrl, drmLicenseUrl, startTime);
const overlay = attachEaseLive(bridge, overlayElement, config, handlers);
const stopVisibility = overlay.onControlsVisibility(applyControlsVisibility);
await loading;
// Host cleanup, including failed-load paths:
stopVisibility();
await overlay.destroy();
await bridge.destroy();
```

This shows order, not a complete error-handling or cancellation implementation.
`attachEaseLive` checks a structural `getPlayer()` method not declared by
`IPlaybackBridge`; both existing bridges provide it synchronously as mount
begins. A new bridge needs that capability, or an intentional API extension, to
work with the current attachment. Attaching before mount throws. Mount failures
still require host cleanup; the attachment does not own the playback bridge.

The public attachment always passes `ads: null`, so it does not arbitrate ad
ownership. The Shaka demo passes `ShakaContentAds`, which forwards controller
state through the SDK-independent `AdvertisingState` interface. Controls visibility
callbacks on the attachment do not replay an initial value: the host should
start with a suitable state and handle subsequent requests. Shaka wrapper
visibility listeners replay immediately, Bitmovin wrapper listeners do not.

## Event direction and payloads

Import shared types through `packages/shared-sdk/web/plugininterface/index.ts`.
The six-event shared map is intentionally bounded. Additional Web SDK events
below are handled locally, outside that map.

| Event | Existing direction / behavior |
| --- | --- |
| `player.ready` | Plugin → overlay after successful load; instance/container are `unknown` in the shared type to avoid a Web SDK dependency. |
| `player.time` | Plugin → overlay at 4Hz, integer epoch milliseconds; SDK-only incoming requests become relative seeks after startup and a 0.75s threshold. |
| `player.state` | Plugin → overlay: `playing`, `paused`, `stopped`, `seeking`, `buffering`. SDK-only incoming `playing`/`paused` drive playback; other requests are ignored. |
| `player.controls` | Player visibility → overlay. The Web adapter also accepts SDK-only incoming visible/hidden requests and applies visibility arbitration. |
| `app.status` | SDK → component/host; `hidden` retains the overlay, `disabled` destroys its instance, `enabled` remains active. SDK manages its view status; this handler does not itself set a DOM hidden flag. |
| `easelive.error` | SDK → component; fatal calls the fatal handler and destroys the overlay, warning leaves it alive. There is no application warning callback/logging in this component. |
| `stage.clicked`, `view.mouseenter` | SDK-only, Web-local: toggle controls or show them when ad/overlay locks permit. |
| `player.videoscale` | SDK-only, Web-local: transform video, reconcile controls, then emit the applied scale back. |

`fromSdkOnly: true` is essential on incoming commands: plugin notifications on
the same event names must not loop back into commands. `toBridge` wraps listener
functions and supports `off`, but the current plugin does not call `off` for its
registrations. There are two distinct bridges here: the host's playback bridge
and the Ease Live SDK event bridge. Do not confuse destroying one with the other.

## Time conversion

Media positions, relative seeks and seek-window bounds are **seconds**. Shared
`PlayerTimePayload` is **Unix epoch milliseconds**, floored before emission.
The property is `EaseLiveConfig.startTimeCode` (capital C), passed into the plugin
as `startTimecode` (lowercase c) representing media position zero.

`readTimecode` follows this precedence:

1. Supplied anchor → `startTimecode + mediaPosition * 1000`. This branch does not
   include seek-window bounds, including for live playback.
2. Otherwise player date → its milliseconds. For live, derive initial/max
   timecodes from media seek-window distances; without a positive window set
   both equal to the current timecode. VOD emits the current timecode only.
3. Otherwise a prior positive timecode → advance it by media-position delta.
   Without an initial anchor/date, it returns null; interpolation does not
   invent an epoch by itself.

Both the demo and public attachment always supply configured `startTimeCode`
or `Date.now()`, so their normal path uses branch 1, overriding manifest date
mapping. Football uses its fixed demo epoch. A caller using the lower-level
plugin without an anchor can reach the date/window branches. Bitmovin live date
uses absolute SDK time; VOD date is relative time measured from Unix epoch.
These choices need revisiting when a real content service defines synchronization.

Incoming time requests are ignored before playback has started or before a
positive emitted timecode; differences under 0.75 seconds are ignored. Larger
differences divide milliseconds by 1000 and call clamped relative `seekBy`.
This avoids an initial overlay sync dropping a freshly buffered segment. It is
not a general absolute-time seek API or a guarantee of precise frame sync.

During ads the plugin suppresses normal time/state updates and incoming transport
commands, reporting buffering while loading and paused while playing ads.
On idle it snaps its interpolation base when no player date exists, emits content
time again and infers stopped versus playing from `hasEnded`. That is not a
snapshot of the user's previous paused state; inspect ad restoration ordering.

## Visibility and scaling

The plugin tracks explicit overlay-hidden controls and scaled-video scenes
separately. Either hides controls. Stage clicks toggle only when neither overlay
lock nor ads forbid it; mouseenter shows controls under the same conditions.
An attempt by another caller to show controls while the overlay lock is active
is corrected back to hidden.

Scale requests carry `scaleX`, `scaleY`, `pivotX`, `pivotY` as normalized values
and `duration` as milliseconds. Wrappers apply `transformOrigin`, a transform
transition with nonnegative finite duration, and the requested scale to the video
surface, not the whole controls/overlay shell. `scaleX < 1 || scaleY < 1` flags
the scene as scaled; returning to 1 clears the transform. Values themselves are
not clamped/validated by the wrapper. Do not introduce arbitrary minimum scales
that break L-Bar/PiP alignment without a product requirement.

During ads, visibility requests are remembered for later reconciliation. Scaling
is still applied immediately and visibility is deferred. On ad completion,
overlay lock state must win over the Shaka wrapper's saved controls visibility.
Keep this arbitration coherent with demo CSS `ad-break` visibility and pointer
events; a hidden overlay and a hidden control bar are different states.

## Known lifecycle limits

`EaseLiveComponent.destroy()` detaches its SDK instance, but the plugin's timer
is tied to **player** destruction. Player callback registrations have no
unsubscribe contract. Destroying/re-attaching overlays while keeping a player
alive can leave timer/callback references to an old overlay. A readiness promise
can also resolve after player destruction and create a timer too late for its
destroy hook. Attachment destruction clears its own host callback set, but does
not unregister its wrapper callback or restore scaling/visibility explicitly.

These are current gaps, not supported overlay-reuse semantics. For affected
tasks, design an explicit plugin disposal/cancellation path and prove it with
pending-load, repeated attachment and teardown cases. Consult
[lifecycle](lifecycle.md) and [verification](verification.md); do not claim the
current destroy order alone solves these races.
