import type {
  AdvertisingInfo,
  AdvertisingCuePoint,
} from '../../../packages/shared-sdk/web/content/ContentMetadata';

export type AdKind = 'pre' | 'mid' | 'post';

/** One IMA request derived from a content cue point. */
export interface AdBreak {
  id: string;
  kind: AdKind;
  offsetSec: number;
  tagUrl: string;
}

export type AdBreakPosition =
  | { kind: 'pre' }
  | { kind: 'mid'; offsetsSec: number[] }
  | { kind: 'post'; offsetSec: number };

export interface AdBreakMarkerSchedule {
  hasPreRoll: boolean;
  midRollOffsetsSec: number[];
  postRollOffsetsSec: number[];
  hasEndPostRoll: boolean;
}

export type AdTagUrls = Record<AdvertisingCuePoint['timePositionClass'], string>;

const KIND_BY_POSITION: Record<AdvertisingCuePoint['timePositionClass'], AdKind> = {
  PREROLL: 'pre',
  MIDROLL: 'mid',
  POSTROLL: 'post',
};

/** Converts service metadata to requests without adding IMA fields to the service model. */
export function createAdBreaks(infoList: AdvertisingInfo[], tagUrls: AdTagUrls): AdBreak[] {
  return infoList.flatMap((info, infoIndex) =>
    info.cuePointList.flatMap((cue, cueIndex): AdBreak[] => {
      const offsetSec = cue.contentTimePosition;
      if (!Number.isFinite(offsetSec) || offsetSec < 0) return [];
      const kind = KIND_BY_POSITION[cue.timePositionClass];
      const tagUrl = tagUrls[cue.timePositionClass];
      if (!kind || !tagUrl) return [];
      return [{
        id: `${info.advertisingContentId}:${info.networkID}:${infoIndex}:${cue.customSlotId}:${cue.sequence}:${cueIndex}`,
        kind,
        offsetSec,
        tagUrl,
      }];
    }),
  );
}

/** Positive post-roll positions are timed; position zero means content ended. */
export function createAdBreakMarkerSchedule(breaks: AdBreak[]): AdBreakMarkerSchedule {
  return {
    hasPreRoll: breaks.some((adBreak) => adBreak.kind === 'pre'),
    midRollOffsetsSec: breaks.filter((adBreak) => adBreak.kind === 'mid')
      .map((adBreak) => adBreak.offsetSec),
    postRollOffsetsSec: breaks.filter((adBreak) => adBreak.kind === 'post' && adBreak.offsetSec > 0)
      .map((adBreak) => adBreak.offsetSec),
    hasEndPostRoll: breaks.some((adBreak) => adBreak.kind === 'post' && adBreak.offsetSec === 0),
  };
}

/** Removes due cues from the pending schedule and returns them in playback order. */
export function takeDueBreaks(
  pending: AdBreak[],
  seconds: number,
): { due: AdBreak[]; remaining: AdBreak[] } {
  if (!Number.isFinite(seconds)) return { due: [], remaining: pending };
  const due: AdBreak[] = [];
  const remaining: AdBreak[] = [];
  for (const adBreak of pending) {
    (adBreak.offsetSec <= seconds ? due : remaining).push(adBreak);
  }
  due.sort((a, b) => a.offsetSec - b.offsetSec);
  return { due, remaining };
}

export function toAdBreakPosition(adBreak: AdBreak): AdBreakPosition {
  if (adBreak.kind === 'mid') return { kind: 'mid', offsetsSec: [adBreak.offsetSec] };
  if (adBreak.kind === 'post') return { kind: 'post', offsetSec: adBreak.offsetSec };
  return { kind: 'pre' };
}

/** Returns the marker state after one completed or skipped IMA break. */
export function removeWatchedMarker(
  schedule: AdBreakMarkerSchedule,
  position: AdBreakPosition,
): AdBreakMarkerSchedule {
  if (position.kind === 'pre') return { ...schedule, hasPreRoll: false };
  if (position.kind === 'mid') {
    return {
      ...schedule,
      midRollOffsetsSec: schedule.midRollOffsetsSec.filter(
        (offset) => !position.offsetsSec.includes(offset),
      ),
    };
  }
  if (position.offsetSec === 0) return { ...schedule, hasEndPostRoll: false };
  return {
    ...schedule,
    postRollOffsetsSec: schedule.postRollOffsetsSec.filter(
      (offset) => offset !== position.offsetSec,
    ),
  };
}
