import type {
  IPlaybackBridge,
  IPlaybackSettings,
  IPlaybackTime,
  PlayerConfig,
  Unsubscribe,
} from '../player/PlaybackBridge';
import {
  removeWatchedMarker,
  type AdBreakMarkerSchedule,
  type AdBreakPosition,
} from '../ads/adBreaks';
import { ShakaPlayer } from './ShakaPlayer';
import { ShakaSettings } from './ShakaSettings';
import { isPrematureContentEnd } from '../utils/media';

type Listener<T> = (value: T) => void;
export type Marker = { kind: 'pre' | 'mid' | 'post'; percent: number };
export type MarkerSchedule = AdBreakMarkerSchedule;

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function listen<T>(set: Set<Listener<T>>, cb: Listener<T>): Unsubscribe {
  set.add(cb);
  return () => { set.delete(cb); };
}

/** Bridges one existing ShakaPlayer/video into the shared React controls API. */
export class ShakaPlaybackBridge implements IPlaybackBridge {
  private player: ShakaPlayer | null = null;
  private video: HTMLVideoElement | null = null;
  private ownPlayer = false;
  private ownedWrapper: HTMLElement | null = null;
  private adActive = false;
  private readonly disposers: Array<() => void> = [];
  private readonly settingsAdapter = new ShakaSettings();
  private readonly playListeners = new Set<Listener<boolean>>();
  private readonly timeListeners = new Set<Listener<IPlaybackTime>>();
  private readonly volumeListeners = new Set<Listener<number>>();
  private readonly bufferingListeners = new Set<Listener<boolean>>();
  private readonly endedListeners = new Set<Listener<void>>();
  private readonly markerListeners = new Set<Listener<Marker[]>>();
  private schedule: MarkerSchedule | null = null;

  constructor(private readonly config: PlayerConfig = {}) {}

  get settings(): IPlaybackSettings { return this.settingsAdapter; }
  getPlayer(): ShakaPlayer | null { return this.player; }

  /** Normal app flow: reuse the already-created player and video. */
  connect(player: ShakaPlayer, video: HTMLVideoElement): void {
    this.disconnect();
    this.player = player;
    this.video = video;
    this.settingsAdapter.attach(player.getInstance(), video);
    const on = (name: string, cb: EventListener) => {
      video.addEventListener(name, cb);
      this.disposers.push(() => video.removeEventListener(name, cb));
    };
    on('play', () => this.emitPlay(true));
    on('playing', () => { this.emitPlay(true); this.emitBuffering(false); });
    on('pause', () => this.emitPlay(false));
    on('waiting', () => this.emitBuffering(true));
    on('stalled', () => this.emitBuffering(true));
    on('canplay', () => this.emitBuffering(false));
    on('seeked', () => { this.emitBuffering(false); this.emitTime(); });
    on('timeupdate', () => this.emitTime());
    on('durationchange', () => { this.emitTime(); this.emitMarkers(); });
    on('volumechange', () => this.emitVolume());
    on('ended', () => {
      if (!this.adActive && !isPrematureContentEnd(video)) {
        this.endedListeners.forEach((cb) => cb());
      }
    });
    this.emitTime();
    this.emitVolume();
    this.emitPlay(!video.paused);
  }

  /** Optional standalone bridge mounting; do not call in app's existing-player path. */
  async mount(
    container: HTMLElement,
    streamUrl: string,
    drmLicenseUrl?: string,
    startTime?: number,
  ): Promise<void> {
    if (this.player) throw new Error('ShakaPlaybackBridge already connected');
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'position:relative;width:100%;height:100%';
    const video = document.createElement('video');
    video.setAttribute('playsinline', '');
    video.autoplay = this.config.autoplay ?? true;
    video.style.cssText = 'width:100%;height:100%';
    wrapper.appendChild(video);
    container.appendChild(wrapper);
    let player: ShakaPlayer;
    try { player = new ShakaPlayer(video); }
    catch (error) { wrapper.remove(); throw error; }
    this.ownPlayer = true;
    this.ownedWrapper = wrapper;
    this.connect(player, video);
    await player.load(streamUrl, drmLicenseUrl, startTime);
  }

  disconnect(): void {
    this.disposers.splice(0).forEach((dispose) => dispose());
    this.settingsAdapter.detach();
    this.player = null;
    this.video = null;
    this.adActive = false;
  }

  async destroy(): Promise<void> {
    const owned = this.ownPlayer ? this.player : null;
    const wrapper = this.ownedWrapper;
    this.disconnect();
    this.ownPlayer = false;
    this.ownedWrapper = null;
    this.playListeners.clear();
    this.timeListeners.clear();
    this.volumeListeners.clear();
    this.bufferingListeners.clear();
    this.endedListeners.clear();
    this.markerListeners.clear();
    if (owned) await owned.destroy();
    wrapper?.remove();
  }

  getTime(): IPlaybackTime | null { return this.readTime(); }
  play(): void { void this.player?.play().catch(console.warn); }
  pause(): void { this.player?.pause(); }

  seekTo(positionPercent: number): void {
    const player = this.player;
    const video = this.video;
    if (!player || !video || this.adActive || player.isLive()) return;
    const range = player.getSeekWindow();
    const size = range.end - range.start;
    if (!Number.isFinite(size) || size <= 0) return;
    video.currentTime = range.start + clamp(positionPercent, 0, 100) / 100 * size;
  }

  setVolume(volumePercent: number): void {
    const video = this.video;
    if (!video) return;
    const volume = clamp(volumePercent, 0, 100) / 100;
    video.volume = volume;
    if (volume > 0) video.muted = false;
  }

  onPlayStateChange(cb: Listener<boolean>): Unsubscribe {
    if (this.video) cb(!this.video.paused);
    return listen(this.playListeners, cb);
  }
  onTimeUpdate(cb: Listener<IPlaybackTime>): Unsubscribe {
    const time = this.readTime();
    if (time) cb(time);
    return listen(this.timeListeners, cb);
  }
  onVolumeChange(cb: Listener<number>): Unsubscribe {
    if (this.video) cb(this.readVolume());
    return listen(this.volumeListeners, cb);
  }
  onBufferingChange(cb: Listener<boolean>): Unsubscribe {
    if (this.video) cb(this.video.readyState < HTMLMediaElement.HAVE_FUTURE_DATA);
    return listen(this.bufferingListeners, cb);
  }
  onEnded(cb: () => void): Unsubscribe {
    this.endedListeners.add(cb);
    return () => { this.endedListeners.delete(cb); };
  }

  /** Controls are hidden while Google IMA owns the shared video surface. */
  setAdActive(active: boolean): void { this.adActive = active; }
  isAdActive(): boolean { return this.adActive; }

  setAdBreakMarkers(schedule: MarkerSchedule): void {
    this.schedule = {
      hasPreRoll: schedule.hasPreRoll,
      midRollOffsetsSec: schedule.midRollOffsetsSec.filter(Number.isFinite),
      postRollOffsetsSec: schedule.postRollOffsetsSec.filter(Number.isFinite),
      hasEndPostRoll: schedule.hasEndPostRoll,
    };
    this.emitMarkers();
  }

  markAdBreakWatched(position: AdBreakPosition): void {
    if (!this.schedule) return;
    this.schedule = removeWatchedMarker(this.schedule, position);
    this.emitMarkers();
  }

  getAdMarkers(): Marker[] {
    const schedule = this.schedule;
    const player = this.player;
    if (!schedule || !player) return [];
    const range = player.getSeekWindow();
    const size = range.end - range.start;
    if (!Number.isFinite(size) || size <= 0) return [];
    const markers: Marker[] = [];
    if (schedule.hasPreRoll) markers.push({ kind: 'pre', percent: 0 });
    for (const offset of schedule.midRollOffsetsSec) {
      if (offset >= range.start && offset <= range.end) {
        markers.push({ kind: 'mid', percent: (offset - range.start) / size * 100 });
      }
    }
    for (const offset of schedule.postRollOffsetsSec) {
      if (offset >= range.start && offset <= range.end) {
        markers.push({ kind: 'post', percent: (offset - range.start) / size * 100 });
      }
    }
    if (schedule.hasEndPostRoll) markers.push({ kind: 'post', percent: 100 });
    return markers;
  }

  onAdMarkersChange(cb: Listener<Marker[]>): Unsubscribe {
    cb(this.getAdMarkers());
    return listen(this.markerListeners, cb);
  }

  private readTime(): IPlaybackTime | null {
    if (!this.player || !this.video) return null;
    const isLive = this.player.isLive();
    const range = this.player.getSeekWindow();
    const duration = isLive ? 0 : Math.max(0, range.end - range.start);
    const currentTime = this.video.currentTime;
    return {
      currentTime,
      duration,
      positionPercent: isLive ? 100 : duration > 0
        ? clamp((currentTime - range.start) / duration * 100, 0, 100) : 0,
      isLive,
    };
  }

  private readVolume(): number {
    return this.video?.muted ? 0 : Math.round((this.video?.volume ?? 0) * 100);
  }
  private emitPlay(value: boolean): void {
    this.playListeners.forEach((cb) => cb(value));
  }
  private emitBuffering(value: boolean): void {
    this.bufferingListeners.forEach((cb) => cb(value));
  }
  private emitTime(): void {
    const state = this.readTime();
    if (state) this.timeListeners.forEach((cb) => cb(state));
    if (this.player?.isLive()) this.emitMarkers();
  }
  private emitVolume(): void {
    const value = this.readVolume();
    this.volumeListeners.forEach((cb) => cb(value));
  }
  private emitMarkers(): void {
    const value = this.getAdMarkers();
    this.markerListeners.forEach((cb) => cb(value));
  }
}
