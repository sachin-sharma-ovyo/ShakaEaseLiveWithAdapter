
import { EaseLiveComponent } from '../../packages/shared-sdk/web/easelive';
import { AdController } from './ads/AdController';
import { createAdBreaks, createAdBreakMarkerSchedule, type AdBreak } from './ads/adBreaks';
import { adRequestConfig } from './ads/adRequestConfig';
import '@white-label/ui-react/tokens.css';
import '@white-label/ui-react/styles.css';
import './app.css';
import { contentMetadata } from './config/contentMetadata';
import {
  adsEaseLiveConfig,
  footballEaseLiveConfig,
} from './config/easeLiveConfig';
import { createWebPlayerPlugin } from './plugin/WebPlayerPlugin';
import { ShakaPlayer } from './shaka/ShakaPlayer';
import { ShakaPlaybackBridge } from './shaka/ShakaPlaybackBridge';
import { mountShakaControls } from './shaka/mountShakaControls';
import {
  errorMessage,
  readPlayerMarkup,
  waitForStartGesture,
} from './utils';

async function main(): Promise<void> {
  const { wrapper, video, status, view, adContainer } = readPlayerMarkup();
  const params = new URLSearchParams(window.location.search);
  const easeLiveConfig = params.get('easelive') === 'ads'
    ? adsEaseLiveConfig
    : footballEaseLiveConfig;
  const streamUrl = params.get('stream') || contentMetadata.streamUrl;
  const startParam = Number(params.get('start'));
  const startTime = startParam > 0 ? startParam : undefined;
  const timecodeParam = Number(params.get('timecode'));
  const startTimecode = Number.isFinite(timecodeParam) && timecodeParam > 0
    ? timecodeParam
    : contentMetadata.startTimecode;

  if (params.get('player') === 'bitmovin') {
    const { runBitmovinDemo } = await import('./demo/bitmovinDemo');
    const heading = document.querySelector('h1');
    if (heading) heading.textContent = 'Bitmovin with Ease Live';
    await runBitmovinDemo({
      wrapper, video, status, view, streamUrl, startTime,
      title: 'Bitmovin with Ease Live', easeLiveConfig,
      startTimecode,
    });
    return;
  }

  if (params.get('player') === 'shaka') {
    // Shaka is the only web ad-supported player.
    const player = new ShakaPlayer(video);
    player.onError((message) => { status.textContent = message; });
    const PlayerUiControls = mountShakaControls({
      wrapper, video, player, title: 'Shaka with Ease Live',
    });
    window.addEventListener('pagehide', () => { void PlayerUiControls.dispose(); }, { once: true });

    const adBreaks = createAdBreaks(contentMetadata.advertisingInfoList, adRequestConfig.tagUrls);
    const ads = wireAds(player, wrapper, view, adBreaks, PlayerUiControls.bridge);
    const easeLive = new EaseLiveComponent(
      view,
      createWebPlayerPlugin(player, ads, startTimecode),
      easeLiveConfig,
      {
        onStatus(next: string) { status.textContent = `Overlay ${next}`; },
        onFatal(message: string) { status.textContent = message; },
      },
    );

    if (!ads) {
      await loadStream(player, easeLive, streamUrl, startTime, status);
      return;
    }

    status.textContent = 'Click the video to start';
    // IMA must be initialized in the user gesture before pre-roll/content load.
    const imaReady = await waitForStartGesture(
      wrapper,
      () => ads.tryInit(adContainer, video),
    );
    if (imaReady) {
      for (const adBreak of adBreaks.filter((item) => item.kind === 'pre')) {
        status.textContent = 'Advertisement';
        await ads.playBreak(adBreak);
      }
      ads.bindContent(video);
    }
    status.textContent = 'Loading stream...';
    await loadStream(player, easeLive, streamUrl, startTime, status, true);
  }

  function wireAds(
    player: ShakaPlayer,
    wrapper: HTMLElement,
    view: HTMLElement,
    adBreaks: AdBreak[],
    bridge: ShakaPlaybackBridge,
  ): AdController | null {
    if (!adBreaks.length) return null;
    const ads = new AdController(player.getInstance(), adBreaks, adRequestConfig.timeoutMs);
    const markers = createAdBreakMarkerSchedule(adBreaks);
    player.setAdBreakMarkers(markers);
    bridge.setAdBreakMarkers(markers);
    ads.onChange((state) => {
      player.setTransportLocked(state.active);
      bridge.setAdActive(state.active);
      document.getElementById('shaka-controls')
        ?.toggleAttribute('hidden', state.active);
      wrapper.classList.toggle('ad-break', state.active);
      view.classList.toggle('ad-break', state.active);
    });
    ads.onWatched((position) => {
      player.markAdBreakWatched(position);
      bridge.markAdBreakWatched(position);
    });
    return ads;
  }

  /** Start player load first, then Ease Live so it can wait on that same load. */
  async function loadStream(
    player: ShakaPlayer,
    easeLive: EaseLiveComponent,
    streamUrl: string,
    startTime: number | undefined,
    status: HTMLElement,
    autoplay = false,
  ): Promise<void> {
    const loadPromise = player.load(streamUrl, undefined, startTime);
    easeLive.init();
    try {
      await loadPromise;
      status.textContent = 'Player ready';
      if (autoplay) await player.play();
    } catch (error) {
      status.textContent = errorMessage(error, 'Failed to load the stream.');
    }
  }
}

void main();
