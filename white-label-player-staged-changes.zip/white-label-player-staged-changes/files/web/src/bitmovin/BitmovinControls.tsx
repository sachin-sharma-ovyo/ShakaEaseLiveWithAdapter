import React, { useCallback, useEffect, useRef, useState, type RefObject } from 'react';
import {
  PlaybackControl,
  type Episode,
  type VideoConfigItem,
  type VideoConfigProps,
  type VideoConfigType,
} from '@white-label/ui-react';
import type {
  IPlaybackBridge,
  IPlaybackOption,
  IPlaybackSettingsState,
  IPlaybackTime,
} from '../player/PlaybackBridge';
import './BitmovinControls.css';

const SKIP_SECONDS = 30;

/** Visible and accessible strings. The host passes its translations; English is the fallback. */
export interface BitmovinControlsLabels {
  play: string;
  pause: string;
  seek: string;
  mute: string;
  unmute: string;
  /** Shown instead of the remaining time on live streams. */
  live: string;
  episodes: string;
  /** Settings panel rows. */
  speed: string;
  quality: string;
  subtitles: string;
  audioLanguage: string;
  /** Automatic quality. */
  auto: string;
  /** Subtitles off. */
  off: string;
  /** Playback speed 1×. */
  normal: string;
}

const DEFAULT_LABELS: BitmovinControlsLabels = {
  play: 'Play',
  pause: 'Pause',
  seek: 'Seek',
  mute: 'Mute',
  unmute: 'Unmute',
  live: 'Live',
  episodes: 'Episodes',
  speed: 'Speed',
  quality: 'Quality',
  subtitles: 'Subtitles',
  audioLanguage: 'Audio Language',
  auto: 'Auto',
  off: 'Off',
  normal: 'Normal',
};

export interface BitmovinControlsProps {
  /** The bridge from `createBridge()`. Mounting and destroying it stays with the host. */
  bridge: IPlaybackBridge;
  /** Defaults to `'desktop'`. */
  device?: 'tv' | 'desktop';
  /** Current item title. With `seriesTitle` it becomes the second line. */
  title: string;
  seriesTitle?: string;
  genres?: string[];
  seasonNumber?: number;
  episodeNumber?: number;
  /** Feeds the Episodes panel. The Episodes button is hidden when empty or absent. */
  episodes?: Episode[];
  /** Host-owned episode navigation. Omit a callback when that direction is unavailable. */
  onPrevious?: () => void;
  onNext?: () => void;
  onBack?: () => void;
  labels?: Partial<BitmovinControlsLabels>;
  /** Element the fullscreen button expands. Defaults to the whole document. */
  fullscreenTarget?: RefObject<HTMLElement | null>;
  className?: string;
}

const INITIAL_TIME: IPlaybackTime = { currentTime: 0, duration: 0, positionPercent: 0, isLive: false };

function formatClock(totalSeconds: number): string {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const mm = String(minutes).padStart(2, '0');
  const ss = String(seconds).padStart(2, '0');
  return hours > 0 ? `${String(hours).padStart(2, '0')}:${mm}:${ss}` : `${mm}:${ss}`;
}

function formatRemaining(t: IPlaybackTime, liveLabel: string): string {
  if (t.isLive) return liveLabel;
  if (t.duration <= 0) return '-00:00';
  return `-${formatClock(Math.floor(Math.max(0, t.duration - t.currentTime)))}`;
}

function formatElapsed(t: IPlaybackTime): string {
  return formatClock(Math.floor(t.currentTime));
}

type SettingsList = Exclude<VideoConfigType, 'main'>;

/** One list in the settings panel: its row on the main page and its options page. */
interface SettingsSection {
  list: SettingsList;
  label: string;
  icon: VideoConfigItem['startIcon'];
  options: string[];
  selectedIndex: number;
  select(index: number): void;
}

function optionIndex(options: IPlaybackOption[], id: string | null): number {
  return id === null ? -1 : options.findIndex((option) => option.id === id);
}

/** Sections the stream offers a choice for, in panel order. Audio needs at least two tracks. */
function settingsSections(
  state: IPlaybackSettingsState,
  bridge: IPlaybackBridge,
  labels: BitmovinControlsLabels,
): SettingsSection[] {
  const settings = bridge.settings;
  if (!settings) {
    return [];
  }
  const sections: SettingsSection[] = [];
  const speedLabel = (speed: number) => (speed === 1 ? labels.normal : `${speed}×`);

  if (state.speeds.length > 0) {
    sections.push({
      list: 'speed',
      label: labels.speed,
      icon: 'playback-speed-circle',
      options: state.speeds.map(speedLabel),
      selectedIndex: state.speeds.indexOf(state.speed),
      select: (index) => settings.setSpeed(state.speeds[index]),
    });
  }
  if (state.qualities.length > 0) {
    sections.push({
      list: 'quality',
      label: labels.quality,
      icon: 'settings',
      options: [labels.auto, ...state.qualities.map((option) => option.label)],
      selectedIndex: optionIndex(state.qualities, state.quality) + 1,
      select: (index) => settings.setQuality(index === 0 ? null : state.qualities[index - 1].id),
    });
  }
  if (state.subtitles.length > 0) {
    sections.push({
      list: 'subtitles',
      label: labels.subtitles,
      icon: 'subtitles',
      options: [labels.off, ...state.subtitles.map((option) => option.label)],
      selectedIndex: optionIndex(state.subtitles, state.subtitle) + 1,
      select: (index) => settings.setSubtitle(index === 0 ? null : state.subtitles[index - 1].id),
    });
  }
  if (state.audioTracks.length > 1) {
    sections.push({
      list: 'audio-language',
      label: labels.audioLanguage,
      icon: 'language',
      options: state.audioTracks.map((option) => option.label),
      selectedIndex: optionIndex(state.audioTracks, state.audioTrack),
      select: (index) => settings.setAudioTrack(state.audioTracks[index].id),
    });
  }
  return sections;
}

/**
 * Player controls built from ui-react `PlaybackControl`, driven by an {@link IPlaybackBridge}.
 * Exported from `@white-label/player-web/bitmovin` as `Controls`.
 *
 * Covers the control bar only. The host owns the surrounding dialog: back button, focus trap,
 * Escape handling, and anything tied to the app (stream sessions, i18n, device detection).
 *
 * Styles: the host imports `@white-label/ui-react/tokens.css`, `@white-label/ui-react/styles.css`
 * and `@white-label/player-web/bitmovin.css`.
 */
export const BitmovinControls: React.FC<BitmovinControlsProps> = ({
  bridge,
  device = 'desktop',
  title,
  genres,
  seriesTitle,
  seasonNumber,
  episodeNumber,
  episodes,
  onPrevious,
  onNext,
  onBack,
  labels: labelOverrides,
  fullscreenTarget,
  className,
}) => {
  const labels = { ...DEFAULT_LABELS, ...labelOverrides };
  const lastVolumeRef = useRef<number>(100);
  const enteredFullscreenRef = useRef(false);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isBuffering, setIsBuffering] = useState(true);
  const [volumePercent, setVolumePercent] = useState(100);
  const [time, setTime] = useState<IPlaybackTime>(INITIAL_TIME);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEpisodesOpen, setIsEpisodesOpen] = useState(false);
  const [settingsState, setSettingsState] = useState<IPlaybackSettingsState | null>(null);
  /** Options page shown in the settings panel; `null` is the main page. */
  const [settingsList, setSettingsList] = useState<SettingsList | null>(null);

  useEffect(() => {
    const unsubscribers = [
      bridge.onPlayStateChange(setIsPlaying),
      bridge.onTimeUpdate(setTime),
      bridge.onVolumeChange((volume) => {
        setVolumePercent(volume);
        if (volume > 0) lastVolumeRef.current = volume;
      }),
      bridge.onBufferingChange(setIsBuffering),
    ];
    if (bridge.settings) {
      unsubscribers.push(bridge.settings.onSettingsChange(setSettingsState));
    }
    return () => unsubscribers.forEach((unsubscribe) => unsubscribe());
  }, [bridge]);

  // Leave fullscreen on unmount, but only if these controls entered it.
  useEffect(
    () => () => {
      if (enteredFullscreenRef.current && document.fullscreenElement) {
        document.exitFullscreen().catch(() => { });
      }
    },
    [],
  );

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      bridge.pause();
    } else {
      bridge.play();
    }
  }, [bridge, isPlaying]);

  const skip = useCallback(
    (delta: number) => {
      if (time.isLive || time.duration <= 0) return;
      bridge.seekTo(((time.currentTime + delta) / time.duration) * 100);
    },
    [bridge, time],
  );

  const restart = useCallback(() => {
    if (time.isLive || time.duration <= 0) return;
    bridge.seekTo(0);
  }, [bridge, time]);

  const toggleMute = useCallback(() => {
    bridge.setVolume(volumePercent > 0 ? 0 : lastVolumeRef.current || 100);
  }, [bridge, volumePercent]);

  const handleVolumeChange = useCallback((value: number) => bridge.setVolume(value), [bridge]);

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) {
      enteredFullscreenRef.current = false;
      document.exitFullscreen().catch(() => { });
      return;
    }
    const target = fullscreenTarget?.current ?? document.documentElement;
    target
      .requestFullscreen()
      .then(() => {
        enteredFullscreenRef.current = true;
      })
      .catch(() => { });
  }, [fullscreenTarget]);

  const toggleSettings = useCallback(() => {
    setIsSettingsOpen((prev) => !prev);
    setSettingsList(null);
    setIsEpisodesOpen(false);
  }, []);

  const toggleEpisodes = useCallback(() => {
    setIsEpisodesOpen((prev) => !prev);
    setIsSettingsOpen(false);
  }, []);

  const seekFromPointer = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      const rect = e.currentTarget.getBoundingClientRect();
      bridge.seekTo(((e.clientX - rect.left) / rect.width) * 100);
    },
    [bridge],
  );

  const seekFromKey = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        skip(-SKIP_SECONDS);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        skip(SKIP_SECONDS);
      } else if (e.key === 'Home') {
        e.preventDefault();
        bridge.seekTo(0);
      } else if (e.key === 'End') {
        e.preventDefault();
        bridge.seekTo(100);
      }
    },
    [bridge, skip],
  );

  const sections = settingsState ? settingsSections(settingsState, bridge, labels) : [];
  const openSection = sections.find((section) => section.list === settingsList);

  // Main page: one row per section showing its current value. Options page: picking an option
  // applies it and goes back to the main page.
  const videoConfigProps: Omit<VideoConfigProps, 'className'> = openSection
    ? {
      type: openSection.list,
      items: openSection.options.map((label) => ({ label })),
      selectedIndex: openSection.selectedIndex,
      onSelectItem: (index) => {
        openSection.select(index);
        setSettingsList(null);
      },
    }
    : {
      type: 'main',
      items: sections.map((section) => ({
        label: section.label,
        startIcon: section.icon,
        secondaryText: section.options[section.selectedIndex] ?? '',
        endIcon: 'chevron-right',
      })),
      onSelectItem: (index) => setSettingsList(sections[index].list),
    };

  const upperLine = seriesTitle || title;
  const episodeNumberLabel = [
    seasonNumber != null ? `S${seasonNumber}` : '',
    episodeNumber != null ? `E${episodeNumber}` : '',
  ].filter(Boolean).join(' ');
  const lowerLine = seriesTitle ? [episodeNumberLabel, title].filter(Boolean).join(' - ') : '';
  const volumeIcon: 'mute' | 'low' | 'high' =
    volumePercent === 0 ? 'mute' : volumePercent < 50 ? 'low' : 'high';

  const sliderA11y = {
    role: 'slider',
    'aria-label': labels.seek,
    'aria-valuemin': 0,
    'aria-valuemax': 100,
    'aria-valuenow': Math.round(time.positionPercent),
    'aria-valuetext': formatElapsed(time),
  };

  return (
    <PlaybackControl
      className={className ? `wlp-controls ${className}` : 'wlp-controls'}
      device={device}
      onBack={onBack}
      backwardsFocus={false}
      onwardsFocus={false}
      scrim={false}
      seriesTitle={upperLine}
      episodeTitle={lowerLine}
      tags={genres}
      remainingTime={formatRemaining(time, labels.live)}
      seekStepSeconds={SKIP_SECONDS}
      onSeekBackward={() => skip(-SKIP_SECONDS)}
      onSeekForward={() => skip(SKIP_SECONDS)}
      onRestart={restart}
      hasPrevious={!!onPrevious}
      hasNext={!!onNext}
      onPrevious={onPrevious}
      onNext={onNext}
      playPauseProps={{
        label: isPlaying ? labels.pause : labels.play,
        isPlaying,
        buffering: isBuffering,
        onClick: togglePlay,
      }}
      timeSliderProps={
        time.isLive
          ? {
            ...sliderA11y,
            value: time.positionPercent,
            thumbnailPreview: false,
            trackThumb: false,
            tabIndex: -1,
            'aria-disabled': true,
          }
          : {
            ...sliderA11y,
            value: time.positionPercent,
            thumbnailPreview: false,
            trackThumb: false,
            tabIndex: 0,
            onClick: seekFromPointer,
            onKeyDown: seekFromKey,
          }
      }
      volumeControlProps={{
        volume: volumeIcon,
        value: volumePercent,
        sliderControl: true,
        onValueChange: handleVolumeChange,
        onVolumeClick: toggleMute,
        label: volumePercent > 0 ? labels.mute : labels.unmute,
      }}
      settingsProps={
        sections.length > 0
          ? { collapsed: !isSettingsOpen, onToggle: toggleSettings, videoConfigProps }
          : { style: { display: 'none' } }
      }
      episodesProps={
        episodes && episodes.length > 0
          ? {
            collapsed: !isEpisodesOpen,
            onToggle: toggleEpisodes,
            episodeSelectionProps: { episodes, sectionLabel: labels.episodes },
          }
          : { style: { display: 'none' } }
      }
      fullscreenProps={{ onToggle: toggleFullscreen }}
    />
  );
};
