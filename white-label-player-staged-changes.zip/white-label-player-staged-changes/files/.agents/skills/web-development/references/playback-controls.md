# Playback and controls

Use for transport behavior, UI, styling, stream choices, captions, accessibility,
keyboard or fullscreen changes. Read [lifecycle](lifecycle.md) for ownership and
[advertising](advertising.md) when Shaka transport or visibility is affected.
Bare source paths are repository-relative.

## Trace from an interaction

The active components are
[ShakaControls.tsx](../../../../web/src/shaka/ShakaControls.tsx) and
[BitmovinControls.tsx](../../../../web/src/bitmovin/BitmovinControls.tsx).
Search the visible label/prop, then the callback, bridge method, SDK/media
operation, resulting event subscription, and React setter. Example:

```text
PlaybackControl play button
 -> togglePlay -> bridge.play()/pause()
 -> wrapper -> HTML video or Bitmovin SDK
 -> bridge media/SDK listeners -> onPlayStateChange -> React state -> button

settings row -> settingsSections -> adapter setter
 -> SDK track/config change -> settings event -> snapshot -> selected row
```

Controls subscribe in an effect and unsubscribe when the bridge changes or the
component unmounts. They do not mount/destroy playback. The demo's
[mountShakaControls.tsx](../../../../web/src/shaka/mountShakaControls.tsx)
connects an existing player/video, creates one React root and returns `update`
and `dispose`. Updating metadata/callbacks retains that root and subscriptions.
Its bridge does not own that player; disposing controls leaves playback alive.

Do not add an optimistic UI toggle without accounting for failed play/load or
the subsequent observed state. The bridge APIs return void from `play`, while
`IWebPlayer.play` returns a promise. Bridges log play rejection; the overlay
adapter's play request currently discards the promise without a rejection handler.

## Playback wrappers and bridge state

[ShakaPlayer.ts](../../../../web/src/shaka/ShakaPlayer.ts) creates a Shaka UI
overlay but disables its controls and keyboard playback; it removes HTML native
controls. It installs polyfills and configures streaming goals/seek tolerances.
Load attaches the video then loads the URL; a DRM URL configures Widevine and
PlayReady servers. `play` tries in the user-gesture turn and retries after the
load if the first call rejects. Relative `seekBy` clamps to `seekRange`.

[ShakaPlaybackBridge.ts](../../../../web/src/shaka/ShakaPlaybackBridge.ts)
can `connect` to a borrowed wrapper/video or `mount` its own wrapper/video/player.
It translates media `play`, `playing`, `pause`, `waiting`, `stalled`, `canplay`,
`seeked`, `timeupdate`, `durationchange`, `volumechange`, `ended` to UI state.
The wrapper separately translates buffering/playing/pause/ended/seeking/seeked
to the shared overlay state vocabulary. These paths can differ: a wrapper
`stopped` event is not the same as a host bridge's ad-suppressed ended event.

[BitmovinPlayer.ts](../../../../web/src/bitmovin/BitmovinPlayer.ts) requires
`licenseKey`, sets `ui: false`, and defaults autoplay true. It identifies sources
by literal `.mpd`/`.m3u8` suffix; other strings become progressive. **Limitation:**
query strings, case variations and extensionless URLs can be misclassified.
Do not claim general source detection or FairPlay support: current DRM wiring
only supplies Widevine and PlayReady URLs. Resume uses a positive finite
`startOffset`, not a seek after playing from zero.

[BitmovinPlaybackBridge.ts](../../../../web/src/bitmovin/BitmovinPlaybackBridge.ts)
binds events before loading, attaches settings/captions, then publishes a
post-load snapshot. `Play`/`Playing`/`Paused`/`PlaybackFinished` drive play state;
seek/time-shift and stall events drive buffering; time/duration and
volume/mute events publish current values. Its cached play and buffering values
are not explicitly reset for reuse; test reuse separately from a new instance.

Both wrappers de-duplicate shared overlay playback state; bridge UI subscriptions
generally publish on every relevant event. Registering host listeners after mount
starts gets current play/time/volume/buffering state, but pre-mount settings and
reconnect semantics differ; see [lifecycle](lifecycle.md).

## VOD, live and units

- Bridge `seekTo` and volume are clamped percentages (0–100). VOD transport
  controls step **30 seconds**, not the README's older 10-second description.
  Live and unknown-duration skips/restart are no-ops. Both sliders report
  live percent 100 and disable live interaction; this is not a DVR UI.
- Shaka seek percentage maps onto `[seekRange.start, seekRange.end]` and duration
  is their difference. UI skip/remaining calculations use absolute current media
  time versus that duration, so nonzero window starts deserve focused checks.
- Bitmovin wrapper requests `TimeMode.RelativeTime` for media positions and
  `AbsoluteTime` only for live date conversion. Live `seekBy` uses `timeShift`
  bounded by `getMaxTimeShift()` and 0; its window is derived in relative time.
  Public percentage seeking intentionally rejects live even though the overlay
  can request a relative DVR seek through the wrapper.
- Current controls disable their live slider themselves but do not pass the
  vendored UI's `isLive`/`liveSeekable` props. Do not assume the UI package's
  native live layout is active or all live transport buttons are hidden.
- Shaka bridge seeking blocks when `adActive`; wrapper play/pause/relative seek
  block when transport-locked. Settings and volume are separate paths; hiding
  controls is not a universal programmatic command lock.

## Settings and captions

`settingsSections` hides unavailable sections, prepends Auto quality and Off
subtitles, and requires more than one audio option for the audio menu. Both
components keep settings/episode panel state locally and close the other panel
when opening either one.

| Adapter | Existing mapping |
| --- | --- |
| [ShakaSettings.ts](../../../../web/src/shaka/ShakaSettings.ts) | Listens to track/variant/adaptation/ABR/text/load events and video rate changes. VOD speeds 0.5–2; explicit speed guard on live. Quality toggles ABR or selects a variant; options filter to current audio language and dedupe height/bandwidth. Audio IDs combine language and roles. Subtitles use text-track IDs plus Shaka visibility. |
| [BitmovinSettings.ts](../../../../web/src/bitmovin/BitmovinSettings.ts) | Waits for `SourceLoaded`, listens to speed/quality/audio/subtitle changes, stops reading on unload. Maps Auto to SDK `auto`; sorts qualities by height/bitrate. Audio/subtitle options dedupe by display label and map active IDs back to the displayed ID. Forced subtitles are excluded from the menu. Live speeds list is empty, though its setter itself accepts any positive value. |

The source does not force immediate Bitmovin buffer replacement on quality
selection. A selected quality may precede visible picture changes. Verify
downloaded/played quality as well as the menu; do not restore unsupported SDK
tweaks or advertise a fixed switch latency from an old comment.

[BitmovinSubtitles.ts](../../../../web/src/bitmovin/BitmovinSubtitles.ts) is
required because stock Bitmovin UI rendering is disabled. `CueEnter` creates
deduplicated text `VTTCue`s on a browser text track; `CueExit`, subtitle disable
and source unload remove them. Cues span playback and rely on SDK enter/exit
timing rather than assuming media and SDK timelines match. It recreates its track
if the video element changes. Detach empties/disables tracks (the DOM API cannot
remove them). `subtitleBottomPercent` positions text, default 25.
**Limitation:** image cues are not drawn, and full cue styling/position metadata
is not mapped. Menu selection alone does not prove visible captions.

Shaka's settings select Shaka text tracks and visibility; there is no parallel
custom caption renderer in this repo. Observe actual captions with the stock
controls disabled when changing track/overlay/layout behavior.

## Styling, input and accessibility

The design system's `PlaybackControl`, `VideoConfig` and `Episode` types are a
vendored React package. Inspect the declared and installed versions before using
new props. Local CSS lives in
[ShakaControls.css](../../../../web/src/shaka/ShakaControls.css),
[BitmovinControls.css](../../../../web/src/bitmovin/BitmovinControls.css), and the
demo shell [app.css](../../../../web/src/app.css). Host consumers need their own
shell dimensions, stacking and overlay containment; `app.css` is not shipped as
a public entry. The UI tokens/styles and player CSS are separate imports.

The demo stacks video, overlay, controls and ad surface. Shaka controls CSS sets
`#ad-container` to z-index 6; the HTML's older z-index 1 comment is incomplete.
Empty control-overlay areas pass pointer events through; actual controls take
events. The Shaka marker layer is a measured sibling overlay, never injected
inside React-owned slider DOM. Check hit areas, menus, markers, narrow layouts
and Ease Live background clicks when changing CSS. Current CSS depends on UI
class names (including different slider selectors); confirm against the version
in use instead of assuming selector compatibility.

Both controls accept English-fallback label overrides, metadata, episodes,
`onBack`, `className`, `device` (`desktop` or `tv`) and a fullscreen ref. The `tv`
prop is browser UI context, not permission to edit native TV code. Episode data
renders a panel; the pinned UI list has no image field or episode-selection
callback. Both controls accept host-owned `onPrevious` / `onNext`, enabling each
transport direction only when its callback exists. Shaka guards callbacks while
ads are active. These callbacks do not load content inside the controls.

The demo's shared `ContentNavigation` and `ContentPlaybackSession` supply those
callbacks for series, update mock episode metadata/URL, and autoplay from zero.
The same flow advances at genuine content completion when the shared demo option
`autoplayNext` is enabled (default). It waits for Shaka postroll, stops at the
last episode and can be disabled with `autoplayNext=false` on either player.
Movies hide the Episodes panel and leave Previous/Next disabled. All mock
episodes reuse the sample stream; arbitrary source switching is not implemented.
See [the demo guide](../../../../web/src/demo/README.md). The library provides
Settings → Subtitles, with no separate subtitle button or PiP control in
`PlaybackControl`; do not add substitute controls without host authorization.

Sliders supply role, min/max/current percentage and elapsed-time accessible text;
VOD sliders are focusable and handle Left/Right (30s), Home, End. Live sliders
are marked disabled and removed from tab order. Play/mute names follow state.
There is no general application-wide keyboard shortcut or focus-trap system in
these components. Hosts own dialog focus, Escape and route/session behavior.
Check keyboard reachability and focus after hiding controls/closing menus;
delegating some behavior to ui-react is not proof of complete accessibility.

Fullscreen targets the supplied element or document root. Components remember
whether they entered it and attempt exit on unmount, swallowing rejected
promises. **Limitations:** no `fullscreenchange` subscription or synchronized
fullscreen icon/state prop, and an outstanding fullscreen request can complete
after unmount. Test Escape, rejected requests, external fullscreen changes, and
teardown before making stronger ownership/state claims.
