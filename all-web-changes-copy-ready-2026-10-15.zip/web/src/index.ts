import { EaseLiveComponent } from '../../packages/shared-sdk/web/easelive';
import { AdController } from './ads/AdController';
import { createAdBreaks, getAdBreakMarkers, getAdBreaks } from './ads/adBreaks';
import '@white-label/ui-react/tokens.css';
import '@white-label/ui-react/styles.css';
import './app.css';
import { contentMetadata } from './config/contentMetadata';
import { adsEaseLiveConfig, easeLiveConfig, footballKickoffTimecodeMs } from './config/easeLiveConfig';
import { createWebPlayerPlugin } from './plugin/WebPlayerPlugin';
import { ShakaPlayer } from './shaka/ShakaPlayer';
import { ShakaPlaybackBridge } from './shaka/ShakaPlaybackBridge';
import { mountShakaControls } from './shaka/mountShakaControls';
import { errorMessage, readPlayerMarkup, waitForStartGesture } from './utils';

async function main(): Promise<void> {
  const { wrapper, video, status, view, adContainer } = readPlayerMarkup();
  const params = new URLSearchParams(window.location.search);
  const playerType = params.get('player');
  const adsDemo = params.get('easelive') === 'ads';
  const selectedEaseLiveConfig = adsDemo ? adsEaseLiveConfig : easeLiveConfig;
  const streamOverride = params.get('stream');
  const streamUrl = streamOverride || contentMetadata.streamUrl;
  const timecodeStartMs = streamOverride || adsDemo ? undefined : footballKickoffTimecodeMs;
  const startParam = Number(params.get('start'));
  const startTime = startParam > 0 ? startParam : undefined;

  if (playerType === 'bitmovin') {
    const { runBitmovinDemo } = await import('./demo/bitmovinDemo');
    await runBitmovinDemo({
      wrapper, video, status, view, streamUrl, startTime,
      easeLiveConfig: selectedEaseLiveConfig, timecodeStartMs,
    });
    return;
  }

  if (playerType === 'shaka') {
    // Shaka's existing ui-react controls remain the only controls.
    const player = new ShakaPlayer(video);
    player.onError((message) => { status.textContent = message; });
    const controls = mountShakaControls({ wrapper, video, player, title: 'Shaka with Ease Live' });
    window.addEventListener('pagehide', () => { void controls.dispose(); }, { once: true });

    const breaks = createAdBreaks(contentMetadata.advertisingInfoList);
    const ads = breaks.length ? wireAds(player, view, breaks, controls.bridge) : null;
    const easeLive = new EaseLiveComponent(view, createWebPlayerPlugin(player, ads, { timecodeStartMs }), selectedEaseLiveConfig, {
      onStatus(next) { status.textContent = `Overlay ${next}`; },
      onFatal(message) { status.textContent = message; },
    });

    if (!ads) {
      await loadStream(player, easeLive, streamUrl, startTime, status);
      return;
    }

    status.textContent = 'Click the video to start';
    // IMA needs to initialize inside the click gesture, before pre-roll/content load.
    const imaReady = await waitForStartGesture(wrapper, () => ads.tryInit(adContainer, video));
    if (imaReady) {
      const preRoll = getAdBreaks(breaks, 'PREROLL')[0];
      if (preRoll) {
        status.textContent = 'Advertisement';
        await ads.playBreak(preRoll.tagUrl, { kind: 'pre' });
      }
      ads.bindContent(video);
    }
    status.textContent = 'Loading stream...';
    await loadStream(player, easeLive, streamUrl, startTime, status, true);
  } else {
    status.textContent = 'Choose ?player=shaka or ?player=bitmovin in the URL.';
  }
}

function wireAds(
  player: ShakaPlayer,
  view: HTMLElement,
  breaks: ReturnType<typeof createAdBreaks>,
  bridge: ShakaPlaybackBridge,
): AdController {
  const ads = new AdController(player.getInstance(), breaks);
  const markers = getAdBreakMarkers(breaks);
  player.setAdBreakMarkers(markers);
  bridge.setAdBreakMarkers(markers);
  ads.onChange((state) => {
    player.setTransportLocked(state.active);
    bridge.setAdActive(state.active);
    document.getElementById('shaka-controls')?.toggleAttribute('hidden', state.active);
    view.classList.toggle('ad-break', state.active);
  });
  ads.onWatched((position) => {
    player.markAdBreakWatched(position);
    bridge.markAdBreakWatched(position);
  });
  return ads;
}

async function loadStream(
  player: ShakaPlayer,
  easeLive: EaseLiveComponent,
  streamUrl: string,
  startTime: number | undefined,
  status: HTMLElement,
  autoplay = false,
): Promise<void> {
  const loadPromise = player.load(streamUrl, undefined, startTime);
  easeLive.init();
  try {
    await loadPromise;
    status.textContent = 'Player ready';
    if (autoplay) await player.play();
  } catch (error) {
    status.textContent = errorMessage(error, 'Failed to load the stream.');
  }
}

void main();
