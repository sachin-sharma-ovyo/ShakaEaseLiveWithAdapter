import type { ContentControls, PlaybackContent, SubtitleTrack } from '../content/PlaybackContent';
import type { ContentAdvertising } from '../player/ContentPlaybackSession';
import type { IPlaybackBridge } from '../player/PlaybackBridge';
import type { IWebPlayer } from '../player/IWebPlayer';
import type { PlayerMarkup } from '../utils/dom';

/** Only SDK construction, controls, and track APIs vary between demo players. */
export interface DemoPlayer {
  readonly bridge: IPlaybackBridge;
  readonly advertising?: ContentAdvertising;
  load(streamUrl: string, startTime?: number): Promise<void>;
  getPlayer(): IWebPlayer | null;
  updateControls(state: ContentControls): void;
  hasSubtitles(): boolean;
  addSubtitle(track: SubtitleTrack): Promise<void>;
  destroy(): Promise<void>;
}

export type DemoPlayerFactory = (markup: PlayerMarkup, content: PlaybackContent) => DemoPlayer;
