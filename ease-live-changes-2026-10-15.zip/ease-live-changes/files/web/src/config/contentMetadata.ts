import type { ContentMetadata } from '../../../packages/shared-sdk/web/content/ContentMetadata';

/** Demo response. Replace this object with content-service metadata when available. */
export const contentMetadata: ContentMetadata = {
  streamUrl: 'https://vz-d1c9ca6b-f40.b-cdn.net/0d6ae227-bc97-4080-ae53-7b8e9a07ba4e/playlist.m3u8',
  startTimecode: 1784487976165,
  advertisingInfoList: [
    {
      advertisingContentId: '1',
      networkID: '1',
      cuePointList: [
        {
          customSlotId: 'intro',
          sequence: 1,
          timePositionClass: 'PREROLL',
          contentEndTimePosition: 0,
          adFormat: 'EMBEDDED',
          timeToNextAdUnit: 0,
          contentTimePosition: 0,
        },
        {
          customSlotId: 'mid-roll-1',
          sequence: 0,
          timePositionClass: 'MIDROLL',
          contentEndTimePosition: 0,
          adFormat: 'CLEAN',
          timeToNextAdUnit: 0,
          contentTimePosition: 90,
        },
        {
          customSlotId: 'end_credits',
          sequence: 0,
          timePositionClass: 'POSTROLL',
          contentEndTimePosition: 4,
          adFormat: 'CLEAN',
          timeToNextAdUnit: 0,
          contentTimePosition: 0,
        },
      ],
    },
  ],
};
