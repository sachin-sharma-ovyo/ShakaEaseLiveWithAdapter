import type { ContentMetadata } from '../../../packages/shared-sdk/web/content/ContentMetadata';

export interface ContentEpisode {
  number: number;
  title: string;
  duration: string;
}

export interface SubtitleTrack {
  id: string;
  lang: string;
  label: string;
  url: string;
}

interface BaseContent extends ContentMetadata {
  subtitleTracks?: SubtitleTrack[];
}

export interface MovieContent extends BaseContent {
  type: 'movie';
  seriesTitle?: never;
  seasonNumber?: never;
  episodeNumber?: never;
  episodes?: never;
}

export interface SeriesContent extends BaseContent {
  type: 'series';
  seriesTitle: string;
  seasonNumber: number;
  episodeNumber: number;
  episodes: ContentEpisode[];
}

export type PlaybackContent = MovieContent | SeriesContent;

/** Metadata and host callbacks shared by every player's controls. */
export interface ContentControls {
  title: string;
  genres?: string[];
  seriesTitle?: string;
  seasonNumber?: number;
  episodeNumber?: number;
  episodes?: ContentEpisode[];
  onPrevious?: () => void;
  onNext?: () => void;
}
