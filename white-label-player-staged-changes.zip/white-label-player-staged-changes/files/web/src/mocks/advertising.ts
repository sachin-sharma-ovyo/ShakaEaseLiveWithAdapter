import type { AdvertisingInfo } from '../../../packages/shared-sdk/web/content/ContentMetadata';

export const advertisingInfoList: AdvertisingInfo[] = [
  {
    advertisingContentId: '1',
    networkID: '1',
    cuePointList: [
      {
        customSlotId: 'intro',
        sequence: 1,
        timePositionClass: 'PREROLL',
        contentEndTimePosition: 0,
        adFormat: 'EMBEDDED',
        timeToNextAdUnit: 0,
        contentTimePosition: 0,
      },
      {
        customSlotId: 'mid-roll-1',
        sequence: 0,
        timePositionClass: 'MIDROLL',
        contentEndTimePosition: 0,
        adFormat: 'CLEAN',
        timeToNextAdUnit: 0,
        contentTimePosition: 90,
      },
      {
        customSlotId: 'end_credits',
        sequence: 0,
        timePositionClass: 'POSTROLL',
        contentEndTimePosition: 4,
        adFormat: 'CLEAN',
        timeToNextAdUnit: 0,
        contentTimePosition: 0,
      },
    ],
  },
];

/** Demo IMA VAST tags and request timeout. These are not content metadata. */
export const adRequestConfig = {
  timeoutMs: 8000,
  tagUrls: {
    PREROLL: 'https://pubads.g.doubleclick.net/gampad/ads?iu=/21775744923/external/single_preroll_skippable&sz=640x480&ciu_szs=300x250%2C728x90&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&correlator=',
    MIDROLL: 'https://pubads.g.doubleclick.net/gampad/ads?iu=/21775744923/external/single_preroll_skippable&sz=640x480&ciu_szs=300x250%2C728x90&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&correlator=',
    POSTROLL: 'https://pubads.g.doubleclick.net/gampad/ads?iu=/21775744923/external/single_ad_samples&sz=640x480&cust_params=sample_ct%3Dlinear&ciu_szs=300x250%2C728x90&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator=',
  },
} as const;
