# Manual transfer of the Web documentation changes

This ZIP contains the documentation created in this session. It has 10 files to
copy and instructions for 6 old files to delete. It contains no application code,
dependencies, native files, credentials, or `.mcp.json`.

## 1. Unzip into a separate folder

Extract `web-documentation-changes.zip` somewhere outside the destination
repository. You will see:

```text
web-documentation-changes/
  MANUAL.md
  files/
    AGENTS.md
    web/
      AGENTS.md
    .agents/
      skills/
        web-development/
          SKILL.md
          references/
            architecture.md
            playback-controls.md
            ease-live.md
            advertising.md
            lifecycle.md
            extensions.md
            verification.md
```

The `.agents` folder is hidden on some computers. On macOS, press
Command + Shift + . in Finder to show it. On Windows, enable View > Show >
Hidden items in File Explorer. Do not omit this folder.

## 2. Identify the destination repository root

The destination root is the folder containing `web/`, `packages/`, and the root
`package.json`. The documentation describes the Web source layout from the
originating repository. If your other repository has different paths or different
player behavior, adjust the references and behavior claims to match its source.
Do not assume that copying these documents transfers any player implementation.

Before replacing or deleting files, inspect the destination's working tree and
back up the affected files outside that repository. Preserve existing staged,
unstaged, and untracked work. If an affected destination file has unrelated
content, merge deliberately instead of overwriting that content.

## 3. Copy these files to exactly these destinations

All paths below are relative to the destination repository root. For every row,
copy `files/<listed path>` from the extracted ZIP to `<listed path>` in the
destination repository. Create missing directories.

| Destination path | Action |
| --- | --- |
| `AGENTS.md` | Add at the repository root. If it already contains other guidance, merge this Web entry point into it while retaining unrelated guidance. |
| `web/AGENTS.md` | Replace the old Web guide with this fresh file, or add it if absent. Preserve any unrelated destination work first. |
| `.agents/skills/web-development/SKILL.md` | Add the new Web skill; if already present, review and replace/merge intentionally. |
| `.agents/skills/web-development/references/architecture.md` | Add the architecture/contracts reference. |
| `.agents/skills/web-development/references/playback-controls.md` | Add the playback, controls, settings and captions reference. |
| `.agents/skills/web-development/references/ease-live.md` | Add the Ease Live reference. |
| `.agents/skills/web-development/references/advertising.md` | Add the Shaka/IMA reference. |
| `.agents/skills/web-development/references/lifecycle.md` | Add the ownership and lifecycle reference. |
| `.agents/skills/web-development/references/extensions.md` | Add the larger-feature and integration workflow. |
| `.agents/skills/web-development/references/verification.md` | Add the verification and work-preservation reference. |

You may copy the contents of `files/` into the destination root using folder
**merge**. Do not replace the entire destination `web/`, `.agents/`, or `skills/`
folder. Do not copy `files/` itself as a new folder inside the repository, and do
not nest the documentation under `web-documentation-changes/` in that repository.

`MANUAL.md` is transfer instructions only; it does not need to be copied into the
destination repository.

## 4. Delete these old files if they exist

Extracting or copying a ZIP does not delete old files. Remove the following six
paths manually from the destination repository after backing up any local work:

- `.agents/skills/web-player-change/SKILL.md`
- `.agents/skills/web-player-change/references/architecture.md`
- `.agents/skills/web-player-change/references/easelive-controls.md`
- `.agents/skills/web-player-change/references/playback-controls.md`
- `.agents/skills/web-player-change/references/shaka-ima.md`
- `.agents/skills/web-player-change/references/verification.md`

If those paths are absent, there is nothing to delete. Remove the old
`.agents/skills/web-player-change/references/` and
`.agents/skills/web-player-change/` directories only if they are empty afterward.
If the destination has extra files in that old skill folder, review them
individually; do not delete unknown files blindly.

Do not delete or modify other skills or native/tool-specific guidance. This
transfer does not change `.claude/`, `CLAUDE.md`, Android, Android TV, iOS, tvOS,
Kotlin, Swift, Gradle, Xcode, or native vendored artifacts.

## 5. Check the result

- Confirm all 10 copied files are in the exact paths above, including `.agents`.
- Confirm the six old files have been removed, if they existed.
- Open root `AGENTS.md`; its links should lead to `web/AGENTS.md` and the new
  `.agents/skills/web-development/SKILL.md`.
- Open the new skill and its seven reference links. Keep their relative folder
  structure intact. Links to Web source should match the destination's files.
- The skill frontmatter should retain `name: web-development` and its description.
- Review the destination diff/status: changes should be documentation only, with
  unrelated work preserved. This transfer needs no dependency installation,
  application build, staging, commit, push, or publication.

The dated typecheck failure in `references/verification.md` records the
originating checkout's installed UI-package mismatch on 2026-11-03. It is not a
claim about your destination checkout. Recheck or relabel that observation if the
destination has a different dependency state. Likewise, verify source-specific
limitations before treating them as current facts in another repository.

## What was validated in the originating repository

The documentation's YAML frontmatter, 85 local links/anchors, source paths,
source-based behavior claims, and documentation-only scope were checked. The
baseline typecheck failed because installed UI declarations rejected `onBack`.
Builds, package-consumer execution, and browser playback were not run. The ZIP
was checked for corruption, exact file contents, and the complete copy/delete
lists. No dependency or application implementation changes are included.
