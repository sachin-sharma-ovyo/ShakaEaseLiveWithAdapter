import type { SubtitleTrack } from '../content/PlaybackContent';

/** Sample captions for the default VOD, not a transcript of the sample video. */
export const demoSubtitleTracks: SubtitleTrack[] = [
  {
    id: 'demo-en', lang: 'en', label: 'English (demo)',
    url: new URL('./subtitles/demo-en.vtt', import.meta.url).href,
  },
  {
    id: 'demo-es', lang: 'es', label: 'Español (demo)',
    url: new URL('./subtitles/demo-es.vtt', import.meta.url).href,
  },
];
