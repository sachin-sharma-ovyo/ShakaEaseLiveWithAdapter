# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project does not yet use versioned releases; entries land under `[Unreleased]` and are grouped by branch / merge date.

Newest entries go at the top of `[Unreleased]`. Entries from July 2026 and earlier
are in [`docs/CHANGELOG-archive.md`](docs/CHANGELOG-archive.md) — when this file grows
past roughly 500 lines, move the oldest branch groups there.

## [Unreleased]

### dev — 2026-11-19 (account management, 18–19 November work)

#### Added

- **Account Management screen** — composed from `PersonalInformation`, `VerticalNavigation`, `Button` and `Alert` in `@white-label/ui-react`, with responsive page layout, populated view mode, local Edit/Save/Cancel drafts, password confirmation and independent visibility state, and local profile-photo selection. The app supplies a typed compatibility contract for the pending UI-library controls.
- **Authenticated profile loading** — `IUserProfile`, `GetProfileUseCase`, DI factory and repository mapping for the existing cookie-authenticated `GET /USER/PROFILE`. First name, surname, gender, birth date, email and mobile phone populate the form; missing fields stay empty and passwords are never populated. Loading, retry and unmount guards are included.
- **Documentation and regression coverage** — account integration notes, a UI-library handoff with the supplied prop contract, and a concise, platform-neutral list of confirmed gaps identifying each responsible organism, molecule, atom or account integration. Change Password and Delete Account are placeholders only; functional actions are out of scope. Focused tests cover avatar navigation, protected direct links and session restoration, profile mapping, failure/retry and local edit controls.

#### Changed

- **Account routing** — moved the former public `/preview/account-management` screen into the normal `GlobalProvider` / `AppRoutes` / `ScreenComponent` / `ScreenLayout` flow at `/AVS_BASE/ACCOUNT_MANAGEMENT`. The old preview URL redirects to the protected route. `RequireSession` waits for session restoration and redirects anonymous visitors to Sign In. Account deep links are treated as standalone screens so menu initialization does not send them Home.

#### Fixed

- **Avatar click logged the user out** — replaced `onAvatarClick={signOut}` with navigation to Account Management.
- **Successful profile response displayed a loading error** — the live API wraps account fields in `resultObj.profile.profileData`, whereas the initial mapper expected them directly in `resultObj`. The mapper now supports the live wrapper and the direct SDK shape; tests cover the nested response and reject unsuccessful responses. AVS `birthDate` / `birthdate` epoch-second values are converted to ISO dates, and `M` / `F` map to the form's gender values.

#### Notes

- Verified: `npm run typecheck`; 17 focused tests across 3 suites. The production build passed before the final response-wrapper correction, with existing Shaka source-map / CRA / Browserslist warnings. After that correction, the actual signed-in browser screen was reloaded and showed the user's populated details.
- Save, photo selection, password-change instructions and deletion notices remain local UI behavior. Backend profile updates, password changes, uploads, account deletion and additional account sections are not connected. The current UI library still ignores several supplied compatibility props; see `docs/account-management-ui-library-gaps.md` and `docs/account-management-ui-library-handoff.md`. No UI-library source changes are included.

#### Changed

- The overlay accepts autoplay (default false) and muted options, forwarded to both Shaka and Bitmovin. User-initiated movie, trailer, programme, series and demo playback passes autoplay true and muted false to request audio.

### feat/player-episode-selection — 2026-11-14 (select an episode from the player panel)

#### Changed

- The series player now passes the current season and episode numbers plus `onEpisodeSelect` to `@white-label/player-web`. Selecting any different episode in the Episodes panel reuses the existing in-player switch flow, fetches that episode's stream and resumes its saved bookmark. Current and invalid selections are ignored.
- The episode panel's `Episode` type now comes through the app's player bridge from `@white-label/player-web`; this feature no longer imports that type directly from `@white-label/ui-react`. The app's other UI-library usage is unchanged.

#### Notes

- Requires a player package build that exposes episode selection; update it separately with `npm run player:sync`. The player package, lockfile, vendored archive and sync script are deliberately outside this change.
- Checked with `npm run typecheck` and the 42 focused `SeriesPlayback` / `VideoPlayerOverlay` tests.

### Fixed

Updated scripts/sync-white-label-player.js to check for pack-web.js instead of pack-web.sh

### chore/ui-react-0.2.3 — 2026-11-13 (lockfile records @white-label/ui-react 0.2.3)

#### Changed

- **`package-lock.json`**: `@white-label/ui-react` `0.2.0` → `0.2.3` (one line). The dependency is `file:../white-label-ui/platforms/react`, so builds always use the sibling checkout. Only the version the lockfile records was stale; `package.json` is unchanged. Since 0.2.0: VideoConfig's submenu header shows the caller's selected option rather than Figma sample text (0.2.1), the `hd` and `a-large-small` icons (0.2.2), and two new tokens, `size/border/xl` and `scrim-overlay-lightTheme`, that no component uses yet (0.2.3). Run `npm run ui:sync` with `white-label-ui` on `main` (tag `v0.13.3`) to refresh a local install.

#### Notes

- Checked on this branch (from `origin/dev` `cc4c344`) with ui-react 0.2.3 and `dev`'s `player-web` `2be0ea1` installed: `npm run typecheck` → exit 0; `npm run gates` → passed (typecheck, lint, format); Jest → 76/76 tests, 9 suites.
- `npm audit` reports existing findings in the `react-scripts` / Babel / Jest tooling. This change adds none; they are left for a separate branch.

### feat/player-controls-part2 — 2026-11-12 (genre tags on Back's line)

#### Changed

- **Genres on Back's line** (on request). `VideoPlayerOverlay` now hands `genres` to the player's control bar, and ui-react `PlaybackControl` draws them as its `tags` in its own top row, beside Back. Before, the overlay drew its own `Tag`s in `.vpo-top`, which put them on a separate line above Back once Back moved into the bar (`1ee1340`). The original reason for drawing them in the overlay (the two bars put that row in different places, `feat/player-controls-part1` Notes) no longer holds with `player-web` `2be0ea1`: both bars fill the overlay. Hiding them now follows the bar: Ease Live's hide and Shaka's ad state both hide the bar, tags included, so the overlay's own `!adActive` check for them is gone. Removed the `Tag` import and `.vpo-genre` (`src/ui/elements/VideoPlayerOverlay.tsx`, `src/ui/styles/elements/videoPlayerOverlay.css`). The player picker (`REACT_APP_PLAYER=both` only) stays in `.vpo-top`, a line above.
- **`src/ui/elements/VideoPlayerOverlay.test.tsx`** — the genre tests now check that the bar gets the genres (and none when there are none) and that the overlay draws no tags itself. The "genres hide during an ad" test is gone, since the bar now hides them. 76 tests pass.

#### Notes

- Checked: `npm run gates`, full Jest suite. Headless Chrome (1600×900, `REACT_APP_PLAYER=both`, Game of Thrones): on both Bitmovin and Shaka, Back (x 48, 40×40) and the "ACTION" tag (x 96, 36 high) share a vertical centre (y 102), 8 px apart, with no tag left in `.vpo-top`. During the Shaka pre-roll, Back and the tag are both hidden; they return when the content starts.

### fix/GoogleAdChangesAndBackButtonAdded — 2026-11-12 (vendor the ad-enabled player build; typecheck fixed)

`1ee1340` (the entry below) changed the app for the ad-enabled player package but didn't commit the package: `vendor/`, `package.json` and `package-lock.json` still pointed at `f2138e2`, which has no ads, so `npm start` / `tsc` failed with `TS2305` (`AdBreakState`, `ShakaAdvertisingConfig` not exported) and `TS2345` (`advertising` not in `PlayerConfig`). The local snapshot `0.2.0-ea71ac4-local.<fingerprint>` it describes was never committed. The player change it was built from is now committed and pushed as white-label-player `2be0ea1` (`fix/supportGoogleAdForReactApp`, "feat(web): Shaka IMA ads via package entry").

#### Changed

- **Vendored `@white-label/player-web` is `0.2.0-2be0ea1`** (`vendor/white-label-player/web/`, `VERSION`, `package.json`, `package-lock.json`; only the player entry changed in the lockfile). Built from a `git archive` of `2be0ea1` in a temporary directory with the steps of the player's `pack:web` (`npm ci` in `packages/shared-sdk/web` and `web`, typecheck, `tsup` build, `npm pack`), not with `npm run player:sync`, which builds inside the `../white-label-player` checkout; that repo was not touched. A later `player:sync` on the same commit gives the same file name (integrity may differ). `2be0ea1` doesn't contain `f2138e2` (never merged) but has everything the app uses from it: Previous / Next on both players (Shaka ignores them during an ad), `onBack`, the Settings rows. It has no "quick menus", so the bar has no Subtitles or Speed button of its own. The only ui-react export it imports, `PlaybackControl`, is in the app's ui-react 0.2.0.
- **`src/ui/styles/elements/videoPlayerOverlay.css`** — removed both `f2138e2` shims: `.wlp-quick-menus` (those buttons no longer exist) and `.wl-video-config__header` (`2be0ea1` fills the submenu header with the localised title, the current value and a working Back to the main page, so hiding it would hide a working control). Stale "beside the close button" comment fixed. `.claude/rules/ui-library-adoption.md` §4 and the labels comment in `VideoPlayerOverlay.tsx` updated to match.
- **`src/ui/elements/VideoPlayerOverlay.test.tsx`** — brought in line with `1ee1340`: mocks `GetPlayerAdvertising` and the bridge's `onAdStateChange`, and `destroy()` resolves (the overlay now catches its rejection). The two close-cross tests became "no close button; the bar's Back is `onClose`" and "genres before the bar". New: the default schedule and `advertising={null}` reach `createBridge`, and genres hide during an ad and come back after it. 77 tests pass (was 17 failing).

#### Notes

- Checked: `npm run gates`; full Jest suite (9 suites, 77 tests); `CI=true REACT_APP_PLAYER=both npm run build` (only the 54 Shaka missing-source-map warnings). **Headless Chrome 157** (`REACT_APP_PLAYER=both`, mock ads on, Game of Thrones on the demo backend, Apple bipbop HLS with English WebVTT): on Shaka, Play started the pre-roll with the bar hidden, then the content played. On both players, the right-hand cluster is Settings, Episodes, Fullscreen. Settings → Subtitles shows the header "Subtitles · Off", its Back returns to the main page, and English shows the captions. Settings → Speed shows "Speed · Normal", and 1.5× sets the rate. Next keeps the overlay open on S1 E2, POSTs the bookmark of the episode left and fetches the next one (Shaka then waits for Play and plays its own pre-roll; Bitmovin autoplays). Back closes the player with no `<video>` left.
- Seen once, not reproduced: on the very first page load after the dev server started (IMA SDK not cached), the bar's Play did nothing for 90 s. Four later runs, including clicks 300 ms and 800 ms after the bar appeared, all started the pre-roll. If someone hits it, it belongs to the player package's Play-gesture handling.
- **Still missing from `1ee1340`**: the tests its entry lists (`src/services/player/shakaAdvertising.test.tsx`, `src/services/player/mockAdvertising.test.ts`, its `VideoPlayerOverlay.test.tsx` cases) and the Jest `moduleNameMapper` for `@white-label/player-web/*` in `package.json`. Not recreated here; the author should push them.

### feat/player-controls-part2 — 2026-11-11 (Shaka Google IMA ads from the player package; package Back button)

The app now consumes a player package built from the local white-label-player checkout (`fix/supportGoogleAdForReactApp` at `ea71ac4` plus uncommitted Web changes that add client-side Google IMA ads to the Shaka entry). The package owns the ad engine; the app supplies a mock schedule and hides its own layers during ads. Rationale: phase 3 #14 (Google Ad Manager) starts on Shaka with replaceable mock data.

#### Changed

- **Vendored `@white-label/player-web` is a local snapshot, `0.2.0-ea71ac4-local.<fingerprint>`** (`vendor/white-label-player/web/`, `vendor/white-label-player/VERSION`, `package.json`, `package-lock.json`). `pack:web` refuses an uncommitted tree, so the library was built and packed by hand under a distinct name; `VERSION` records the base commit and a fingerprint of the packed Web source. Installed files were compared byte-for-byte with the tarball, and both `package-lock.json` and `node_modules/.package-lock.json` carry the tarball's integrity. **Not a release:** re-run `npm run player:sync` once the player change is committed. `@white-label/ui-react` is unchanged (the sibling `../white-label-ui` checkout is present and its `dist` matches the installed copy).
- **`src/ui/elements/VideoPlayerOverlay.tsx`** — the purple X close button is gone; the overlay passes `onClose` as `onBack` to the package controls, whose Back arrow now closes (bookmark save, session release and navigation unchanged). New `advertising` prop (default: `GetPlayerAdvertising()`; `null`: none) handed to `createBridge`; subscribes to the bridge's `onAdStateChange` (unsubscribed on cleanup) and hides genre tags, the player picker and the Ease Live layer during ads. `onBack` is always forwarded: hiding Back during ads is the package's job. Focus: the dialog holds focus until the lazy controls load, then moves into them (searching only `.vpo-chrome`, since the player's hidden Shaka DOM can't take focus, and skipping the picker); the Tab trap also skips `visibility: hidden` elements and includes IMA's frame during ads; focus still returns to the opener on close. Bridge / Ease Live teardown rejections are logged instead of left unhandled. Ease Live is still attached right after `mount()` starts; the package now starts the overlay only when the content load starts (after the pre-roll), which fixed "EaseLive error: Player setup timed out" seen while waiting for Play.
- **`src/domain/content_page/PlayerBridge.ts`** — `IPlaybackBridge` gains optional `onAdStateChange`; `IPlayer.createBridge(options?)` takes `{ advertising }`; `PlayerAdvertising` / `PlayerAdState` types (from the package). **`src/services/player/ShakaPlayer.tsx`** passes `advertising` to the package; Bitmovin ignores it (no Bitmovin ads).
- **`src/ui/styles/elements/videoPlayerOverlay.css`** — `.vpo-easelive--ad` hides the Ease Live layer during ads; no focus outline on the dialog itself.
- **`package.json`** — Jest `moduleNameMapper` for `@white-label/player-web/{shaka,bitmovin,easelive}` (Jest 27 doesn't read package `exports`), so tests import the package by its public subpaths.

#### Added

- **`src/services/player/mockAdvertising.ts`** — TEMPORARY mock schedule: pre-roll, mid-roll at 90 content seconds, post-roll at content end, 8000 ms timeout, Google's public sample VAST tags (the ones the player demo uses). `REACT_APP_MOCK_ADS`: unset = on for `npm start`, off for `npm run build`; `false` disables locally; production needs an explicit `true`. Served by `GetPlayerAdvertising()` in `src/modules/ContentPageModule.ts`, the replacement point for a typed, runtime-validated backend adapter. Documented in `README.md` and `.env.example`.
- Tests: `src/services/player/shakaAdvertising.test.tsx` (the installed package with a fake Shaka and IMA: Play starts the pending session synchronously, unrelated clicks / Enter don't, one Play button and none in the video area, pre-roll before content at the start time, mid-roll at its offset, content time kept during an ad, post-roll before `onEnded` and once only, ad error / timeout / missing SDK fall back to content, absent / empty / invalid config plays normally, close while waiting for Play / during an ad / while the SDK loads, ad-state replay and unsubscribe, repeated mounts, `loadImaSdk` reuse / dedupe / retry / timeout, controls hide Back during ads and restore it and focus); `mockAdvertising.test.ts`; `VideoPlayerOverlay.test.tsx` (no close button, `onBack` always forwarded, initial focus and restoration, schedule passed / defaulted / `null`, no remount on re-render, host UI hidden during ads, ad-state unsubscribe, teardown rejection logged).

#### Notes

- Checked: `tsc --noEmit`; ESLint and Prettier on the changed files; full Jest suite (11 suites, 104 tests); `CI=true REACT_APP_PLAYER=both` production build (only Shaka's missing-source-map warnings, 54, for files its package doesn't publish; the bundle contains the final player code); player Web typecheck, library build and webpack demo build. Dev server (`REACT_APP_PLAYER=shaka`, port 3001) answered `GET /AVS_BASE` (`Accept: text/html`) with 200. `.env.local`'s `AVS_API_TARGET` was already a plain URL; not changed.
- **Observed in headless Chrome 157** (CDP-driven real clicks, Ease Live "Football" demo, pres95 backend, Google sample tags): awaiting Play with Back visible and Play not buffering, no centre play button; a click on the video area and Enter on Back did not start ads (Enter closed the player); Play started the pre-roll (Skip Ad shown, controls and Back hidden, Ease Live layer hidden, ad container clickable); clicking Skip Ad ended it; content then loaded and played with focus back on Pause; the mid-roll started at 90.5 s with content paused at 90.5 s and resumed at 91.1 s; the post-roll played after content end and content stayed ended; Ease Live attached after the pre-roll with no "Player setup timed out"; Escape during an ad and after it closed the player leaving no videos or ad containers; reopening started a fresh pre-roll. The VS Code integrated browser (Electron, no AAC) can't play the content (Shaka 4032), so it was not used for playback.
- **Not checked:** fullscreen with ads, keyboard Tab into IMA's Skip, Learn more, real backend VOD content with bookmarks during ads, Previous / Next with ads, engine switch during an ad, Safari / Firefox / mobile / TV runtimes, ad blockers.
- Known limits: Back is hidden during an ad (Escape still closes on desktop; there is no pointer exit until the ad ends or is skipped); after Previous / Next the new episode waits for Play before its pre-roll; Escape with the Settings panel open (focus on the Settings button) closes the player, as before this change.

### feat/player-controls-part2 — 2026-11-10 (player controls part 2: Subtitles, Speed, Previous / Next with bookmarks, Episodes)

Player controls part 2 for the web player. Subtitles and Speed get their own buttons in the bar; series episodes switch with one click on Previous / Next inside the open player, with the episode left keeping its bookmark (unless it is at least 95% watched) and the episode switched to resuming from its own; the Episodes panel now also appears when the episode was started from the series hero. The control bar itself comes from the vendored player package: the earlier implementation (white-label-player `33a8440` + `f2138e2`, branch `feat/player-next-episode`, never merged to its `dev`) was re-vendored from the tarball still in that repo's `build/web-pack/`. **white-label-player was not changed** (nothing re-packed, no checkout).

#### Changed

- **Vendored `@white-label/player-web` is now `0.2.0-f2138e2`** (was `880901a`; `vendor/white-label-player/web/`, `vendor/white-label-player/VERSION`, `package.json`, `package-lock.json`). `f2138e2` adds, over the controls the app had: **Subtitles** and **Speed** buttons in the bar's right-hand cluster ahead of Settings (each shown only while the stream offers a choice; Speed is a vertical list on desktop and a horizontal chip row on TV; Subtitles lists Off and the tracks), only one of Subtitles / Speed / Settings / Episodes open at a time, and Previous / Next that are enabled by host `onPrevious` / `onNext` (they were hard-coded disabled). It does **not** have `880901a`'s picture-in-picture button or its blank-slot `:has()` fix (white-label-player `67d07c7`, `55614bf`, `5792c90`, only on the unmerged `feat/ui-react-0.1.0-playback-control`). In practice PiP was already not drawn: the app's ui-react copy, re-synced from white-label-ui `main` (`54e51e3`), has no `PlaybackControl.pictureInPictureProps`. A player-side merge of the two branches is needed to have both.
- **No Subtitles or Speed button in the bar** (2026-11-11, on request; both are chosen in Settings → Subtitles / Settings → Speed). The vendored controls have no option to leave them out; they draw both inside one wrapper (`.wlp-quick-menus`) in the bar's right-hand cluster, so `src/ui/styles/elements/videoPlayerOverlay.css` hides that wrapper. It doesn't depend on the buttons' labels or on `:has()`, so it holds for translations and older smart-TV engines. (A first version hid only Subtitles, matched by its label with `:has()`; replaced.) Settings, Episodes, Fullscreen and Previous / Next are unaffected. Checked in headless Chrome (Bitmovin build): the bar's right-hand cluster reads Settings, Episodes, Fullscreen with no gap; Settings → Subtitles → English shows the captions and Settings → Speed → 1.5× sets the playback rate.
- **`src/ui/elements/watchCompletion.ts`** (new) — one rule for "watched to the end": 95% of a known duration (`isWatchCompleted`), replacing the 5/6 rule. Used by `VideoPlayerOverlay` (no bookmark saved on a pause or exit at the end; the bookmark is cleared instead) and `useWatchProgress.canResume` (Resume not offered at 95%+). So VOD details also change: a movie left between 83% and 95% now keeps its bookmark and offers Resume. `resumePositionOf` gives an episode's start position from its bookmark.
- **`src/ui/elements/VideoPlayerOverlay.tsx`** — new `onPrevious` / `onNext` props, passed to the bar. Labels for Speed, Quality, Subtitles, Audio Language, Auto, Off and Normal through `text()` (new keys `player.speed.label`, `player.quality.label`, `player.subtitles.label`, `player.audio.label`, `player.quality.auto`, `player.subtitles.off`, `player.speed.normal`). A stream swap no longer unmounts the control bar (the effect cleanup keeps the destroyed bridge, whose commands are no-ops, until the next player is set), and fullscreen is exited only when the overlay closes: before, every episode switch would have left fullscreen. Saving the episode left reuses the existing exit path (the cleanup runs with that episode's callbacks).
- **`src/ui/content_page/SeriesPlayback.tsx`** — `playEpisode(episode, season?)` takes an `ISeasonPlaylist` (the season's episodes and its index) instead of `IEpisodePlaybackInfo`; the provider builds the "S1 E2 - Title" label and the Episodes panel list itself (`toPanelEpisodes` in `seriesHelpers.ts`). New `setFirstSeason`: `SeasonEpisodesCollection` publishes the season its container loaded, so the hero's Play gets the Episodes panel and Previous / Next when that season holds the first episode. Previous / Next fetch the neighbour's stream and bookmark while the current episode keeps playing, then swap stream, episode and start position in one render; Play from a list still starts over and drops the bookmark, as before. A second click while a switch is pending is ignored; a switch answered after close / Play / Trailer is dropped. Movies and trailers get no Previous / Next and no Episodes panel. Switching stays within the season (no cross-season next).
- **`src/repositories/content_page/BookmarkRepository.ts`** — `fetchBookmark` compares content ids as text. Content ids reach the app as **numbers** at runtime (seen in the browser: `1210000117 number`) although `IContent.contentId` is typed `string`, and the bookmark list's id type is unconfirmed; a strict compare of the two types never finds the bookmark. This also affects the VOD Resume button, which uses the same lookup.
- **`src/ui/styles/elements/videoPlayerOverlay.css`** — hides `.wl-video-config__header` inside the player. ui-react 0.2.0's VideoConfig draws a submenu header (back arrow, title, current value) that the vendored controls (built against ui-react 0.1.1) don't fill in: it showed the Figma sample value ("Subtitles · English" with subtitles off, "Speed · 1x") on a back button that did nothing, in the new Subtitles / Speed menus and in every Settings submenu. To remove once the player controls pass `headerTitle` / `headerValue` / `onBack`.

#### Added

- Tests: `watchCompletion.test.ts`, `BookmarkRepository.test.ts` (string / number id matching), `useWatchProgress.test.ts` (95% Resume boundary), `VideoPlayerOverlay.test.tsx` (Previous / Next and labels to the bar; episode switch saves the episode left with its own callback, clears it at 95%, mounts the next at its start time, keeps the bar mounted and fullscreen on; 93% pause now saved), `SeriesPlayback.test.tsx` (14 cases: neighbours, labels, resume / start over, failed lookup, double click, close during a switch, stream error, hero season, trailer). Whole suite: 9 suites, 74 tests.

#### Notes

- Checked: `npm run gates`, the full test suite, `CI=true npm run build`; and in headless Chrome against the dev server on Game of Thrones (series `1700000014`, pres95 backend), with `REACT_APP_STREAM_URL_OVERRIDE` set to Apple's public `img_bipbop_adv_example_fmp4` HLS (it has an English WebVTT track), on both `REACT_APP_PLAYER=shaka` and `bitmovin` (the `.env.local` licence works on localhost). Observed: bar order Subtitles, Speed, Settings, Episodes, Fullscreen; Previous disabled on E1; the Subtitles menu (Off / English) selects and the caption text is on screen; Speed 1.5x sets the playback rate; the Episodes panel lists the season after the hero's Play; Next / Previous swap the episode without closing the player and POST the bookmark of the episode left (`CONTENT/USERDATA/VOD/{id}`, e.g. 41.3 s). The anonymous session's `GET /USER/BOOKMARKS` answers `401 User not logged in`, so resume was checked with the bookmark API answered in the browser from the positions the app had posted (CDP request interception): E1 resumed at ~42 s, E2 at ~102 s, E2 left at 97% was cleared and started over.
- Not checked: a logged-in account against the real bookmark API (in particular the `contentId` type in `/USER/BOOKMARKS`); fullscreen across a switch in a real browser (headless Chrome never entered fullscreen; unit-tested only); TV device mode and D-pad; Safari / Firefox / TV runtimes; real AVS streams with subtitles.
- Known limits: picking an episode in the Episodes panel does nothing (the library's `EpisodeSelection` rows have no callback; display only, as before). One extra `GET /USER/BOOKMARKS` per switch (the switch reads the next bookmark before swapping; `useWatchProgress` reads it again for the new id).

### feat/WLA-369-event-details — 2026-11-05 (sport event details hero)

The event page (`/AVS_BASE/PAGE/DETAILS/ENTITY/EVENT/{id}`) already rendered its rails through the WLA-363 entity route; this branch adds the hero on the library's `SportEventDetails` organism ([WLA-511](https://acn-avs.atlassian.net/browse/WLA-511), `white-label-ui` `e2bb036`, Figma 5171-25886 / 25887 / 25888). It was blocked on [WLA-465](https://acn-avs.atlassian.net/browse/WLA-465) until WLA-511 shipped the organism. `dev` is merged in (merge commit `55de141`, which takes `dev`'s side of every file this branch touches; the changes below are re-applied on top).

#### Added

- **`src/domain/content_page/SportsEntity.ts`** — `IEventEntity` (competition, season, stage, referees, venue, description, status, day name, sport, organisation), carried as an optional trailing `event` on `Content` (`src/domain/content_page/Content.ts`), the same way as `team` / `athlete`.
- **`src/repositories/content_page/ContentCollectionRepository.ts`** — `toEvent(ContentItemDTO)`, filled only for `EVENT_ITEM`. `MetadataDTO` gains the EVENT_ITEM fields. `venueName` and `refereeNames` can arrive as `null`: the venue goes through `defaultString`, the referees through `?? []` (`dev` removed the local `defaultArray`). The start time already maps to `airingStartTime` (WLA-363).
- **`src/ui/content_page/EventDetailsContentItem.tsx`** — the event hero. Tags: sport (grey) and event type (blue). Subtitle: `Competition | Organisation` (Figma "League | Association"). Info strip: day, date and time (`timer`), and the status (`info`). Event Information: competition, season, stage, venue, referee(s), empty rows dropped, no row icons (the Figma `stop` square is a placeholder, and `ListItem` leaves the icon uncoloured, so it renders black). About: the full description, or "Not Available"; the organism clamps it and shows Read More / Read Less only when it overflows (white-label-ui PR #171, `8170e75`). Backend enums (`FINISHED`, `REGULAR_SEASON`) are shown in sentence case through `text()` keys, so the dictionary can override them. Back goes one step back, or home on a direct link. The organism's `children` slot stays empty: the rails are the page's own containers.
- **`src/ui/content_page/EventDetailsContentItem.test.tsx`** — 4 tests: enum sentence case, the mapping and dropped rows, no organism demo copy when fields are missing, the full description and both Read More / Read Less labels passed through. Whole suite 43 passed in 7 suites.

#### Changed

- **`src/ui/content_collection/ContentDetailCollection.tsx`** — `EVENT_ITEM` renders `EventDetailsContentItem` (was `null`).

#### Notes

- Read More: the first version cut the text at 300 characters app-side and hid the button with a CSS override, because the organism always rendered it. White-label-ui PR #171 moved that into the organism (CSS line clamp, overflow measured with `ResizeObserver`, Read Less toggle), so the app clamp, its state and `eventDetails.css` were removed.
- Library gaps, handled app-side: `SportEventDetails` tags always render on desktop and TV with demo defaults ("team" / "event"), so a missing sport or type falls back to "Sport" / "Event". There is no calendar or location glyph, so the date uses `timer` and the venue is only in the info panel.
- Known upstream divergence (WLA-511): the panels keep their border on TV, where the Figma has none.
- Verified on demo-api, event `540406`, direct link: hero shows "FC Bayern München vs RB Leipzig", Football / Match tags, "Bundesliga | DFB", "Friday, Aug 22, 2025, 9:30 PM · Finished", four info rows (no venue: the backend sends `null`), about text with no Read More (it fits), poster from the CDN, and the 3 rails below lined up with the hero. Checked on desktop and tv (`WLA_DEVICE_MODE`). Back on a direct link goes to Home. Console clean.
- Long description: none of the demo events has one, so it was checked with the event's CONTENT/DETAIL response patched in the browser to a 1,164-character description: the text clamps to 5 lines, Read More appears, expands to Read Less (`aria-expanded` true) and collapses again.
- Not checked: mobile width, a real TV.
- The earlier follow-up (PROGRAM cards opening VOD details) was fixed by WLA-467 on `dev`.

### feat/player-controls-part1 — 2026-11-02 (Confluence "Player UI Controls" Part 1: the gaps)

An audit of the Part 1 control list against the code found these gaps: Play kept a stored bookmark, Pause saved none, series episodes had no bookmarks, skip was 10 s not 30 s, genres were not in the player, Close was an arrow, and closing live playback stayed on the programme screen. This branch is cut from `WLA-479-new-player-controls` (it needs the new bar) and has `dev` merged in (first PR #84, WLA-467, local merge commit `8e380b1`; then PRs #90 WLA-459 and #92 WLA-460, which turned the VOD and programme screens into thin wrappers and moved their logic into `VodDetailsContentItem` / `ProgramDetailsContentItem` — the changes below were ported there, and the changelog and the two screens were the conflicts). The player package change is white-label-player `880901a` (unpushed), re-vendored with `npm run player:sync`.

#### Changed

- **Play removes a stored bookmark** (`VodDetailsContentItem.tsx`, `SeriesPlayback.tsx`). `startVod('play')` / `playEpisode` call `clear()` once the stream URL is known, when a bookmark is stored. A start that fails or returns no URL keeps it. Resume keeps it. For episodes the stored value is read through a ref when the stream arrives, because the hook is keyed by the episode just chosen.
- **Pause saves a bookmark** (`VideoPlayerOverlay.tsx`). On a playing-to-paused change the overlay calls `onTimeUpdate` at once instead of waiting for the 5 s poll. It ignores the state replayed on subscribe (it would write a bookmark at 0 right after Play cleared it), live, an unknown duration, and the pause at the end of the video (at least 5/6 watched counts as finished, the same rule as on close, now one helper `isNearEnd`).
- **Series episodes get bookmarks** (`SeriesPlayback.tsx`): `useWatchProgress` keyed by the active episode, `onTimeUpdate` saves, `onEnded` clears. Trailers have no id, so nothing is saved. Nothing resumes an episode yet: the series screen has no Resume action, so the bookmark is written (and shows to other clients) but not used here.
- **`useWatchProgress.ts`**: a new id resets the saved position and the last-sent value at once, and an answer for an old id is ignored. Before, the next episode inherited the last one's position until its own fetch returned, and a slow answer could land on the wrong episode. Movies are unaffected (one id per screen).
- **Close is a cross** (`VideoPlayerOverlay.tsx`): `x-mark` icon, label `player.close.label` ("Close") instead of the `arrow-left` "Back". `backButtonRef` is now `closeButtonRef`.
- **Closing live playback leaves the screen** (`ProgramDetailsContentItem.tsx`): `handleClose` ends playback and then does what Back does (`handleBack`: one step back, or the TV guide on a direct link). VOD and series close as before, back to their details page.
- **Genres next to the close button**: `VideoPlayerOverlay` takes `genres` and draws them as ui-react outlined `Tag`s in its own top strip (`.vpo-top`), right after the close button, so both players show them in the same place (the library's top-row look: back button, then tags). They are not handed to the player's control bar, and they hide with it when Ease Live hides the bar. `.vpo-top` now wraps (`flex-wrap`, `max-width: 100%`) so many genres go onto a second line. Movies and trailers pass the content's genres, episodes pass the episode's, live passes the programme's genres.
- **Player package re-vendored** (`player-web` `880901a`): skip buttons now step 30 s with the library's `seek-*-30` glyphs and "Rewind / Forward 30 seconds" labels (the slider's arrow keys keep 10 s). The package's controls also gained an optional `genres` prop, which this app does not use (see Notes). `package.json`, `package-lock.json`, `vendor/white-label-player/VERSION` and the tarball moved from `5792c90` to `880901a`.

#### Added

- Tests (25 new; whole suite 36 passed in 6 suites): `VodDetailsContentItem.test.tsx` (Play clears, Resume keeps, failed start keeps), `SeriesPlayback.test.tsx` (keyed by episode, overlay wiring, genres, Play clears, failed start keeps), `VideoPlayerOverlay.test.tsx` (pause saves; not on replay, near the end, live or unknown duration; unsubscribes on close; cross icon; genres drawn after the close button and not given to the bar), `useWatchProgress.test.ts` (no carry-over between ids, late answer ignored, first save measured from zero). With the changes to `VideoPlayerOverlay.tsx`, `useWatchProgress.ts` and `SeriesPlayback.tsx` removed, 15 of the 19 tests in their three suites fail (the other four are "does not save" cases that pass without the feature). With `VodDetailsContentItem.tsx` reverted, its Play-clears test fails.

#### Notes

- Checked: `tsc --noEmit` exit 0, eslint and prettier clean on the touched files, the test suite above. Measured in headless Chrome (real controls, real overlay CSS and ui-react `Tag` / `IconButton`, SDKs stubbed, fake bridge; both players give the same numbers): the skip buttons are labelled "Rewind 30 seconds" / "Forward 30 seconds"; the three genre tags sit on the close button's row, centred on it (offset 0 px), 8 px apart and 8 px from the button, on desktop (button 40 px, tags 36 px) and tv (button 32 px, tags 44 px); none are drawn in the control bar; with 8 genres in a 700 px window 4 wrap onto a second line and the strip stays inside the chrome; the strip ends well above the title block.
- Why the genres are drawn here and not by the player's bar: the library puts a `tags` row at the top of the bar. Bitmovin's bar fills the overlay, so that row landed at the top of the screen under the close button, while Shaka's wrapper collapses the bar to its content, so the row landed just above the title. Drawing them in the overlay's own top strip gives both players the same place. The player package's `genres` prop (white-label-player `880901a`) is therefore unused by this app; it is additive and harmless, and can be dropped from the package if you'd rather not carry it.
- On tv the close button is the `sm` size and the tags `md` (32 px vs 44 px, centred on each other). The button size is unchanged from before; the library's own top row would use `md` for both.
- Not checked: playback in a real browser with either player, the real AVS bookmark API (whether `clear()` posting position `0` removes the bookmark is unconfirmed), the live close navigation (no test; it reuses the existing `handleBack`), PiP, Safari / Firefox / TV.
- Known gaps: "Watch from the beginning" only seeks to 0 inside the player package and does not clear the bookmark (the 5 s poll overwrites it). Play pressed before the bookmark fetch returns clears nothing (`savedSeconds` is still 0). After Play the poll saves a new bookmark within 5 s, so one exists again during playback.
- New UI text key: `player.close.label` ("Close"). `player.back.label` is no longer used by the overlay.
- Restart `npm start` after pulling this: the player package changed in `node_modules`.

### feat/WLA-460-program-page-containers — 2026-10-30 (Programme details from the backend PAGE response)

Programme details now fetch `/PAGE/DETAILS/PROGRAM/{id}` and render through `ContentPageComponent` → `MapContentCollection` → `ContentDetailCollection`, like VOD (WLA-459), Series and entity pages. Deep links and refreshes render the full page; nothing is read from `location.state`. The backend returns one bare `CONTENT_ITEM` (`contentType: PROGRAM`, verified on demo-api 2026-10-30), so the WLA-459 inline-item path carries it with no pipeline change. Removes the last temporary details exception from `.claude/rules/backend-driven-layout.md`.

#### Added

- **`ProgramDetailsContentItem`** (`ui/content_page/`): the programme hero, moved from `ProgramDetailsScreenComponent` with the same behaviour (`VideoDetailsLive`, Watch Live via the LIVE stream flow, live progress / countdown on a 30 s clock, favourites under the same `epg:{contentId}` key, Back to the previous screen or the TV Guide on a direct link). Builds a `ProgramSlot` from the item with the existing `ProgramSlot.fromContent`.
- `ContentDetailCollection`: `CONTENT_ITEM` + `contentType: PROGRAM` → `ProgramDetailsContentItem`, inside `.content-detail-bleed` like the VOD hero.
- `detailsRoute.ts`: `programPageUrlFor` (strict id regex, as for VOD and series), replacing `programContentIdFromPath`.
- Tests: programme page case in `PageRepository.test.ts`; `programPageUrlFor` cases in `detailsRoute.test.ts`.

#### Changed

- `ProgramDetailsScreenComponent` is a thin wrapper like `DetailsScreenComponent`; malformed id → "Programme unavailable". `ScreenLayout` passes `screenState`.
- `ContentCollectionMapper.toContent` maps a singular `metadata.genre` (PROGRAM items) into `genres` when `genres` is absent, so the hero's Genre row keeps working.
- TV Guide and PROGRAM cards no longer pass a programme slot in router state (`contentDetailsNavState` returns `{}` for programmes).
- The Rating row uses `starRating` only. The old fallback that turned `pcLevel` into stars is gone: `pcLevel` is a parental-control level (55 on the sample), not a rating.

#### Removed

- `/CONTENT/DETAIL/PROGRAM` slice, now unused: `ProgramDetailUseCase`, `GetProgramDetailUseCase`, `IEpgRepository.fetchProgramDetail` and its implementation, `EpgService.fetchProgramDetail`, `IProgramDetail`, and `EpgRepository.test.ts` (it only covered that method).
- "Programme details" row from the app-owned screens table in `.claude/rules/backend-driven-layout.md`, and its mention in `CLAUDE.md`.

### WLA-479-new-player-controls — 2026-10-29 (player control bar on the new PlaybackControl, ui-react 0.1.0, picture-in-picture)

The player control bar now uses the white-label-ui WLA-485 `PlaybackControl`, shown as the `Organisms/PlaybackControl` `BarOnly` story. The bar is drawn by `@white-label/player-web`'s `ShakaControls` / `BitmovinControls`, which use the app's own copy of `@white-label/ui-react` (the package keeps it external), so two things had to move: the app's ui-react copy and the player package's control props. Picture-in-picture is new on top of that. The first part (ui-react, controls) is committed as `4e93df7`; the picture-in-picture part is in the working tree.

#### Added

- **Picture-in-picture button in the player control bar** (2026-10-29). Between Episodes and Fullscreen in the right-hand cluster, drawn by the ui-react `PlaybackControl` (new opt-in `pictureInPictureProps`, ui-react `0.2.0`) from `ShakaControls` / `BitmovinControls`. Glyph `picture-in-picture`, switching to `picture-in-picture-exit` and "Exit picture in picture" while the video floats. The controls follow the new optional `bridge.pictureInPicture` member of the player package (`@white-label/player-web`) and pass the props only while the bridge reports `supported`, so the button is hidden until the stream has mounted and on browsers without the API. Never drawn on TV (the bar omits it, like Fullscreen). **No change in this repo's source**: `VideoPlayerOverlay` and its CSS are untouched, and there are no new text keys (the labels are the library's English strings, like the rest of the bar). What changed here is only the two synced packages below. An earlier version of this work put the button in the overlay's top right; that was replaced because the team wanted it in the bar.

#### Changed

- **`@white-label/ui-react` re-synced to `0.2.0`** (white-label-ui `9d52f0c` plus its uncommitted changes: the `0.1.0` version bump for WLA-485, then `0.2.0` for the picture-in-picture prop; `npm run ui:sync`). The installed copy was a build from 2026-10-21. `package-lock.json` records `0.2.0`; `package.json` is unchanged (still `file:../white-label-ui/platforms/react`). **This is a whole-library refresh, not only the player bar.** Besides `PlaybackControl` (WLA-485), the white-label-ui commits since that build include the Button padding rebind (PR #164: desktop / mobile Button is now 24 / 32 / 40 px tall for sm / md / lg, down from 28 / 40 / 48, TV is 28 / 40 / 48, down from 36 / 48 / 56), the secondary Button border now drawn inside the box in its own colour token, the `tertiary` Button / IconButton type, and the VideoSettings settings-trigger icon fix. Every screen with a ui-react `Button` will shift; no screen was compared before / after.
- **Vendored `@white-label/player-web` re-packed** (`vendor/white-label-player/web/white-label-player-web-0.2.0-5792c90.tgz`, was `a9ac67f`; `vendor/white-label-player/VERSION`, `package.json`, `package-lock.json`). Source is white-label-player branch `feat/ui-react-0.1.0-playback-control` (cut from `dev`, not pushed): `f5fe3b8` is the controls change below, `67d07c7` adds the picture-in-picture bridge member and `55614bf` draws the button in the bar and `5792c90` removes the blank slot (next entry) (`4e93df7` vendored `f5fe3b8`; the working tree has `5792c90`). What changed in the controls: `scrim={false}` and `seekStepSeconds={10}` (so the glyph and label say 10 seconds, as the skip does), a working Replay button (seeks to the start; nothing on live streams), and Previous / Next shown **disabled** because the controls have no episode navigation yet. `BarOnly` itself draws Previous / Next enabled; this is a decision, see the player CHANGELOG.
- **No blank slot in the bar's right-hand cluster** (2026-10-29, in player-web `5792c90`; no change in this repo's source). With no episodes (a single video) or no settings, the controls hid the button but `PlaybackControl` still drew its 36 px slot and the 16 px gap beside it, leaving a gap between Settings and the new picture-in-picture button. The player package's control CSS now hides that slot as well (a `:has()` rule). Browsers without `:has()` (older smart-TV engines) keep the blank slot, as before.
- **What the bar looks like now** (versus the bar before this change): adds Replay, Previous and Next buttons, the 10-second glyphs, and the 45 px focus ring on real focus (TV) or `:focus-visible` (desktop). `VideoPlayerOverlay` itself is untouched: its own Back button and the player picker still sit above the bar.

#### Notes

- Checked: `npm run typecheck` passes. The DOM of `ShakaControls` and `BitmovinControls` (device `tv`, static render of the player sources against this repo's ui-react 0.1.0, SDKs stubbed) matches `BarOnly` button for button: Replay, Mute, Previous, Rewind, Play, Forward, Next, Settings, Episodes; same title, episode and time text; no scrim, no top row. Differences are the intended ones: 10-second labels, Previous / Next disabled, and no pinned focus rings.
- Checked, picture-in-picture (2026-10-29): `npm run typecheck` passes. A jsdom test mounted the real `ShakaControls` and `BitmovinControls` (the committed player sources, SDKs stubbed) against this repo's ui-react `0.2.0` with a fake bridge: 12 of 12 pass. No button while `supported` is false; it appears between Episodes and Fullscreen when true; a click calls `toggle` once and `active` swaps the label; not drawn on TV; it disappears if `supported` turns false; unsubscribed on unmount. The UI library and the player helper have their own checks (see their CHANGELOGs).
- Checked, blank slot (2026-10-29): headless Chrome, desktop mode, the real `ShakaControls` and `BitmovinControls` (SDKs stubbed, fake bridge) against this repo's ui-react `0.2.0`, slots counted from `getBoundingClientRect`, control CSS from git `HEAD` vs the fix. Settings but no Episodes: 4 slots with 1 blank became 3 with 0 blank, gaps 16 px and 16 px. Neither: 4 with 2 blank became 2 with 0 blank, gap 16 px. Both: unchanged (4 slots, 0 blank). The same for both controls. Not run: the app with a stream, Safari or Firefox, `mobile` or `tv` device modes, a browser without `:has()`.
- **Not checked, picture-in-picture:** a real playing app. The floating window itself, the button's own look and size (only the gaps between the bar's slots were measured, in the entry above; the Storybook measurement had no browser tool), real Shaka and Bitmovin video elements, Safari, and what happens to Ease Live graphics and the host controls (they are DOM above the video, so they are not in the floating window). Closing the overlay while floating closes the window by design, not verified live. Compose and SwiftUI have no PiP button; that is the native parity gap recorded in white-label-ui.
- **Not checked:** the app in a browser. No playback, no pixel or spacing comparison with the story, no `desktop` or `mobile` device mode, and no screen outside the player after the ui-react refresh. The app needs the AVS backend and a Bitmovin key, so it was not started here.
- `ui:sync` and `player:sync` also reinstalled dependencies; the `npm audit` and install-script warnings they print are not new.

### feat/WLA-459-vod-page-containers — 2026-10-28 (VOD details from the backend PAGE response)

VOD details now fetch `/PAGE/DETAILS/VOD/{id}` and render through `ContentPageComponent` → `MapContentCollection`, like Series (WLA-458) and entity pages. Deep links and refreshes render the full page; nothing is read from `location.state`. The backend returns two shapes, both handled: movies get `content_detail` + `SMALL_CARDS` "Highlights" + `LARGE_CARDS` "You may also like"; other VOD (episodes, clips) gets one bare `CONTENT_ITEM` container with no `retrieveItems`. Removes the VOD details exception from `.claude/rules/backend-driven-layout.md`.

#### Added

- **Inline items in the PAGE pipeline**: `ICompositeContainer.inlineItems` (`domain/content_page/Containers.ts`). `PageRepository` maps a bare `CONTENT_ITEM` container (no `retrieveItems`) into it, through the TRAY item mapper (`ContentCollectionMapper.toContent`, now exported with `ContentItemDTO`). `ContentCollectionComponent` starts such a container `Loaded` with those items and fetches nothing. Shared with WLA-460 (Programme details), whose page has the same shape.
- **`VodDetailsContentItem`** (`ui/content_page/`): the VOD hero, moved from `DetailsScreenComponent` with the same behaviour (Play / Resume / Trailer, favourites, watch progress, tags, See More). Skips the "Episode" row when `episodeTitle` repeats the title, as `/CONTENT/DETAIL/VOD` does on movies.
- `ContentDetailCollection`: `CONTENT_ITEM` + `contentType: VOD` → `VodDetailsContentItem`. `MapContentCollection`: explicit `CONTENT_ITEM` case → `ContentDetailCollection`, and no generic header.
- `detailsRoute.ts`: `VOD_DETAILS_PREFIX`, `isVodDetailsPath`, `vodPageUrlFor` (strict id regex, as for series).
- Tests: `PageRepository.test.ts` (new; both page shapes), `vodPageUrlFor` cases in `detailsRoute.test.ts`.

#### Changed

- `DetailsScreenComponent` is a thin wrapper like `SeriesDetailsScreenComponent`; malformed id → "Details unavailable". `ScreenLayout` keys it by pathname and passes `screenState`.
- `App.tsx`: VOD route is `/AVS_BASE/PAGE/DETAILS/VOD/*` (was `:contentId/:slug`), so slugless and malformed links reach the screen instead of a blank page.

#### Fixed

- **Details hero alignment** (2026-10-29): inside `.content-collections-list` the `VideoDetails` hero was inset by the list's safe-area gutter, and since the organism pads its own body with the same gutter, its text started at 2× (96 px) while the rails started at 1× (48 px). The background and scrim were inset as well. `ContentDetailCollection` now wraps the VOD and series heroes in `.content-detail-bleed` (new `styles/content_page/contentDetailCollection.css`), which pulls them out to the list's edges with a negative inline margin, so no `.wl-*` class is overridden. Measured at 1440 px: the hero spans the full width, and the hero title and the "You may also like" title both start at 48 px. The series hero (WLA-458) had the same nesting and is fixed too. Team and athlete heroes are unchanged.

#### Removed

- `SimilarContentRail.tsx` + `similarContentRail.css` (app-invented "More like this" rail with a hardcoded `/TRAY/SEARCH/VOD?genres=…` URL and English title). The backend's "You may also like" container replaces it. Dropped from the ESLint allowlist (`package.json`), the rule file, `CLAUDE.md` and `docs/ui-library-adoption.md`.

#### Notes

- Checked in the browser on demo-api (fresh loads): `1498201592` (movie) shows the hero and "You may also like", Highlights hidden (empty, existing rails hide when empty); `100139` (episode) shows the hero with only the PAGE request; refresh, slugless link, card → card navigation, Play, Trailer, Resume after 30 s and malformed id all work; console clean. Favourite while signed out redirects to sign-in, as before.
- Backend, not blocking: "Highlights" always returns 0 items (`query=__Clone__2__{id}` looks like an unresolved placeholder); non-movie VOD has no page template; "You may also like" includes the title itself (the old rail filtered it out).
- The test file uses regex matchers for expected `/PAGE/…` URIs, because the UI ESLint guard rejects backend-URI string literals in `src/ui/` (tests included).

### feat/player-picker — 2026-10-22 (Bitmovin / Shaka picker, Shaka controls, temporary Ease Live demo, vendored player)

Lets developers compare the two `@white-label/player-web` players (WLA-435) in one build, and adds the temporary Ease Live demo (2 examples reached from Home) until the AVS backend serves Ease Live content. Release builds are unchanged: `REACT_APP_PLAYER` still defaults to `bitmovin` and `REACT_APP_EASELIVE_DEMO` to `false`. Checked with production builds: the `bitmovin` build has no Shaka chunk, and with the demo off the Ease Live SDK is not built at all; with it on, the SDK is one ~100 KB lazy chunk. The player package (0.2.0, with the `./easelive` entry) now comes from a vendored tarball, so the app no longer needs a white-label-player checkout.

#### Added

- **Vendored `@white-label/player-web`** (2026-10-23): `vendor/white-label-player/web/white-label-player-web-0.2.0-a9ac67f.tgz` (390 KB, from white-label-player `feat/web-easelive-attach` `a9ac67f`, packed by its new `pack:web`), with `vendor/white-label-player/VERSION`. `package.json` / `package-lock.json` point at the tarball (with an integrity hash) instead of `file:../white-label-player/web`. `npm run player:sync` is now `scripts/sync-white-label-player.js` (runs the player repo's `pack:web`, swaps the tarball, writes `VERSION`, reinstalls), replacing `player:build` / `player:clean`. `.gitattributes` (new) marks `vendor/**` as vendored and `*.tgz` as binary. Docs: `README.md` → Video player, `CLAUDE.md` → Build / run, `docs/ui-library-adoption.md`. `@white-label/ui-react` still comes from `../white-label-ui` — a fresh clone still needs that checkout until it is vendored the same way.

- **Ease Live demo rail** (`src/ui/content_page/EaseLiveDemoRail.tsx`), at the top of Home when `REACT_APP_EASELIVE_DEMO=true`: a ui-react `Rail` with two `Card`s (Football, Football with ads). Each opens `VideoPlayerOverlay` on the demo stream with that Ease Live programme. App-added block, recorded as a temporary exception in `.claude/rules/backend-driven-layout.md`. `ScreenLayout` shows it only when the main menu's default item (Home) is selected. Cards show the demo stream's Bunny Stream poster (`thumbnail.jpg` next to the playlist, same image for both). `easeLiveDemoRail.css` gives it the same insets as `.content-collections-list`, which it sits above, so it lines up with the backend rails.
- **Ease Live behind a domain interface**: `IEaseLive` / `IEaseLiveOverlay` / `EaseLiveProgram` in `domain/content_page/EaseLive.ts`, adapter `services/player/EaseLive.ts` over the package's `attachEaseLive`, lazy loader `LoadEaseLive()` in `ContentPageModule.ts`.
- **`VideoPlayerOverlay` `easeLive` prop**: loads Ease Live with the player, attaches it right after mount starts into a new `.vpo-easelive` layer between video and chrome, hides the control bar when Ease Live asks (`.vpo-controls-hidden`), and removes it on close or player switch. An Ease Live failure is logged and playback continues. Without the prop nothing changes. `.vpo-top` (Back + picker) is now `align-self: flex-start`, so the full-width strip it used to span no longer takes clicks meant for Ease Live buttons along the top. Checked in the browser (2026-10-23): football stats overlay and the ads programme's L-bar / PiP / border scenes show in both players, matching the player repo's demo page apart from IMA ad breaks.
- **Ease Live on every video** (2026-10-23, optional): `REACT_APP_EASELIVE_TRY_ON_ALL=football|ads` (with the demo on) puts that demo programme on every playback, backend VOD and live included, to show Ease Live on real content. The demo rail then shows a **Football | Ads** `ToggleButton` that switches it, remembered in localStorage (`WLA_EASELIVE_PROGRAM`, `src/ui/config/easeLiveChoice.ts`); it applies from the next playback. The demo cards keep their own programme. Unset (the default) = off. The programmes are timed to the demo clip, so their scenes don't match other content; real content needs its own Ease Live programme and the IDs from the backend. Checked in the browser on backend VOD: the football side stats and the ads programme's PiP / L-bar / border scenes show over real content. Text keys: `easelive.demo.all_videos.label`, `easelive.demo.all_videos.ads`.
- **`REACT_APP_EASELIVE_DEMO`** (`.env.example`); `scripts/react-scripts.js` defaults it to `false` so webpack can drop the chunk.

- **`REACT_APP_PLAYER=both`** (`scripts/react-scripts.js`, `.env.example`): bundles both players as separate lazy chunks.
- **Player picker** in `VideoPlayerOverlay.tsx`: a ui-react `ToggleButton` (Bitmovin | Shaka) next to Back, shown only when the build has both players. Switching tears down the current player and mounts the other at the same position (live restarts at the live edge) without firing `onEnded`.
- **`src/ui/config/playerChoice.ts`**: remembers the last pick in localStorage (`WLA_PLAYER`), falling back to the build's default.

#### Changed

- `LoadPlayer(kind)` in `ContentPageModule.ts` takes the player to load; `AVAILABLE_PLAYERS` lists the build's players. `PlayerKind` added to `domain/content_page/PlayerBridge.ts`.
- **Shaka now renders the package's ui-react control bar.** WLA-436 turned Shaka's stock UI off and added `ShakaControls`, but `services/player/ShakaPlayer.ts` still assumed Shaka drew its own, so Shaka played with no controls. Renamed to `ShakaPlayer.tsx`; it imports `@white-label/player-web/shaka.css` (exported since player PR #28) and narrows the bridge to `ShakaPlaybackBridge` for `ShakaControls`.

#### Notes

- Not yet checked in a browser: playback, the player switch, Bitmovin licensing on `localhost`, and the Ease Live demo in the app.
- New UI text keys: `player.picker.label` ("Player"), `easelive.demo.title` ("Ease Live demo"), `easelive.demo.football` ("Football"), `easelive.demo.ads` ("Football with ads"), `easelive.demo.error`. Player names are not translated.
- Both players show the same control bar by design (player repo: ui-react controls own the UI for both).
- IMA ad breaks are not part of the demo; only Ease Live's own overlay graphics.

### fix/WLA-467-program-card-routing — 2026-10-16 (PROGRAM cards open programme details)

PROGRAM (live airing) cards opened the VOD details screen. There, Play ran the VOD stream flow with a programme id. The programme details screen only worked when the TV guide handed it a slot, and showed a placeholder on direct link or refresh. Found while verifying WLA-369 ("More Programs From This Event" on `EVENT/540406`); the home LIVE rail had the same problem.

#### Changed

- **`src/ui/content_page/detailsRoute.ts`**:
    - `contentDetailsUrlFor` sends PROGRAM content to `/AVS_BASE/PAGE/DETAILS/PROGRAM/{contentId}/{slug}`. It detects PROGRAM from the backend `onClick` URI (`/PAGE/DETAILS/PROGRAM/…`), falling back to `contentType`.
    - New `contentDetailsNavState(content)` hands PROGRAM cards over as an `IProgramSlot` (`{ program }`) and everything else as `{ content }`.
    - The programme route helpers (`PROGRAM_DETAILS_PREFIX`, `programDetailsUrlFor`, `isProgramDetailsPath`) moved here from `epgRoute.ts` to avoid an import cycle. New `programContentIdFromPath` accepts only a plain id segment before it reaches the API URL.
- **Card call sites** — `SmallCardsContentItem`, `LargeCardsContentItem`, `CarouselContentCollection`, `RailContentCollection` pass `contentDetailsNavState(content)`. This covers every rail and grid layout.
- **`src/ui/content_page/ProgramDetailsScreenComponent.tsx`**:
    - The programme is fetched by the contentId in the path, which makes direct links and refresh work. A slot in router state is only the first paint.
    - It shows a loading state while fetching with no slot. The placeholder now appears only when the fetch fails.
    - The old code read `useParams().contentId`, which was always undefined because the route is `/*`.
    - Back returns to the previous screen and falls back to the TV guide only when there is no in-app history. Before, it always went to the guide.
- **`src/repositories/content_page/EpgRepository.ts`** — `fetchProgramDetail` maps the full programme (`IProgramDetail.program`) from `/CONTENT/DETAIL/PROGRAM/{id}` through the listing mapper. That endpoint returns the channel and airing window (verified on demo-api).
- **`src/domain/content_page/Epg.ts`** — `IProgramDetail.program?`, plus `ProgramSlot.fromContent(content, posterUrl)`.
- **`src/ui/screen/ScreenLayout.tsx`** — the programme screen is keyed by pathname, so going from one programme to another resets its state.

#### Removed

- **`src/ui/content_page/DetailsScreenComponent.tsx`** — the live-programme rows (channel, airing, features) and `isLiveContent`. No card routes PROGRAM content to the VOD screen any more.

#### Added

- `src/ui/content_page/detailsRoute.test.ts` and `src/repositories/content_page/EpgRepository.test.ts`. These are the repo's first unit tests: routing, nav state, path parsing and detail mapping.

#### Notes

- A programme favourited from a card (`contentId`) and from its details page (`epg:{contentId}`) are still two different favourites. Not changed here; raise separately.
- Jest's default `testMatch` glob doesn't match files under a `.claude/worktrees/…` checkout on Windows. To run tests from a worktree, pass `--testMatch="<abs-path>/src/**/*.test.ts"`.

### chore/backend-driven-layout-rule — 2026-10-15 (enforce backend-driven page layout)

Code in this repo is agent-generated, so the rule is written for Claude Code and backed by a lint guard that blocks commits and builds. The branch is cut from `feat/WLA-458-series-page-containers`: on `dev`, the old Series screen still hardcodes TRAY URLs and would fail the new guard. Merge WLA-458 first.

#### Added

- **`.claude/rules/backend-driven-layout.md`** (auto-loaded for `src/ui/**` and `src/App.tsx`):
    - hard rules: no backend URIs or layout fetches in UI code, no structure from `location.state`, no invented blocks, an explicit `case` for every layout a page returns;
    - a step-by-step recipe for adding a backend-driven page, with the WLA-458 / WLA-363 screens as references;
    - the allowed-exception tables;
    - what to do when the backend PAGE response doesn't support a design: stop and report, don't hardcode.
- **ESLint guard** (`eslintConfig.overrides` in `package.json`), for `src/ui/**`:
    - `/TRAY/`, `/PAGE/` and `/CONTENT/` string and template literals are errors;
    - importing `GetPageUseCase` or `GetContentCollectionUseCase` from `ContentPageModule` is an error;
    - an allowlist exempts the pipeline (`ContentPageComponent`, `GridPageComponent`, `ContentCollectionComponent`, `SeasonEpisodesCollection`), the route mappers (`entityRoute`, `detailsRoute`) and, temporarily, `SimilarContentRail`;
    - react-app's own `WithStatement` restriction is kept.

#### Changed

- `CLAUDE.md` _Working conventions_: a line pointing at the new rule.
- `.bitbucket/pull-request-template.md`: a backend-driven-layout checkbox under _Backend / API contract impact_.

#### Notes

- Verified: `eslint src/` passes with zero warnings on this branch. The guard fails on the pre-WLA-458 Series screen (the `GetContentCollectionUseCase` import and both hardcoded TRAY URLs) and on a probe file with a `/PAGE/` literal and a `GetPageUseCase` import.
- Backend finding recorded in the rule: on demo-api, `/PAGE/DETAILS/VOD/{id}` and `/PAGE/DETAILS/PROGRAM/{id}` return a single bare `CONTENT_ITEM`, not a list of containers. VOD and Programme details stay temporary exceptions until the UI Builder configures those pages.

### feat/WLA-458-series-page-containers — 2026-10-15 (Series details from backend PAGE containers)

The Series details route now fetches `/PAGE/DETAILS/GROUP_OF_BUNDLES/{id}` and renders it through `ContentPageComponent → MapContentCollection`, like the entity pages (WLA-363). Before this, it hardcoded the seasons/episodes TRAY URLs and read the hero from `location.state`, so a deep link or refresh showed no hero. The backend returns three containers: `content_detail` (a `BUNDLE_ITEM` hero), `INCLUDED_ITEM` (the first episode, `actionType: PLAY`) and `LIST_VIEW` (seasons).

#### Added

- **`src/ui/content_page/SeriesPlayback.tsx`** — `SeriesPlaybackProvider` / `useSeriesPlayback`. The hero, first-episode and seasons containers are separate collections, so the player state, `VideoPlayerOverlay` and `StreamErrorAlert` moved out of the screen into a context scoped to the series screen. This is not a state library: `GlobalContext` is still the only global store.
- **`src/ui/content_page/SeriesDetailsContentItem.tsx`** — the `VideoDetails` hero for a `BUNDLE_ITEM` with `contentType GROUP_OF_BUNDLES`. Play starts the INCLUDED_ITEM episode and is hidden until that episode loads.
- **`src/ui/content_collection/IncludedItemCollection.tsx`** — draws nothing. It publishes its item as the hero's Play target, so the page looks the same as before (decision on WLA-458).
- **`src/ui/content_collection/SeasonEpisodesCollection.tsx`** — the season `Select` / single-season heading and the episode cards, moved from the old screen. It reuses the container's own fetch for the first season and fetches later seasons on selection.
- **`src/ui/content_page/seriesHelpers.ts`** — poster, label and duration helpers shared by the above.
- `ISeasonSource` and `ICompositeContainer.seasons` (`domain/content_page/Containers.ts`). `PageRepository` parses `metadata.filter_retrieveItems`. Bad JSON gives `[]` and a warning.
- `seriesPageUrlFor(pathname)` (`detailsRoute.ts`) — accepts only a plain id segment before it is spliced into the API URL.

#### Changed

- `SeriesDetailsScreenComponent.tsx` is now a thin wrapper around `ContentPageComponent`, like `EntityDetailsScreenComponent`. The hardcoded `seasonsUrl` / `episodesUrl` and the `location.state` read are gone. `ScreenLayout` keys it by pathname and passes `screenState`.
- `MapContentCollection` dispatches `INCLUDED_ITEM` and `LIST_VIEW` and suppresses their generic headers. `ContentDetailCollection` dispatches `BUNDLE_ITEM`.

#### Notes

- Season URIs from `filter_retrieveItems` are used as the backend sends them. They have no `orderBy=episodeNumber`, which the old code appended. The backend order matched `episodeNumber` in all 8 LINDEMARC seasons checked.
- The LINDEMARC `filter_parentId=0` issue the ticket mentions did not reproduce on 2026-10-15: the first 40 LINDEMARC series all carry real season ids.
- Verified in the browser on LINDEMARC: deep link and refresh, card click from Home, a 4-season switch (`1700001889`), hero Play, episode Play and Trailer, and the malformed-id fallback.

### feat/WLA-447-html-layout — 2026-10-14 (HTML_LAYOUT blocks on entity pages)

Entity pages now render `HTML_LAYOUT` containers: CMS-authored blocks such as Statistics, Results, Shot Map, Match Timeline and Ranking. They're inline in the PAGE response, with `metadata.htmlText` holding base64 HTML. The `AVS_BASE` region returns none; `LINDEMARC` does (athlete `ATH800017`, team `TEAM102`, event `EVT999001`).

#### Added

- **`dompurify` ^3.4.17** (runtime dependency, about 20 KB gzipped). Backend HTML is a string injection surface (`.claude/rules/abstraction-layer.md`), and the POC injects it unsanitised. It adds no transitive dependencies.
- **`src/ui/elements/sanitizeHtml.ts`** — a private DOMPurify instance:
    - It keeps the HTML and SVG profiles. `FORCE_BODY` stops the leading `<style>` being dropped.
    - It forbids `iframe`/`form`/`object`/`embed`/`base`/`meta`/`link`.
    - It empties a `<style>` containing `@import`/`expression()`/`javascript:`. It tests after CSS escapes are decoded, so `@\69mport` is caught.
    - Link `href`s (HTML and SVG `<a>`, `href` and `xlink:href`) are limited to `http(s)://`, root-relative paths and `#`. `/\host` counts as protocol-relative and is rejected.
    - Anything it strips is logged with `console.warn`.
    - Verified lossless on all 6 LINDEMARC blocks. Script, event-handler, `javascript:`, protocol-relative and `data:` links are removed.
- **`src/ui/content_collection/HtmlContentCollection.tsx`**:
    - The title is the backend `label` as `wl-text-heading-sm`. The sanitised HTML goes into a shadow root, so the block's own `<style>` and the app's CSS can't reach each other.
    - An empty `htmlText` renders nothing, e.g. the athlete page's "Team" block.
    - Link handling:
        - `http(s)` links open in a new tab with `noopener`.
        - Region-prefixed in-app links (`/LINDEMARC/PAGE/DETAILS/ENTITY/…`) go through the router.
        - Unmapped links are blocked, with a warning.
        - `#` anchors scroll within the shadow root and don't touch the router history.
    - If `htmlText` isn't valid base64, the block is hidden and a warning is logged.
- **`src/ui/styles/content_page/htmlContentCollection.css`** — outer rhythm only, using tokens.
- **`src/ui/content_page/entityRoute.ts`** — `entityRouteFromHref(href)` strips the leading region segment, then reuses `entityRouteFor`.
- **`src/repositories/common/Helpers.ts`** — `decodeBase64Utf8`. Plain `atob` mangles non-ASCII.
- **`response_examples/page_entity_html_layout.json`** — a trimmed LINDEMARC athlete page (one populated and one empty `HTML_LAYOUT`).

#### Changed

- **`src/repositories/content_page/PageRepository.ts`**:
    - `retrieveItems` is now optional, and the mapper guards it.
    - Before this, a container without it threw, and the whole page showed "Network error".
    - The mapper also decodes `metadata.htmlText` into the new `CompositeContainer.html` field (`src/domain/content_page/Containers.ts`).
- **`src/ui/content_collection/MapContentCollection.tsx`** — added a `HTML_LAYOUT` case. Before, the block fell through to an empty SmallCards carousel.

#### Notes

- Follow-ups:
    - D-pad focus can't reach links or `<details>` inside shadow roots (`useTvNavigation.ts`; P3-R-6).
    - App routes are hardcoded to `/AVS_BASE` while the API region comes from config.
    - The backend sends an identical `plainText` alongside `htmlText`; only `htmlText` is used, as in the POC.
    - Known sanitiser limits, all acceptable for first-party CMS content:
        - CSS `url(https://…)` isn't blocked, so a block can load remote images or fonts.
        - A `:host { position: fixed }` rule can let a block overlay the app.
        - Middle- and ctrl-clicks on links skip the router handler, because there's no `auxclick` listener.
        - An `HTML_LAYOUT` that also carries an `onClick` or `onTitleClick` action would trigger a TRAY fetch through `CompositeContainer.applyAction`. Not seen in the samples.

### dev — 2026-10-14 (athletes rail on sports page + athlete details hero, WLA-376)

Athletes now appear in `LARGE_CARDS` rails on the sports page and the athlete entity details page renders the `SportsmanDetails` hero.

#### Added

- **`src/domain/content_page/SportsEntity.ts`** — adds `IAthleteEntity` (`role`, `teamName`, `nationality`, `sportName`), parallel to the existing `ITeamEntity`.
- **`src/ui/content_page/AthleteDetailsContentItem.tsx`** — maps `content.athlete` to the `SportsmanDetails` organism. Guards on `athlete === undefined` (same pattern as `TeamDetailsContentItem` guards on `team`). Every text prop is passed explicitly via `text(key, fallback)` to suppress organism demo copy.

#### Changed

- **`src/domain/content_page/Content.ts`** — `IContent` gains `athlete?: IAthleteEntity`; `Content` class gains a matching constructor parameter. Removes the WLA-366 placeholder comment.
- **`src/repositories/content_page/ContentCollectionRepository.ts`** — `MetadataDTO` gains `role?` and `nationality?`. Adds `toAthlete()` (parallel to `toTeam()`); `toContent()` passes it as the last constructor argument.
- **`src/repositories/common/RepositoriesConfig.ts`** — `makePoster` guards against a null `imageId` (backend may omit the field for some sports entities), returning an empty URL rather than crashing on `null.startsWith`.
- **`src/ui/content_collection/ContentDetailCollection.tsx`** — adds `ATHLETE_ITEM` → `AthleteDetailsContentItem` case.
- **`src/ui/content_collection/LargeCardsContentItem.tsx`** — derives `subtitle` from `content.athlete.role · content.athlete.teamName` (athletes show e.g. "Attacking Midfield · 1. FC Köln"). VOD/series/team cards have no `athlete` entity, so `subtitle` stays `undefined`.

### feat/WLA-363-team-details — 2026-10-13 (session 3 of 3: card navigation, polish)

Sports entity cards now open the entity route (team, athlete, and event alike). Event cards show their real start date, and entity cards no longer show a favourite heart.

#### Changed

- **`src/ui/content_page/entityRoute.ts`** adds `entityRouteForContent(content)`. It reads the card's `onClick` action URI and returns the validated `/AVS_BASE/PAGE/DETAILS/ENTITY/{TYPE}/{id}` route, or `undefined`. This is the single lookup both card types share.
- **`src/ui/content_collection/LargeCardsContentItem.tsx`, `SmallCardsContentItem.tsx`**:
    - Entity items `navigate(route)` with no router state. Everything else keeps the `contentDetailsUrlFor` VOD/series path.
    - `FavoriteAction` is hidden for entity items, since they have no `contentId`.
    - Small cards drop the date subtitle when the start time is invalid, instead of rendering "Invalid Date".
- **`src/repositories/content_page/ContentCollectionRepository.ts`** maps `EVENT_ITEM.metadata.eventStartDateTime` (epoch ms) to `airingStartTime` via `toAiringStart`. A missing value maps to an invalid date, not 1970. It reuses `defaultNumber`.
- **`src/ui/content_page/TeamDetailsContentItem.tsx`** — the sport chip is hidden (`iconLabels={false}`). The library has no trophy or sport glyph, and the session 2 `star` stand-in read as a rating, so users tried to click it.
- **`docs/ui-library-adoption.md`** — `TeamDetails` added to "Already adopted".

#### Notes

- `RailContentCollection` / `CarouselContentCollection` are unchanged. Entity items never reach them: on demo-api, the team, athlete and event pages use only `LARGE_CARDS` / `SMALL_CARDS`, and home has no ENTITY trays. The grid collections reuse the two card items, so "See all" will inherit the routing.
- `genreTags` needed no change, because the mapper already defaults a missing `genres` to `[]`.
- Follow-ups, none of them in scope:
    - Upstream: the hardcoded Panel `play` icon, plus the English "TEAM" badge text and its aria-label in `TeamDetails`.
    - The POC's `extendedMetadata` chips (`courtType` / `matchFormat`).
    - "See all" (`onTitleClick` → WALL_PAGE grid).
    - `SportsmanDetails` hero is WLA-366.
    - No event details component exists, so the event route renders rails only.

### feat/WLA-363-team-details — 2026-10-12 (session 2 of 3: TeamDetails hero)

The `content_detail` hero now renders the `TeamDetails` organism from `@white-label/ui-react` for `TEAM_ITEM`, matched to Figma 1342-9828 (desktop) and 1342-9830 (tv). What goes where follows the POC's TEAM_ITEM config:

- the sport is the only chip
- the "Team Information" panel holds Team and Coach rows
- the "Description" panel shows the description, or "Not Available" when there is none

#### Added

- **`src/ui/content_page/TeamDetailsContentItem.tsx`** maps `content.team` and the HM poster to `TeamDetails`.
    - `device` comes from `useDeviceMode()`.
    - The info `List` is a 2-column grid on desktop and stacked on tv. ListItem colours are inverted, so the label goes in `title` and the value in `subtitle`.
    - Every text prop is passed explicitly, so no organism demo copy leaks.
    - Strings go through `text(key, fallback)` using the POC's dictionary keys (`label_team_informations`, `label_team_name`, `label_coachNames`, `label_description`, `card_metadata_longDescription__unavailable_data`).
    - No app CSS: the organism owns all of the hero's layout.

#### Changed

- **`src/ui/content_collection/ContentDetailCollection.tsx`** — `TEAM_ITEM` → `TeamDetailsContentItem`. `ATHLETE_ITEM` stays reserved for WLA-366.

#### Notes

- Upstream organism issues, which can't be fixed app-side:
    - both Panel title rows hardcode a `play` icon, which the Figma render doesn't show
    - the "TEAM" badge text and its `aria-label` are hardcoded English
- `organizationName` is mapped but not shown, matching the POC. The POC's extra chips (`extendedMetadata.courtType` / `matchFormat`) aren't mapped, and team 44 has neither field.

### feat/WLA-363-team-details — 2026-10-12 (session 1 of 3: route + data layer)

WLA-363 adds the Sports Team details page. It is a backend-driven page at `/AVS_BASE/PAGE/DETAILS/ENTITY/{TYPE}/{id}`. The route mirrors the backend's `/PAGE/DETAILS/ENTITY/...` URI, so the containers of the PAGE response render through the existing `ContentPageComponent` → `MapContentCollection` pipeline, the same one Home uses. This session lands the route and the data layer: the rails render, and the `content_detail` hero is still blank (the `TeamDetails` organism comes in session 2).

#### Added

- **`src/ui/content_page/entityRoute.ts`** — `ENTITY_DETAILS_PREFIX`, `isEntityDetailsPath`, `entityPageUrlFor`, `entityRouteFor`. The TYPE and id segments are validated before the path is spliced into the API URL.
- **`src/ui/content_page/EntityDetailsScreenComponent.tsx`** — passes a `RAILS_PAGE` `RetrieveItems` for the page URI to `ContentPageComponent`. A malformed path shows an error `Alert`.
- **`src/ui/content_collection/ContentDetailCollection.tsx`** — the `content_detail` dispatcher. It picks the hero by the layout of the fetched item (`TEAM_ITEM`, and `ATHLETE_ITEM` for WLA-366), because the container layout is identical for every entity type. It renders nothing for now.
- **`src/domain/content_page/SportsEntity.ts`** — `ITeamEntity`.

#### Changed

- **`src/App.tsx`**, **`src/ui/screen/ScreenLayout.tsx`**:
    - New `/AVS_BASE/PAGE/DETAILS/ENTITY/*` standalone route. The NavBar treats it as a details route.
    - The screen is keyed by pathname. Container ids repeat across entity pages and collections load once, so without the key, team → team navigation would show stale rails.
- **`src/ui/content_collection/MapContentCollection.tsx`** — `content_detail` case. The rail header is suppressed for it.
- **`src/repositories/content_page/ContentCollectionRepository.ts`**, **`src/domain/content_page/Content.ts`**:
    - Sports items have no `title`, so the label comes from `teamName`, `name` or `eventName`, chosen by item layout. Athletes also carry `teamName`, so a plain fallback chain would mislabel them.
    - `TEAM_ITEM` items fill an optional `Content.team`.

#### Notes

- Event cards show "Invalid Date", because `EVENT_ITEM` has `eventStartDateTime`, not `airingStartTime`. Card navigation for entity items is not wired yet either. Both are session 3.

### fix/home-hero-banner-hover — 2026-10-09

The home hero carousel now reveals each slide's title, tags, star rating and description on hover, matching the ui-react Storybook Banner Carousel. `Banner` is a controlled-state molecule: its header and footer stay `display: none` until `state` is `hover` (desktop) or `focused` (TV). The app never passed `state`, `tags` or `rating`, so only the image and scrim showed.

#### Changed

- **`src/ui/content_collection/CarouselContentCollection.tsx`** — each slide is now a `HeroBanner` with its own hover state (`useHoverWithDelay(0)`, as in `SmallCardsContentItem`) and focus state.
    - Desktop: hover or keyboard focus → `hover`. TV: focus → `focused`.
    - Tags: PC level, genres, then duration (max 4; `sm` on TV, `md` on desktop).
    - Rating: static `Icon` stars in one `role="img"` wrapper. The story's `IconButton`s aren't used because they are interactive and must not nest inside the banner's `role="button"`.
    - No action buttons. The whole banner still opens details on click, and on Enter through `useTvNavigation`.
    - The hero no longer shows the container label ("Hero Carousel") as a heading. Figma's Banner Carousel has no title row, and with the arrows now overlaid on the slides (`navPosition="inside"`, the library default for banners) the title stood alone above the hero. The label is passed as the section's `aria-label` instead, only when non-empty, so the library's fallback name is never overridden with nothing. Card rails keep their titles.
- **`src/ui/styles/content_page/contentCollectionsList.css`** — **temporary** 16px top gap (`--space-padding-sm`) between the NavBar and the first content row, desktop only. There is no Desktop Home design yet, and the hero sat flush under the NavBar. The value follows the TV design's spacing. Revisit when the Desktop Home frame lands. TV is unchanged.
- **`src/ui/styles/screen/search.css`** — resets that top gap inside `.avs-search-results`, so the search screen is unchanged (SearchArea owns the spacing above its results).
- **`src/ui/config/UiConfig.ts`** — new `durationToText(seconds)`, moved out of `DetailsScreenComponent`'s private `formatDuration` (now imported there).

#### Notes

- `SeriesDetailsScreenComponent` still has its own `formatDuration`. It rounds differently (whole minutes first), so it was left alone.
- The demo-api backend returns `starRating: 0` and no `pcLevelVod` for the current hero items, so on that backend only the genre and duration tags and no stars show. The code paths render once the data is present.

### chore/WLA-443-bitbucket-rest-api-pr-creation — 2026-10-08 (adopt Bitbucket REST-API PR creation)

Unify PR creation across the three documented repos: `white-label-ui` already opened PRs
through the Bitbucket REST API with a dedicated HTTP access token, while this repo routed
developers and agents to the Bitbucket web UI. Both now use the same token-based REST flow.
Sister change: **white-label-multiplatform**, branch `chore/WLA-443-bitbucket-rest-api-pr-creation` (WLA-443).

#### Added

- **`.env.bitbucket.example`** — committed template for the gitignored `.env.bitbucket.local`.
  Documents token creation (Manage account → HTTP access tokens, **Repository: WRITE** — Read
  gives an identical 401 on PR creation), `wla`-project scoping (one project-scoped token
  covers all WLA repos; each repo still needs its own file because `BITBUCKET_REPO` differs),
  and why the API token is **not** interchangeable with the git credential.
- **`CONTRIBUTING.md` → "Opening a pull request"** — one-time token setup, the exact `curl`
  for `POST /rest/api/1.0/projects/$BITBUCKET_PROJECT/repos/$BITBUCKET_REPO/pull-requests`
  with the `pr.json` body shape, and a 401 triage order (file sourced → token has Repository
  WRITE → token still live) stating that a 401 is not transient and must not be retried.

#### Changed

- **`.gitignore`** — ignore `.env.bitbucket.local` (confirmed with `git check-ignore -v`).
- **`CONTRIBUTING.md` → Branching** — "create PRs via the Bitbucket web UI" replaced with the
  REST-API path; the web UI is kept only as an explicit fallback for developers without a
  token yet.
- **`CLAUDE.md` → Working conventions** — new bullet stating PRs go through the REST API, not
  the web UI and not `gh`, with the two-credentials warning and the 401 triage order.
- **`.claude/settings.json`** — the `PostToolUse` git-push hook now tells the agent to open the
  PR via the REST API (source `.env.bitbucket.local`, `Authorization: Bearer`, never print the
  token, 401 triage), keeping the web-UI link as the no-token fallback.
- **`.bitbucket/pull-request-template.md`** — the header comment pointed at the web UI, which
  contradicted the rest of this change; it now points at the REST-API flow with the web UI as
  the no-token fallback.

#### Notes

- **No change to git authentication.** `git clone`/`git push` continue to use Git Credential
  Manager (Keychain on macOS); this token only affects the REST-API PR-creation path.
- **Verified:** both `.claude/settings.json` files re-parse as valid JSON, and the modified
  hook command was executed against a simulated `git push` payload — it emits valid JSON and
  stays silent for non-push commands. `git check-ignore -v` confirms the new ignore rule.
  The PR for this branch was itself opened through the REST API, which is the end-to-end check.
- No tests were added or run; neither repo has meaningful test coverage and there is no CI.

### feat/WLA-435-player-package — 2026-10-07

Take the video player from the white-label-player repo (`@white-label/player-web`) and choose Bitmovin or Shaka at build time (WLA-435, session 5). Supersedes react PR 71 (WLA-406): its Bitmovin + ui-react controls now live in the player package, and its react-side changes are re-applied here by hand on top of PR 74 (resume).

#### Added

- **`@white-label/player-web`** dependency (`file:../white-label-player/web`, copied via `install-links=true`, so React and ui-react resolve from this app's `node_modules` only) plus `player:build` / `player:clean` / `player:sync` scripts mirroring `ui:*`.
- **`REACT_APP_PLAYER`** build-time setting (`bitmovin` default, or `shaka`; documented in `.env.example`). `LoadPlayer()` in `src/modules/ContentPageModule.ts` replaces `GetPlaybackBridge()`: a constant-condition `import()`, so only the chosen player is built, as a lazy chunk fetched on first playback. Verified with `npm run build`: `bitmovin` → one 589 kB player chunk and no Shaka code; `shaka` → one 298 kB chunk and no Bitmovin code.
- **`scripts/react-scripts.js`** — `npm start` / `npm run build` wrapper. With the variable unset, webpack can't fold the condition and built both players; the wrapper loads CRA's `.env` files, defaults to `bitmovin`, and fails on unknown values (e.g. `Shaka`).
- **`src/services/player/BitmovinPlayer.ts`**, **`ShakaPlayer.ts`** — app-side adapters: pass `REACT_APP_BITMOVIN_KEY` as `licenseKey` (the library never reads env vars) and load `@white-label/player-web/bitmovin.css`.
- **`IPlayer`** in `src/domain/content_page/PlayerBridge.ts` — `{ createBridge(), Controls? }`; `Controls` is the Bitmovin control bar, absent for Shaka.

#### Changed

- **`src/domain/content_page/PlayerBridge.ts`** — `IPlaybackBridge` / `IPlaybackTime` / `Unsubscribe` are re-exported (type-only) from the player package. PR 74's `getCurrentTime` / `getDuration` / `onPlaybackFinished` are replaced by the package's `getTime()` / `onEnded()`.
- **`src/ui/elements/VideoPlayerOverlay.tsx`** — PR 71's app half: full-bleed dialog, `IconButton` Back, focus trap + restore, Escape to close, stream-session keepalive, `text()` labels and `useDeviceMode()` passed to the package's `Controls` (rendered once the bridge exists; nothing extra for Shaka). PR 74's resume ported to the library bridge: `startTime` goes to `mount`, the 5 s poll reads `getTime()`, the cleanup reads `getTime()` before `destroy()` for the ≥ 5/6 near-end check, `onEnded` is unsubscribed in cleanup. No more auto-fullscreen on mount / close on fullscreen exit (as in PR 71).
- **`src/ui/styles/elements/videoPlayerOverlay.css`** — PR 71's token-only layout (no hex / `rgba()` / `aspect-ratio`), without its `.wl-time-slider::before` rule (now in the package's `bitmovin.css`). `isolation: isolate` on `.vpo-video` — Shaka's `z-index: 1` controls layer otherwise covered the Back button.
- **Details / Programme / Series screens** — PR 71's header split: `seriesTitle` + `title` (Trailer label, channel name, `S1 E1 - …` episode label via a new `episodeLabel` helper), and the Series screen forwards the season's episodes to the in-player Episodes panel.
- **Docs** — `README.md` (Video player section), `CLAUDE.md` (build commands), `.claude/rules/ui-library-adoption.md` (player controls come from the package; the four "missing" barrel types are exported — re-checked), `docs/ui-library-adoption.md` §6 marked done.

#### Removed

- `bitmovin-player` direct dependency (now transitive via the player package), `src/services/player/BitmovinPlayerService.ts`, vendored `public/bitmovinplayer-ui.js` / `.css` and their `public/index.html` comment, the `bitmovin-player/modules/*` declaration in `src/declarations.d.ts`.

#### Notes

- Needs the white-label-player branch `feat/WLA-435-player-web-bitmovin` (S3 + S4 + S4b, not yet merged) checked out next to this repo and built (`npm run player:sync`).
- Validation (demo backend): **Bitmovin** — trailer, Play/Resume (anonymous: MASTER falls back to the trailer), a series episode and a programme's Watch Live all play (the live one reported a fixed duration, so likely the dev demo-stream fallback, and its live slider state wasn't seen); play/pause, skip ±10 s, slider seek, mute/unmute, settings toggle, Episodes panel with real episodes (Series), Escape and Back close; player and `<video>` removed on close; Resume starts at the saved position; natural end and closing past 5/6 bring back Play; no console warnings or duplicate-React errors. **Shaka** (first run in react) — plays with the default Shaka UI, Back reachable, teardown clean, Resume starts at the saved position, `onEnded` and near-end close clear it. **DRM not tested in either mode** (no `REACT_APP_BITMOVIN_DRM_URL` locally). Fullscreen button not exercised (needs a real user gesture).
- Pre-existing (PR 74), not changed: the 5 s poll keeps running after `onEnded`, so it re-saves the end position until close; and Details saves trailer progress as the movie's bookmark. On the anonymous demo Play falls back to the trailer, so Resume can stay visible after a trailer ends until the overlay closes.
- Out of scope, noted: `useWatchProgress` (in `src/ui/`) calls the `modules/` factory directly, like `useFavorite`. The runtime `IPlayerBridge.default` from `/CONFIG/APP` (`ConfigApp.ts`) overlaps the new build-time setting and is left untouched.

### WLA-268-resume-button — 2026-10-05 (session 2)

Replace localStorage watch-progress store with AVS bookmark API

#### Added

- **`src/repositories/content_page/BookmarkRepository.ts`** — implements `IBookmarkRepository`; `fetchBookmark` calls `GET /USER/BOOKMARKS?deviceId=...` and filters by `contentId` to return `startDeltaTime` in seconds; `saveBookmark` calls `POST /CONTENT/USERDATA/VOD/{contentId}?deviceId=...` with `{"bookmark":{"startDeltaTime": position},"deltaThreshold": position − previousPosition}`.
- **`src/usecases/content_page/VodBookmarkUseCase.ts`** — thin use case wrapping `fetch` and `save` on `IBookmarkRepository`.
- **`IBookmarkRepository`** added to `src/usecases/RepositoryInterfaces.ts`.
- **`GetVodBookmarkUseCaseFactory()`** added to `src/modules/ContentPageModule.ts`.

#### Changed

- **`src/ui/elements/useWatchProgress.ts`** — localStorage implementation removed; replaced with `GetVodBookmarkUseCaseFactory().fetch()` on mount (seeds `savedSeconds` and the `deltaThreshold` baseline from `startDeltaTime`) and fire-and-forget `.save()` on each poll / player exit. `isLoading` guard keeps `canResume` false until the initial API response arrives.

### WLA-268-resume-button — 2026-10-05

Add VOD resume button; fix FavoriteButton `size` prop type error

#### Added

- **`src/ui/elements/useWatchProgress.ts`** — new localStorage-backed hook tracking watch position per content item. Lower threshold: 30 s. Upper threshold: 5/6 of content watched → entry cleared. Uses React state (`useState`) so `save`/`clear` trigger immediate re-renders, avoiding stale localStorage reads in the render that unmounts the player overlay.
- **`IPlaybackBridge.getCurrentTime()`**, **`getDuration()`**, **`startTime?` on `mount()`** — seek and progress-polling infrastructure added to the domain interface (`src/domain/content_page/PlayerBridge.ts`) and implemented in `BitmovinPlayerService`. `getDuration()` delegates to `player.getDuration()`, which the player always knows at runtime — avoids reliance on `content.duration` that backends commonly omit.
- **`VideoPlayerOverlay`** — new props `startTime?`, `onTimeUpdate?`, `onEnded?` wired to the player bridge. Polls `getCurrentTime()` every 5 s. Cleanup compares exit position against player-reported duration: if ≥ 5/6 reached on manual exit, calls `onEnded` (clears progress) instead of `onTimeUpdate` (saves progress).

#### Changed

- **`src/ui/content_page/DetailsScreenComponent.tsx`** — Play button replaced by Resume (with saved seek position) when `canResume` is true; mutually exclusive, single button slot. `useWatchProgress` wired with `saveProgress` → `onTimeUpdate` and `clearProgress` → `onEnded`.

#### Fixed

- **`DetailsScreenComponent`** / **`SeriesDetailsScreenComponent`** — `FavoriteButton size` changed from `'xl'` to `'lg'`; `FavoriteButtonSize` only accepts `'sm' | 'md' | 'lg'`.

### feat/WLA-320-programme-details-figma-align — 2026-10-05 (session 3)

[WLA-320](https://acn-avs.atlassian.net/browse/WLA-320) — Consume library WLA-421 / WLA-422 implementations: round action buttons and FavoriteButton slot on VideoDetailsLive.

#### Changed

- **`src/ui/content_page/ProgramDetailsScreenComponent.tsx`**: passes `actionsShape="round"` (WLA-421 new prop) and `favoriteButton={<FavoriteButton .../>}` (WLA-422 new slot) to `VideoDetailsLive`. Favourite removed from the `actions[]` text-label array. Matches the pattern in `DetailsScreenComponent` / `VideoDetails`.
- **`.claude/rules/ui-library-adoption.md`**: updated WLA-421/WLA-422 traps from "library gaps / no workaround" to document the new API (`actionsShape`, `favoriteButton` slot on `VideoDetailsLive`).

### feat/WLA-320-programme-details-figma-align — 2026-10-05 (session 2)

[WLA-320](https://acn-avs.atlassian.net/browse/WLA-320) — Post-review fixes: switch `expandedDetails` to plain spans (consistent with VOD details pattern), harvest library API gaps, file library tickets for both.

#### Changed

- **`src/ui/content_page/ProgramDetailsScreenComponent.tsx`**: `expandedDetails` switched from `<List>`+`<ListItem>` to plain `<span>` elements matching `DetailsScreenComponent.buildExpandedDetails`. The organism's `wl-video-details-live__expanded-details` wrapper already provides `flex-column` layout; List added unwanted padding on top. Removed unused `List`/`ListItem` imports.
- **`.claude/rules/ui-library-adoption.md`**: harvested three new library API traps from WLA-320 investigation: (1) `VideoDetailsLive.actions` hardcodes pill shape — do not work around with CSS, flag as library gap; (2) `VideoDetailsLive` has no `favoriteButton` slot (unlike `VideoDetails`); (3) `expandedDetails` on both organisms must use plain elements, not `List`/`ListItem`.

#### Notes

- Library gaps [WLA-421](https://acn-avs.atlassian.net/browse/WLA-421) (`actionsShape` prop) and [WLA-422](https://acn-avs.atlassian.net/browse/WLA-422) (`favoriteButton` slot) implemented in the library and consumed: action buttons now round, favourite renders as `FavoriteButton` atom.

### feat/WLA-320-programme-details-figma-align — 2026-10-05

[WLA-320](https://acn-avs.atlassian.net/browse/WLA-320) — Programme details: adopt `List`/`ListItem` for detail grid, replace raw error `<p>` with `StreamErrorAlert`, migrate all hardcoded English strings to `text()`.

#### Changed

- **`src/ui/content_page/ProgramDetailsScreenComponent.tsx`**
    - `expandedDetails` block: `<dl>/<dt>/<dd>` with hardcoded `#888`/`#fff` hex replaced with `<List>`+`<ListItem title={label} subtitle={value} />` from `@white-label/ui-react`. Eliminates the last two hardcoded hex values in this file.
    - Stream error state: raw `<p style={{color:'#ff9ea4'...}}>` replaced with `<StreamErrorAlert>` (same wrapper `DetailsScreenComponent` uses). `handleAlertClose` added to reset `playerState` + `errorMessage` on dismiss — the previous render had no dismiss path.
    - All 17 hardcoded English strings migrated to `text(key, fallback)` from `src/ui/config/text.ts`. New keys: `programme_detail_channel`, `programme_detail_airing`, `programme_detail_duration`, `programme_detail_min`, `programme_detail_episode`, `programme_detail_genre`, `programme_detail_rating`, `programme_detail_features`, `programme_detail_recordable`, `programme_detail_unavailable_title`, `programme_detail_unavailable_desc`, `programme_detail_back_to_guide`, `programme_detail_loading`, `programme_detail_watch_live`, `programme_detail_saved`, `programme_detail_save`, `programme_detail_live`, `programme_detail_no_info`, `programme_detail_min_left`, `programme_detail_starts_in`, `programme_detail_stream_error`, `programme_detail_stream_error_entitlement`.

### fix/configurable-api-proxy-target — 2026-10-05

Rationale: the TV Guide at `/AVS_BASE/EPG` showed "No channels available" locally while the demo site (`demo.avs-accenture.com/AVS_BASE/TV-GUIDE/`) worked. This was not an EPG code regression. Commit `98c7a41` (2026-07-21) pointed the `/avs_api` dev proxy at `varnish.test.pres95.presales-eks.avs-accenture.com` to get the Podcast/Media tabs. That backend returns live channels but `/TRAY/SEARCH/PROGRAM` comes back with `total: 0` for every instant, so every channel row is empty and `TvGuideComponent` hides empty rows. The demo backend (`demo-api.avs-accenture.com`) returns programmes for the same requests.

#### Changed

- **`src/setupProxy.js`**: the `/avs_api` target now comes from the `AVS_API_TARGET` env var (CRA loads `.env.local` into the dev-server process). The default stays pres95 (`https://varnish.test.pres95.presales-eks.avs-accenture.com`), the team's current backend for the Podcast/Media tabs. Non-`https://` values throw at dev-server start, and an override logs the active target once. The var is deliberately not `REACT_APP_`-prefixed, so it never reaches the client bundle.
- **`.env.example`**: documents `AVS_API_TARGET`. It sets the pres95 default explicitly and has the demo backend (`https://demo-api.avs-accenture.com`, with EPG data) as a commented-out alternative.
- **`README.md`**, **`CLAUDE.md`** (§ API configuration): describe the override and note that backends differ in content.

#### Notes

- **The default backend still has no EPG data.** To work on the TV Guide, set `AVS_API_TARGET=https://demo-api.avs-accenture.com` in `.env.local` and restart `npm start`.
- `/avs_config` still points at `demo.avs-accenture.com`. It is unchanged because the pres95 setup already ran with demo config.

### chore/ui-adoption-audit-tickets — 2026-10-01

Rationale: re-audit of hand-rolled UI against `@white-label/ui-react` (library `main` @ `1710e19`) after WLA-316 → WLA-321 landed. Every remaining item outside the EPG screen and Programme details (WLA-320) now has its own Jira ticket, and the adoption catalogue reflects the current code.

#### Added

- **`.claude/agents/delivery.md`**: new Haiku-model agent that mechanically creates and amends WLA Jira tickets from a fully specified JSON spec written by the caller. It reuses the `create-jira-ticket` / `amend-jira-ticket` skill field mappings, is non-interactive (skips skill Steps 0 and 5), and documents Jira's counter-intuitive `Blocks` link direction (blocker goes in `inwardIssue`). Hand-back is capped at 15 lines. A new agent type registers only on the next session start, so this run used a general-purpose agent on Haiku reading the same definition.

#### Changed

- **`docs/ui-library-adoption.md`**: refreshed to the 2026-10-01 audit. Scorecard is 66 library components, 22 adopted (was 47 / 9). Sign-in, cards, VOD details and series sections are marked done, with ticket refs. EPG line numbers re-verified, and the "no `Tabs` container" claim corrected (it now exists). §6 player rewritten: Bitmovin's stock UI is still in use, and the available library player components are listed. §8 dead-code list updated; hex drift is down from 105 values in 17 files to 4 files. The four "missing barrel types" are marked resolved (all now exported). New **Ticket map** section.

#### Notes

- Jira tickets created: [WLA-406](https://acn-avs.atlassian.net/browse/WLA-406) player controls + overlay, [WLA-407](https://acn-avs.atlassian.net/browse/WLA-407) NavBar submenu, [WLA-408](https://acn-avs.atlassian.net/browse/WLA-408) episode list → `MediaList`, [WLA-409](https://acn-avs.atlassian.net/browse/WLA-409) live grid states + stray `;`, [WLA-410](https://acn-avs.atlassian.net/browse/WLA-410) startup splash, [WLA-411](https://acn-avs.atlassian.net/browse/WLA-411) live grid → `Grid` (blocked by library [WLA-404](https://acn-avs.atlassian.net/browse/WLA-404) landscape Grid), [WLA-412](https://acn-avs.atlassian.net/browse/WLA-412) channel logo (blocked by library [WLA-405](https://acn-avs.atlassian.net/browse/WLA-405) Card logo slot), [WLA-413](https://acn-avs.atlassian.net/browse/WLA-413) clickable heading, [WLA-414](https://acn-avs.atlassian.net/browse/WLA-414) dead UI cleanup.
- [WLA-327](https://acn-avs.atlassian.net/browse/WLA-327) (missing barrel types) and [WLA-315](https://acn-avs.atlassian.net/browse/WLA-315) (adoption rule) are closed; the doc records both as resolved.
- Not edited, flagged instead: `.claude/rules/ui-library-adoption.md` §4 still lists the four barrel types as missing.

### feat/WLA-319-series-details-figma-align — 2026-10-01 (session 2)

[WLA-319](https://acn-avs.atlassian.net/browse/WLA-319) — episode card enrichment and post-library-update cleanup.

#### Changed

- **`src/ui/content_page/SeriesDetailsScreenComponent.tsx`** — Episode `Card` gains: `cardTitle` formatted as `S{n} E{n} - {episodeTitle}`, `description` from `longDescription`, `tags` (parental rating `Tag`, formatted-duration `Tag`, genre `Tag`s via `genreTags`), `actions` (play `IconButton` + inline `EpisodeFavoriteButton`). `EpisodeFavoriteButton` calls `useFavorite` directly with `shape="pill" size="md"` rather than reusing `FavoriteAction` (which is hardcoded `shape="round"`). Jira ticket [WLA-403](https://acn-avs.atlassian.net/browse/WLA-403) filed for the Chrome card-media aspect-ratio bug. VideoDetails series-level `FavoriteButton` size updated `tv:'md'→'lg' / desktop:'lg'→'xl'` to match Figma's 48 pt spec with the corrected library size scale.
- **`src/ui/styles/content_page/seriesDetails.css`** — `.series-episode-list` padding added (`space/padding/md` top+bottom, `space/padding/2xl` left+right). `.series-season-select` horizontal margin added (`space/padding/2xl`). `.series-episodes` confirmed no padding/margin. Three `.wl-card__media` width rules added as a Chrome flex/aspect-ratio workaround (WLA-403), then **removed** in the same session after the library fix (WLA-403 Change 1) landed — net diff is zero for those rules.
- **`src/ui/content_collection/FavoriteAction.tsx`** — Non-TV `FavoriteButton` size updated `'md'→'lg'` to maintain ~40px rendered size with the corrected library size scale (old MD rendered at ~40px due to missing `box-sizing: border-box`; new LG = 40×40 exactly). Optional `size` prop added (typed via `React.ComponentProps` to stay in sync with library union); callers that don't pass it get the device default.
- **`src/ui/content_page/DetailsScreenComponent.tsx`** — VideoDetails `FavoriteButton` size updated same as above (`tv:'md'→'lg' / desktop:'lg'→'xl'`).

#### Notes

- `FavoriteButton` size scale correction (library PR, merged 2026-10-01): SM 24px unchanged; MD corrected 28×28 (was ~40px); LG corrected 40×40 (was ~56px); XL new 48×48. `box-sizing: border-box` applied to button root — previously border was outside the stated size. Storybook stories in Card and VideoDetails updated to use corrected names.
- Card media aspect-ratio fix (library PR, WLA-403): `Card layout="list"` `.wl-card__media` now ships explicit `width` values per device (TV 165px, Desktop 273px, Mobile 132px) so Chrome's flex engine has an anchor for the `aspect-ratio: 3/2`. App-side workaround removed.

### feat/WLA-319-series-details-figma-align — 2026-09-30

[WLA-319](https://acn-avs.atlassian.net/browse/WLA-319) — align series details screen with Figma,
replace hand-rolled season tab strip and status paragraphs with library components.

#### Changed

- **`src/ui/content_page/SeriesDetailsScreenComponent.tsx`** — season tab strip (`role="tablist"` buttons) replaced by `Select` + `MenuItem` from the library; inline `role="tab"` / `aria-selected` / `data-active` / `series-season-tab*` classes removed. Three inline `<p className="series-status">` replaced by `Alert` components (loading/error/empty); `Alert` hardcoded `role="alert"` overridden to `role="status"` for polite announcements. Inline error `<p style={{ color: '#ff9ea4' }}>` replaced by `StreamErrorAlert` (same component used in `DetailsScreenComponent`). Outer `<div style={{ padding: '24px' }}>` replaced by `<section className="series-episodes">` (no `Panel` — Figma shows no bordered box). `VideoDetails as DetailsPage` alias dropped; JSX renamed to `<VideoDetails`. `text(key, fallback)` added for all new user-visible strings. Module-level `keepMenuItemKeyboardActivation` handler works around `Select`'s `onKeyDown` swallowing Enter/Space across the subtree. `seasonLabel` helper extracts display label logic.
- **`src/ui/styles/content_page/seriesDetails.css`** — rewritten to 3 layout-only rules: `.series-episodes` margin-inset, `.series-season-select` 216px width cap, `.series-episodes__heading` margin reset. All 8 previous rules removed (season tab strip, status/error paragraphs, outer container — all replaced by library components). No hex, no font-size, no `.wl-*` overrides.
- **`docs/ui-library-adoption.md` §5** — rows 193-195 (series screen) marked done (WLA-319); replacement column updated from `TabItem selected` → `Select + MenuItem` for the season strip, `<section>` for the wrapper. Row 190 updated to remove `SeriesDetailsScreenComponent` from the two-file inline error paragraph list (now handled by `StreamErrorAlert`).

#### Notes

- **Figma deltas declared:** episode section sits below the fold (not in the hero), episode cards are portrait where Figma shows horizontal list cards with synopsis, no star rating or crew rows (no domain source). `VideoDetails` has no series slot — upstream ticket needed for a dedicated slot.
- **A11y trade-off:** `Select` has no accessible name, the trigger `Input` is `aria-hidden`, and `SelectProps` does not extend HTML attributes (no `aria-label` pass-through). The old tablist was more accessible. User confirmed `Select` per Figma (figma.md:91-93); upstream library ticket raised.
- **`Select` keyboard workaround:** `keepMenuItemKeyboardActivation` stops propagation on Enter/Space only (not Escape) to counter `Select`'s `preventDefault` on those keys for its whole subtree.
- **Behaviour changes:** seasons fetch failure now shows an error `Alert` instead of silently hiding the section; zero-season result shows an info `Alert` instead of a bare heading. Both needed because the section always renders.
- **P3-R-6:** season `Select` is not D-pad reachable on TV — the old tab strip wasn't either; no regression.

### chore/agent-pipeline-cost-tuning — 2026-09-29

Post-mortem on the WLA-321 session's token cost (~11.2M tokens). Harvests the durable
findings out of the gitignored plan file and tightens the agent pipeline that produced it.

#### Added

- **`.claude/agents/planner.md`, `implementer.md`, `reviewer.md`** — now tracked. They were local-only under `.gitignore:32-35`, so every teammate re-derived them or worked without. They are generic (not tied to the four Figma-alignment tickets) and encode cost lessons from WLA-317 and WLA-321.

#### Changed

- **`.claude/rules/ui-library-adoption.md`** §4 — three findings promoted out of `.claude/work/WLA-321/plan.md` before that gitignored file is lost: there is no `Checkbox` component (it is `SelectIndicator type="checkbox"`, `aria-hidden` + `pointer-events: none`, `hover` is a prop); `Scrim`'s prop is `variant` not `style` and it is `position: absolute` (merged into the existing `Scrim` bullet); `Input`/`TextField` already provide the password eye toggle via `endIcon`/`onEndIconTap`, and no `eye-slash` glyph exists. All re-verified against `node_modules/@white-label/ui-react/dist/` at the cited line numbers, not copied on trust from the plan.
- **`.claude/rules/ui-library-adoption.md`** §5 — the "new UI text" constraint now points at `text(key, fallback)` (`src/ui/config/text.ts`) rather than `Dictionary.getText` directly, and states why calling `getText` raw renders blank labels.

#### Notes

- **`.claude/agents/planner.md`** — "Budget the plan file generously" asked for _"real prop names and values, not a description"_, which is what produced a plan containing the implementation. Replaced with a 10-line cap on code fences, scoped to API signatures, literal keys and ambiguous edit targets; component bodies, JSX trees and stylesheets are explicitly out. Added a **HARVEST** marker convention for durable findings.
- **`.gitignore`** — `.claude/agents/` un-ignored. `.claude/skills/align-screen/` stays ignored: disposable, scoped to WLA-318..321, slated for deletion.
- **`.claude/skills/align-screen/SKILL.md`** (still gitignored, listed for the audit trail) — gained a "Three agents. No more." contract and a section on orchestrator turn cost; Phase 1 now rejects oversized plans, Phase 4 harvests durable findings.
- Measured basis: `plan.md` was 842 lines / 300 inside code fences against a 250-line diff, and was read three times. Two of the session's five subagents (Explore 43,813 tokens; bug investigator 150,345) were improvised outside the documented pipeline — 42% of subagent spend.

### feat/WLA-321-signin-figma-align — 2026-09-29

[WLA-321](https://acn-avs.atlassian.net/browse/WLA-321) — align sign-in screen with Figma,
adopt `@white-label/ui-react` components, route all strings through `Dictionary.getText`.

#### Changed

- **`src/domain/config/Dictionary.ts`** — widened `IDictionary` interface to include `getText(key: string): string`; `Dictionary` class already implemented it, no runtime change.
- **`src/usecases/config/ConfigAppUseCase.ts`** — added `public static getDictionary(): IDictionary | undefined` accessor so UI can safely read the loaded dictionary without importing a protected field.
- **`src/ui/config/text.ts`** (new file) — `text(key, fallback)` helper; returns the localised string when the dictionary is loaded and the key is present, otherwise the English fallback. Fallbacks are load-bearing: sign-in renders before config bootstrap on cold deep links.
- **`src/ui/screen/SignInScreenComponent.tsx`** — replaced hand-rolled inputs and raw `<button>` submit with `TextField`, `Input`, `Button`, `Alert`, `SelectIndicator` from the library; all user-visible strings go through `text(key, fallback)`; "Remember me" rendered as a semantically correct `<button role="checkbox">` wrapping `SelectIndicator`; password field wired to `endIcon="eye"` / `onEndIconTap` toggle; `noValidate` added to form; `Cancel` button removed (Figma has no equivalent; NavBar provides the nav context); `flushSync` wraps `signIn()` before `navigate('/')` to fix a pre-existing race where cards briefly rendered with `isLoggedIn=false` after login (React 18 `useSyncExternalStore` fires Router re-renders synchronously before batched state commits).
- **`src/ui/styles/screen/signInScreen.css`** (new file) — layout-only replacement for the deleted `signIn.css`; no hex values, no `.wl-*` class overrides; `color: var(--text-primary)` on `.signin-screen` is load-bearing (see Notes).
- **`src/ui/screen/ScreenLayout.tsx`** — removed `import '../styles/screen/signIn.css'` (the import existed solely for the dead `.header-auth-button` rule; no NavBar CSS was ever needed here).

#### Removed

- **`src/ui/styles/screen/signIn.css`** — 124 lines, 20+ hardcoded hex values; all rules either absorbed by library components or dead (`.header-auth-button` was never applied anywhere in `src/`).

#### Notes

- **No `<Scrim>` rendered.** Sign-in renders inside `.screen-content-wrapper` which already paints `--surface-background` (`#131314`). `--surface-overlay` (`rgba(19,19,20,0.8)`) composited over `#131314` is pixel-identical — the Scrim costs a `position:relative` wrapper and a z-index fix for zero visual change. Figma's scrim exists because the design draws sign-in over VOD artwork; our route has no artwork behind it. If a backdrop is added later, add `position:relative` to `.signin-screen`, render `<Scrim variant="solid" />` as first child, and `position:relative` on `.signin-form`.
- **`.header-auth-button` was dead CSS.** `figma.md` and the task brief both cited `NavBarLayout.tsx:90` as applying this class. The actual line renders a library `NavItem`; the migration happened in an earlier NavBar adoption pass and the CSS was left behind. No NavBar CSS needed to be migrated or written.
- **Cancel button removed.** The old implementation had a `Cancel` button not present in Figma; `ScreenLayout` renders `NavBarLayout` above sign-in on this route, which provides the navigation context.
- **`text()` fallback mechanism.** `Dictionary.getText` returns `''` for unknown keys, and the dictionary is `undefined` until config bootstrap completes. Sign-in renders before that on cold deep links (`ScreenLayout.tsx:172`). Every `text()` call passes an English source string as the second argument; these fallbacks are load-bearing until the backend `/CONFIG/DICTIONARY` payload carries the `signin.*` keys.
- **`IDictionary` interface widened by exactly one method** (`getText`). `setLocale` was not added — widening it further makes the shape harder to mock.
- Adjacent P0-R-6 debt not in scope: `NavBarLayout.tsx:85,90` hardcodes `"User"` and `"Sign In"`.

### dev — 2026-09-29

[WLA-318](https://acn-avs.atlassian.net/browse/WLA-318) — consume UI library WLA-318 changes
in the React app: action icons, `favoriteButton` slot, import workaround cleanup.

#### Changed

- **`src/ui/content_page/DetailsScreenComponent.tsx`** — added `startIcon: 'play'` / `startIcon: 'theatre-mode'` to Play/Trailer actions; removed text-only Save `VideoDetailsAction` entry (workaround for missing `favoriteButton` slot); wired `<FavoriteButton>` to the new `favoriteButton` prop (`size='lg'` desktop / `'md'` TV, `isFavorite` state, `onClick=toggleFavorite`); added `FavoriteButton` to the library import.
- **`src/ui/content_page/SeriesDetailsScreenComponent.tsx`** — replaced `VideoDetailsLiveTagItem as VideoDetailsTagItem` / `VideoDetailsLiveAction as VideoDetailsAction` alias workaround with proper derived types from `VideoDetailsProps` (matches the pattern in `DetailsScreenComponent.tsx`); added `startIcon: 'play'` / `startIcon: 'theatre-mode'` to Play/Trailer actions; removed emoji-prefix Play label (`▶ Play`) and heart-emoji Save action (`♥`/`♡`); wired `<FavoriteButton>` to `favoriteButton` prop; updated stale organism comment.

#### Notes

- `ProgramDetailsScreenComponent.tsx` (`VideoDetailsLive`) is not affected — `VideoDetailsLive` was not changed by WLA-318 in the library.
- `FavoriteButton size='mobile'` (`'sm'`) deferred until `useDeviceMode()` returns `'mobile'` (Phase 3 #16 scope).

### feat/WLA-318-vod-details-align — 2026-09-28

[WLA-318](https://acn-avs.atlassian.net/browse/WLA-318) — align VOD details screen with Figma
and remove remaining hardcoded UI.

#### Changed

- **`src/ui/content_page/DetailsScreenComponent.tsx`** — dropped misleading `VideoDetails as DetailsPage` alias; derived `TagItem`/`ActionItem` from `VideoDetailsProps` instead of aliasing the `VideoDetailsLive` equivalents; `buildTags` now includes duration and PC level up to 4 chips; star rating clamped 0–5 wired via `rating` prop; `buildCrewDetails` now renders `List`/`ListItem` instead of bare `<span>`s (Duration moved to tags, Language/Country moved to expanded block); added `buildExpandedDetails` returning `List`/`ListItem` for Language, Country, Available-until; description uses the organism's own expand/collapse mechanism (`expanded`/`expandedDetails`/`onSeeLess`); action labels stripped of unicode glyph substitutes (`▶ ♥ ♡`); error state replaced with `StreamErrorAlert` (fixed-position, no longer below the fold).
- **`src/ui/content_collection/SimilarContentRail.tsx`** — `<h2>` heading moved into `Carousel title` prop; fixes the `aria-label="Carousel"` accessibility defect.
- **`src/ui/styles/content_page/similarContentRail.css`** — reduced to layout-only; removed `background: #303030`, `color: #eee`, `font-size`, `font-weight`, `padding` literals; `.similar-content-heading` rule deleted entirely.

#### Added

- **`src/ui/elements/StreamErrorAlert.tsx`** — shared fixed-position `Alert` element for playback errors; extracted from three identical inline `<p style>` blocks across the details screens. WLA-319/320 will remove their copies.
- **`src/ui/styles/elements/streamErrorAlert.css`** — layout-only CSS for the above; `z-index: 200` (above navbar 100, below player overlay 1000).

#### Removed

- **`src/ui/styles/content_page/detailsScreen.css`** — confirmed orphan (no importer in `src/`); 196 lines, ~21 hardcoded hex values, one `aspect-ratio` (Tizen risk). Satisfies AC3.

#### Notes

- **Known Figma deltas** (declared, not oversights): "Directed by/Cast" rows have no backend source; Expanded "Year" omitted (contractStartDate is an availability window, not a release year); heart in actions row is unimplementable on `VideoDetailsProps.actions` typed array — library request raised; similar-content rail stays portrait (landscape/sm/desktop Card tier is unimplemented in the library); star rating renders filled-only, not filled-of-five. See plan §8.
- Library-owned hardcoded English on this screen: `"See Less"` and `Alert aria-label="Dismiss"` — upstream items alongside P0-R-6.

### chore/agent-pipeline — 2026-09-28

Cost-control scaffolding for the four remaining screen-alignment tickets
([WLA-318](https://acn-avs.atlassian.net/browse/WLA-318) VOD details,
[WLA-319](https://acn-avs.atlassian.net/browse/WLA-319) Series,
[WLA-320](https://acn-avs.atlassian.net/browse/WLA-320) Programme,
[WLA-321](https://acn-avs.atlassian.net/browse/WLA-321) Sign-in), plus
[WLA-315](https://acn-avs.atlassian.net/browse/WLA-315) (UI-library adoption rule).

WLA-317 cost ~$68 in a single 317-turn session. Over half of that was context re-reading:
the conversation grew 46K → 343K tokens, so identical work cost ~7× more at the end than at
the start. A further $20 went on subagent exploration whose findings apply to all four
remaining tickets. Both are addressable without changing the model.

#### Added

- **`.claude/rules/ui-library-adoption.md`** (WLA-315) — the adoption rules that do not go
  stale: prefer-but-don't-force, delete-the-CSS-you-replace, no hardcoded hex, the
  non-uniform `device` defaults table, the library API traps (`htmlType` not `type`, renamed
  `title` props, placeholder defaults that render as demo copy, tuple-typed props, `x-mark`),
  the `useTvNavigation` private-class-name constraint, and the `npm run ui:sync` requirement.
  `docs/ui-library-adoption.md` stays the per-screen catalogue; it carries an audit date and
  is explicitly flagged there as needing verification before use.
- **`scripts/gates.js`** + **`npm run gates`** — typecheck, lint and format check, scoped to
  files changed against the base branch. `--fix` applies, `--base <ref>` overrides.
  Repo-wide `prettier --write` rewrote 75 untouched files CRLF→LF during WLA-317, which
  `git status` flagged but `git diff` hid; scoping it is the behavioural fix pending
  [WLA-389](https://acn-avs.atlassian.net/browse/WLA-389) (`.gitattributes`).

#### Notes

- **Not committed, by design.** `.claude/agents/{planner,implementer,reviewer}.md` and
  `.claude/skills/align-screen/` are gitignored local scaffolding: a three-phase pipeline
  (plan on Opus, implement and review on Sonnet) that keeps the orchestrating session near
  its context floor by moving bulk work into short-lived subagents. The agents are generic;
  only the skill is ticket-shaped and is meant to be deleted after WLA-321. To promote them
  for the team, remove the `.gitignore` lines and commit.
- `.claude/work/` is gitignored — per-ticket agent handoff files.
- Pipeline discipline, recorded because it is the part that decays: one ticket per session,
  handoffs through files rather than conversation, subagent hand-backs capped at ~15 lines,
  `preview_eval` returning small JSON for measurement, and at most one `preview_screenshot`
  taken last. Three screenshots cost more context in WLA-317 than 99 shell commands.

### feat/WLA-317-search-screen — 2026-09-28

[WLA-317](https://acn-avs.atlassian.net/browse/WLA-317) — align Search with Figma
(`AVS-WL-Library` node `1191:17338`, `SearchPage / TV`) and finish the UI-library adoption on
that screen. Blockers WLA-313 (real routes) and WLA-314 (device mode) were already closed.

The Search _chrome_ was already 100% library: `SearchLayout` renders a single `SearchArea`
and imports no CSS, and the Figma template is literally one `SearchArea / TV` instance plus
an empty `additional-content` slot. The work here was structural.

#### Added

- **`src/ui/screen/searchRoute.ts`** — `HOME_ROUTE`, `SEARCH_ROUTE`, `homeUrl()`,
  `searchUrl()`, `isSearchPath()`, mirroring `signInRoute.ts` / `epgRoute.ts`. Removes the
  bare `'/AVS_BASE'` / `'/AVS_BASE/SEARCH'` literals from `App.tsx` and `ScreenLayout.tsx`.
  `isSearchPath` uses strict equality rather than `startsWith`: Search has no sub-paths, and
  `HOME_ROUTE` is a prefix of every other route.
- **`src/ui/screen/SearchScreenComponent.tsx`** — Search is a named screen component instead
  of an inline branch in `ScreenLayout`'s conditional. It takes `screenState` plus the
  `updateNavParams` / `reloadOnParamsChange` callbacks as props, so `ScreenState`'s mutable
  `forceUpdate` tick stays confined to `ScreenLayout` (per `src/ui/CLAUDE.md`).
- **`src/ui/styles/screen/search.css`**, **`src/ui/styles/content_page/gridPage.css`**,
  **`src/ui/styles/content_page/largeCardsGrid.css`** — layout-only, no colour, type or
  spacing literals.
- **Deep links to `/AVS_BASE/SEARCH` now work.** The first-navigation effect in `ScreenLayout`
  switches to `MenuZone.Search` and stays put when the app loads directly on the Search URL,
  instead of bailing out and letting the Main-zone bootstrap bounce you to Home. Verified by
  hard refresh.

#### Changed

- **Navigation is menu-zone aware.** `IScreenState.onRetrieveItems` now takes
  `(menuZone?: MenuZone) => void`, and `retrieveItems` forwards the zone it already receives.
  `ScreenLayout.updateNavParams` routes Search-zone clicks to `SEARCH_ROUTE` and everything
  else to `HOME_ROUTE`.
- **`onSearch` no longer needs `replace: true`.** It calls `switchMenu(MenuZone.Search)` and
  navigates itself only when that returns `false` (retrieve-items URL unchanged). Verified:
  `history.length` goes 2 → 3, one entry either way.
- **`LargeCardsGridCollection` uses the library `Grid` organism** instead of a hand-rolled
  CSS grid. This is the follow-up the WLA-316 revert (`60f4f80`) promised and never filed —
  no such ticket exists in Jira or the repo, and WLA-317's AC is the first to forbid that
  exact `#202020` on that exact screen.
- **Loading / error states use the library `Alert`** in `ContentPageLayout` and
  `GridPageLayout` (the two layouts Search renders), replacing bare `<div>Loading...</div>` /
  `<div>Network error</div>`.
- **`.screen-content-wrapper`** — `background-color: #202020` → `var(--surface-background)`,
  and `height: 100vh` → `min-height: 100vh`. The shell darkens app-wide from `#202020` to the
  token's `#131314`, matching `.content-collections-list`, which already used the token. The
  `min-height` change fixes a guaranteed overflow: `.wl-search-area` is `min-height: 100dvh`
  and sits _below_ the NavBar inside a fixed-height wrapper.
- **`smallCardsCollection.css` tokenised.** `var(--surface-primary, #fff)` replaced with
  `var(--pure-bw-white)` — `--surface-primary` is not in the token set, so that fallback was
  always the literal.
- **`.wl-text-heading-sm` override in `src/index.css` reduced to `color` + `margin`.** The old
  comment claimed the library had no CSS rule for the class. It does — `tokens.css:595`,
  weight 500 / 20px — and the app's re-declaration loaded later at equal specificity, silently
  forcing **22px app-wide**. The library rule sets no colour and no margin, so deleting the
  block outright would have left every `<h2>` unstyled-black on a dark background; hence
  reduce, not delete. **Affects headings on every screen** (verified 20px / white on both Home
  and Search).

#### Removed

- **`SearchState.isVisible` and its entire mechanism** — `setSearchVisibility`,
  `onSearchState`, `onSearchStateCallBack`, and the
  `menuZone !== MenuZone.Search → setSearchVisibility(false)` block in `retrieveItems`.
  Nothing read the flag for display and `onSearchState` had zero callers, so that "leave
  search" reset was writing to a field no one observed. The one load-bearing behaviour,
  `switchMenu(MenuZone.Search)`, is now an explicit call from `onSearch`.
- **Dead Search assets** — `src/ui/styles/screen/screenHeader.css` (`.search-icon*` rules
  including a `:hover scale(1.1)`) and `src/ui/assets/SearchIcon.svg`. Zero importers, both
  flagged in `docs/ui-library-adoption.md:238`.
- **`src/ui/styles/content_page/largeCardsCollection.css`** — the `Grid` adoption removed its
  last real consumer; its import in `LargeCardsContentCollection.tsx` was already dead.

#### Fixed

- **Interacting with the Search chrome kicked you back to Home.** `SearchLayout`'s tab and
  filter handlers call `menuState.click()` → `retrieveItems(zone=Search)` → the retrieve-items
  callback → `navigate('/AVS_BASE')`. Every filter click threw the user off the Search route.
  This was the concrete reason Search was not a real screen; the zone-aware navigation above
  is the fix. Verified: filter and tab clicks now keep `/AVS_BASE/SEARCH`.
- **Search results were inset twice.** `.wl-search-area__results` applies
  `--space-inset-safe-area-horizontal` and the nested collection lists applied it again — 96px
  at desktop against Home's 48px. An `.avs-search-results` wrapper cancels the inner one so
  the library slot owns the gutter. Home's own 48px is untouched.
- **Ragged, overflowing result grid.** The library's `.wl-grid` declares
  `grid-template-columns: repeat(5, 1fr)`; `1fr` is `minmax(auto, 1fr)`, so each column's
  minimum is the poster's intrinsic width. Columns measured 473/317/349/432/427px at 1440 and
  the row overflowed its container, silently clipped by `.wl-grid { overflow: hidden }`.
  `largeCardsGrid.css` applies the standard `minmax(0, 1fr)` fix — now 5 × 247px at desktop,
  5 × 241px at TV. **Library defect, raise upstream.**
- **Orphan tab/filter divider.** `SearchArea` renders `.wl-search-area__divider`
  unconditionally, so omitting the tab row left a floating vertical rule. Hidden via an
  `avs-search-area--no-tabs` modifier until the library makes it conditional.
- **More than two search categories were dropped silently.** `handleTabChange` is now clamped
  to the two rendered options and the dropped labels are warned about, rather than looking
  like a backend fault.
- **Clearing the search box left the previous results on screen.** The clear button fires
  correctly and the rails refetch without `&query=`, but the Results collection kept its
  stale cards. `ContentCollectionComponent`'s "not enough URL parameters" branch set the
  state to `Loaded` without resetting `data` — its comment assumed `data` was still empty,
  which is only true on first mount. Dropping the `{{query}}` parameter on an empty term
  makes `queryParams.check()` fail, so that branch runs on every clear. Now resets to
  `ContentCollection.getEmpty()`. Shared component, so any collection with unresolved
  parameters now clears rather than showing stale content — verified Home is unaffected.
- Stray `;` in `GridPageLayout`, which React rendered as a literal text node under the grid
  header.

#### Notes

- **Tab-row behaviour below two options (AC item).** `SearchArea.tabOptions` is a hard
  fixed-length 2-tuple and all three Figma `SearchArea` variants publish exactly two labels —
  there is no 1-tab state to match. Omitting the row stands as the confirmed behaviour, with
  the orphan divider now hidden. Relaxing the tuple so 1..n categories can render is
  [WLA-334](https://acn-avs.atlassian.net/browse/WLA-334), already open against the library.
  **Open design question:** what Search should render at 0, 1 or more than 2 categories.
- **`Grid` cell heights are fixed design constants** — 340px desktop, 220px mobile, 180px TV.
  At TV the 241 × 180 cell crops portrait posters to landscape (`object-fit: cover`). That is
  the library's Figma constant, not a bug we introduced; worth a design question before #16.
- **D-pad is unaffected by the `Grid` swap.** `useTvNavigation.ts:31-33` only matches
  `.wl-carousel__track`, `.wl-carousel` and `.wl-navbar`; the grids were already
  arrow-key-inert, and `.wl-grid` changes nothing. The class-name coupling itself is
  [WLA-333](https://acn-avs.atlassian.net/browse/WLA-333).
- **`SmallCardsGridCollection` stays hand-rolled** — `Grid` is portrait-only and those are
  landscape cards. Needs a landscape `Grid` variant from the library.
- **Two app stylesheets now touch library-private selectors** — `.wl-search-area__divider` in
  `search.css` and `.wl-grid` in `largeCardsGrid.css`. Same category of coupling as
  `useTvNavigation`; both are commented as such and both are removable once the library ships
  its fixes.
- **Out of scope per the ticket**: search backend behaviour and the `setInterval` poll in
  `SearchLayout.tsx` — untouched.
- **The "Search history" button is a dead control, deliberately left visible.** Figma
  publishes it and composition parity is this ticket's AC, so it stays. It cannot be wired
  from this repo: `SearchArea` forwards `onHistoryPress` to the `Search` molecule but not
  `menuOpen` / `menuItems` / `onMenuItemSelect` / `onMenuItemRemove`, so the dropdown is
  unreachable through the organism. Bypassing `SearchArea` to compose `Search` directly
  would violate this ticket's own "no hand-rolled equivalent of a shipped library
  component" AC. There is also no history data source — building one means inventing
  client-side persistence of viewer search terms, which the repo's security posture rules
  out. Needs a library change plus a product decision on where history lives. Filed as
  [WLA-387](https://acn-avs.atlassian.net/browse/WLA-387).
- **`?q=` in the URL** so a Search deep link restores the term is
  [WLA-388](https://acn-avs.atlassian.net/browse/WLA-388). It also has to settle
  `INavParams.searchState`, which is write-only today (`applyNavParams` ignores
  `searchString`, so back/forward already does not restore the term), and
  `GridPageComponent` fetching with `params: undefined`, so `{{query}}` never reaches grid
  pages.
- **Not yet ticketed**: the `.wl-grid` column defect and the unconditional
  `.wl-search-area__divider` (both worked around here); the library has no spinner or
  skeleton atom; `Carousel.title` is `string`-only, so "see all" cannot be wired.

### dev (tooling) — 2026-09-25

#### Added

- **`ui:build` / `ui:clean` / `ui:sync` npm scripts** in `package.json`, replacing the
  manual three-step ritual for pulling changes from the sibling `white-label-ui` repo
  (build there → delete `node_modules/@white-label/ui-react` → hand-copy `dist/`).
  `npm run ui:sync` now does all three.

#### Notes

- **Why the delete step can't be dropped.** `@white-label/ui-react` is consumed as
  `file:../white-label-ui/platforms/react`, and npm pack-and-extracts it rather than
  symlinking. Because the library's `version` is pinned at `0.0.0` and never moves, npm
  considers the dependency satisfied and skips re-extraction — verified here: both
  `npm install @white-label/ui-react@file:...` and the same command with `--force` left a
  deliberately-planted sentinel string in the installed `dist/index.js` untouched.
  Removing the installed directory first is the only thing that actually re-syncs.
- **Bumping the library's `version` on each meaningful change** would let npm detect
  staleness on its own and would put a real record of the consumed UI build in the
  lockfile. Worth doing in `white-label-ui`; not done here.
- **No lockfile churn** — `file:` dependencies record only the link path, with no integrity
  hash, so re-syncing leaves `package-lock.json` byte-identical.
- Longer term the fix is publishing `@white-label/ui-react` to a private registry
  (Artifactory / Azure Artifacts) and consuming it as a normal versioned dependency. Blocked
  on the CI-platform decision, which is still open.
- Deliberately **not** switched to symlinks / `npm link` / npm workspaces: the library ships
  its own `react` and `react-dom` in `node_modules`, and webpack resolves symlinks to their
  real path, so the library would load a second React copy ("Invalid hook call"). Avoiding
  that needs a webpack alias, which stock `react-scripts` does not expose.

### feat/WLA-316-home-ui-library (follow-up) — 2026-09-25

Three fixes found by exercising the app **logged in**, which returns far more content
variation than the anonymous cluster.

#### Fixed

- **Crash on the logged-in homepage** — `TypeError: Cannot read properties of undefined
(reading 'length')` in `genreTags`. `MetadataDTO.genres` was typed `string[]` and passed
  straight through, but the registered (`R`) cluster omits it for some items, so `undefined`
  reached a domain field declared `string[]`. The old `FloatingIsland` happened to mask this
  with `content.genres ?? []`; moving genres into `Card`'s `tags` slot removed that guard.
  Fixed at the boundary: the DTO now says `string[] | undefined` and the mapper defaults it
  through a new `defaultArray<T>` helper, so the domain contract is true again and call sites
  need no guards.

#### Changed

- **VOD cards no longer render an always-empty progress bar.** `Content.getProgress()`
  returned a hardcoded `0` for anything not live, so every VOD card drew a 0% bar. It now
  returns `number | undefined` — the elapsed share of the airing window for live (where `0`
  is meaningful: "just started"), and `undefined` for VOD, which the library treats as "hide
  the bar". Resume positions are not a display concern: they come from AVS _bookmarks_
  (`fetchUserBookmarks` / `PLAYER.FROM_BOOKMARK`), both mapped into `ConfigApp` but not yet
  consumed. Deliberately **not** a `progress > 0` display rule, which would also hide the bar
  for a live programme in its first minutes and would bake around the missing feature.
  `RailContentCollection` had that `> 0` guard locally and `SmallCardsContentItem` did not —
  both now share the domain rule.

- **Renamed the WLA-280 "bookmark" feature to "favourites"** — a terminology collision with
  the platform. In AVS a _bookmark_ is a playback resume position; the "save this title"
  concept is `fetchFavorites`, and the library atom is already `FavoriteButton`. Left as-is,
  wiring real resume progress would have produced two unrelated things called "bookmark", with
  `avs:bookmarks` in localStorage holding favourite IDs. Renamed via `git mv` (history
  preserved): `domain/bookmarks` → `domain/favorites`, `IBookmarkRepository` →
  `IFavoriteRepository`, `LocalStorageBookmarkRepository` → `LocalStorageFavoriteRepository`,
  `BookmarkUseCase` → `FavoriteUseCase`, `BookmarkModule` → `FavoriteModule`, `useBookmark` →
  `useFavorite`, `BookmarkAction` → `FavoriteAction`, and the storage key
  `avs:bookmarks` → `avs:favorites`. `IFavoriteRepository` now documents the distinction so the
  two vocabularies stay apart.
  **Note:** the storage-key change orphans any favourites saved during local testing — the
  feature is a day old and client-side only, so no migration was written.
  Worth raising with the WLA-280 author, since the original naming was theirs.

### feat/WLA-316-home-ui-library — 2026-09-25

Rationale: the shared `@white-label/ui-react` library reworked `Carousel` and `Card`
(white-label-ui `f96d68a`, `4074837`) after this branch's first two commits. `node_modules` was
refreshed to that build and the app stopped compiling — `variant` no longer exists on
`CarouselProps`. More importantly the rework **moves card-frame ownership into the library**, so
most of the pixel workarounds this branch had accumulated were not just redundant but actively
fighting the library.

#### Changed

- **Carousel API migration (4 call sites)** — `variant="hero" | "shelf"` is gone, replaced by
  `bannerCarousel?: boolean` + `cardLayout?: 'landscape' | 'portrait'`.
  `CarouselContentCollection` → `bannerCarousel`; `LargeCardsContentCollection` and
  `SimilarContentRail` → `cardLayout="portrait"`; `SmallCardsContentCollection` →
  `cardLayout="landscape"`. `SmallCardsContentCollection` and `SimilarContentRail` predate this
  branch but broke on the same rework, so they are fixed here. Dropped the explicit `showDots` on
  card carousels — the library default (`false`) is the Figma behaviour; passing it forced dots on
  where Figma has none.
- **Card sizing now comes from the library, not the app.** `Card` gained `size?: 'sm' | 'lg'`,
  which renders the exact Figma frame per layout+device. `LargeCardsContentItem` and
  `SmallCardsContentItem` take an optional `size` pass-through and the Carousel consumers pass
  `size="lg"` (per the library changelog, every Figma carousel slot is the LG tier). The prop is
  deliberately _omitted_ in Grid/Rail contexts, where the card must keep filling its cell.
- **Section headings moved into `Carousel title`.** `MapContentCollection` no longer renders
  `ContentCollectionHeader` for `LARGE_CARDS` / `SMALL_CARDS`; the library now puts the title and
  the prev/next arrows in one header row, which the app's separate `<h2>` was splitting across two.

#### Added — bookmarks restored (WLA-280) and extended to Home cards

Context: PR #54 added bookmarks to the three details screens by passing `isBookmarked` /
`onBookmark` to `VideoDetails` / `VideoDetailsLive`; commit `5de2355` (in PR #55) removed them
because they produced 3× TS2322 and a blocking CRA overlay. A revert was requested.

**A literal revert of `5de2355` is not possible, and the original feature never rendered.**
Re-verified against the current library build: neither organism declares those props, neither
renders `children`, and `actions` is `{ label, onClick }[]` rendered as text `Button` atoms.
Critically, `VideoDetails` spreads `...rest` onto its root `<div>` (`VideoDetails.tsx:93`) — so
even ignoring TypeScript, the two props were being forwarded to a DOM node, producing React
unknown-prop warnings and **no heart**. The removal fixed a real defect rather than deleting
working UI. Only the safe half is restored here.

- **`BookmarkAction.tsx`** (new) — `FavoriteButton` wired to the existing `useBookmark` hook, for
  a `Card`'s `actions` slot. Calls `stopPropagation()`: `actions` renders inside the Card root
  that carries `onClick`, so without it bookmarking would also open the details page.
- **`LargeCardsContentItem` / `SmallCardsContentItem`** — bookmark heart in `Card.actions`,
  revealed on hover alongside the Gradient Scrim so rails stay uncluttered at rest. On TV it
  should follow D-pad focus instead; noted in code, belongs to `P3-R-6`.
- **Three details screens** — `useBookmark` wiring restored (including the `epg:` id prefix for
  programmes), surfaced as a Save/Saved entry in the supported `actions` array instead of the two
  invalid props. This is a text button, not the Figma heart (node 1088:2881).
- The bookmark domain layer (`IBookmarkRepository`, `LocalStorageBookmarkRepository`,
  `BookmarkUseCase`, `BookmarkModule`, `useBookmark`) was already intact and is now actually used.

Known limitations: bookmarks remain localStorage-only until a backend favourites API exists;
nesting a real `<button>` inside a `role="button"` Card is an a11y smell that `Card.actions`
invites; and a logged-out heart click routes to sign-in, navigating away from Home.

#### Changed — card hover is now the library's Gradient Scrim (UX decision, 2026-09-25)

- UX confirmed the intended card hover behaviour: hovering toggles the library's **Gradient Scrim**,
  which darkens the media so the overlaid white title, tags and buttons keep contrast. There is no
  bespoke overlay in the design. `Card` does not toggle the scrim itself — it is purely prop-driven —
  so the app passes `showScrim={isHovered}` (previously hardcoded `showScrim`, always on).
- Content that the old overlay revealed on hover is now passed to `Card` and rendered **immediately**
  from the BE response, per UX: genres map to the `tags` slot as `Tag` atoms, and the live airing
  window moves into `subtitle` (VOD keeps just the start time).
- `useHoverWithDelay(0)` on both card items — the 300ms delay existed to stop the heavy overlay
  flickering. A scrim is a pure visual affordance and a delay reads as lag.

#### Removed

- **Hardcoded card heights** — the inline `style={{ height: '162px' | '234px' }}` in
  `SmallCardsContentItem` and the `470px` / `350px` `.large-cards-shelf .wl-carousel__item` rules
  in `largeCardsCollection.css`, plus the now-purposeless `large-cards-shelf` class. These were
  derived from Figma by hand while the library's own frame table was wrong; the library table is
  now authoritative (`Card.css`: portrait LG desktop 318×420 / TV 196×300; landscape LG desktop
  432×264 / TV 268×180).
- **`--space-inset-safe-area-horizontal: 58px` override in `src/index.css`** — this was masking a
  real bug. The library _does_ ship the token, device-scoped (desktop 48px / TV 58px / mobile
  16px), in `@white-label/ui-react/tokens.css`, a **separate export** from `styles.css` that the
  app already imports. The earlier session concluded it was missing by grepping only
  `dist/index.css`. The app's flat `:root` rule has equal specificity to the library's
  `[data-device="desktop"]` rule but loads later, so desktop was silently getting the TV inset.
  Replaced with a comment explaining why nothing is defined there.
- **`src/ui/content_collection/PosterComponent.tsx`** — orphaned since the tile rewrite replaced it
  with `Card src`; zero remaining references.
- **`src/ui/elements/FloatingIsland.tsx` + `src/ui/styles/elements/floatingIsland.css`** — the
  bespoke hover overlay, superseded by the Gradient Scrim above. No remaining references.
  Its long-description text has no home on landscape/portrait Cards (`description` is list-layout
  only), so that copy is dropped — consistent with the Figma card, which shows title/tags only.

#### Reverted

- **`LargeCardsGridCollection.tsx`** restored to its pre-branch CSS-grid implementation, with its
  `.large-cards-grid-wrapper` / `.large-cards-grid` rules. It renders on the Browse/category grid
  screen, not Home, so its `Grid`-organism adoption was outside WLA-316's homepage scope. Split
  into its own ticket. Note this re-introduces the pre-existing hardcoded `#202020` on that screen,
  which belongs to the new ticket.

#### Notes — gaps flagged to the library team

- `Carousel.title` is `string`-only, so the backend-driven `onTitleClick` action cannot be wired.
  Adopting the library header row therefore drops the clickable "see all" on Home rails. Needs an
  `onTitleClick` handler or a `ReactNode` title. **Accepted knowingly** — tracked with the existing
  arrow/dot-styling library ticket.
- `Card` still has no `autoHover`; every call site must wire `onMouseEnter`/`onMouseLeave` to
  `state`. TODOs left in both card items.
- `VideoDetails` / `VideoDetailsLive` have no bookmark slot and no `children`; `actions` is
  text-Button-only, so the Figma heart cannot sit in the CTA row. Blocks full WLA-280 fidelity.
- `Card.actions` encourages nesting a `<button>` inside a `role="button"` Card — the molecule
  offers no non-interactive affordance slot.
- `.wl-text-heading-sm` is still not a standalone CSS rule in the library, so the local definition
  in `src/index.css` stays (still used by `ContentCollectionHeader` for RAIL, and
  `GridCollectionHeader`).
- `tokens.css` being a separate export from `styles.css` is an easy footgun — worth either shipping
  the tokens in `styles.css` or documenting the dual import.

#### Notes — local dependency refresh

`node_modules/@white-label/ui-react` had to be refreshed by copying `dist/` manually: the dep is
`file:../white-label-ui/platforms/react` pinned at version `0.0.0`, so `npm install` (even with
`--force`) reports "up to date" and never re-copies. A version-bump policy or a refresh script
would stop a future `npm install` silently reverting the library.

### feat/WLA-316-home-ui-library — 2026-09-22

Rationale: WLA-316. The Home screen's card tiles were entirely hand-rolled; the design-system
audit (`docs/ui-library-adoption.md`) mapped each to a library replacement. Both `Grid` and
`MediaList` organisms are now available (they were the stated blockers in the ticket), so no
external dependency remains. The `--motion-duration-deafult` typo silently prevented all card
hover transitions.

#### Added

- **`src/ui/content_collection/LargeCardsGridCollection.tsx`** — adopts `Grid` organism from
  `@white-label/ui-react`. Replaces the hand-rolled CSS-grid wrapper + `LargeCardsContentItem`
  tile. `Grid` provides 5-column desktop/TV layout and 2-column mobile layout via design tokens.

#### Changed

- **`src/ui/content_collection/SmallCardsContentItem.tsx`** — rewritten as `Card layout="landscape"`.
  Retains the live-progress `setInterval` state (60 s tick). `FloatingIsland` and channel-logo
  image now render as `Card.children` inside the media slot. `device` resolved via `useDeviceMode()`.
- **`src/ui/content_collection/LargeCardsContentItem.tsx`** — rewritten as `Card layout="portrait"`.
  `FloatingIsland` as `Card.children`. Used by carousel rails, grid, and `SimilarContentRail`.
- **`src/ui/content_collection/CarouselContentCollection.tsx`** — now renders `Banner` from
  `@white-label/ui-react` instead of the hand-rolled `CarouselContentItem`. Navigation wired via
  `onClick` on `Banner` (which extends `HTMLAttributes<HTMLDivElement>`).
- **`src/ui/content_collection/ContentCollectionHeader.tsx`** — heading CSS deleted; uses
  `wl-text-heading-sm` library utility class directly. Clickable variant uses `cursor: pointer`
  inline (one layout property, not a colour/type literal).
- **`src/ui/content_collection/GridCollectionHeader.tsx`** — same: `wl-text-heading-sm`.
- **`src/ui/styles/content_page/smallCardsCollection.css`** — tile-level rules deleted (Card
  absorbs them); grid-wrapper rules kept for `SmallCardsGridCollection`. Added
  `.small-card-channel-logo` for the channel badge inside the Card media slot. The
  `--motion-duration-deafult` typo is gone (the offending rule was deleted with the tile block).

#### Deleted

- **`src/ui/content_collection/CarouselContentItem.tsx`** — replaced by `Banner`.
- **`src/ui/styles/content_page/carouselCollection.css`** — all classes were `CarouselContentItem`-specific; absorbed by `Banner`.
- **`src/ui/styles/content_page/largeCardsCollection.css`** — tile rules absorbed by `Card`; grid layout absorbed by `Grid` organism.
- **`src/ui/styles/content_page/contentProgressBar.css`** — `Card.progress` replaces the hand-rolled bar.
- **`src/ui/styles/content_page/contentCollectionHeader.css`** — replaced by `wl-text-heading-sm`.
- **`src/ui/styles/content_page/gridCollectionHeader.css`** — replaced by `wl-text-heading-sm`.

#### Notes

- **Missing components flagged to library team:** `FloatingIsland` (no equivalent, kept app-owned
  as `Card.children`); `Card.src` has no `onError` (poster fallback degraded — `PosterComponent`
  kept as URL resolver); `Grid` expects portrait cards only (`SmallCardsGridCollection` stays on
  CSS grid with `Card layout="landscape"`; flag to designer); `textHeadingSm` token constant not
  exported from barrel (string literal used instead — raise upstream).
- `SimilarContentRail` regression tested: renders correctly after `LargeCardsContentItem` rewrite.
- Phase task links: WLA-316.

#### Fix (2026-09-22 follow-up) — card height collapse

`wl-card[data-layout=landscape/portrait]` has `height: 100%` but no intrinsic height;
the Carousel shelf sets item width only, so cards were collapsing to ~38px (text content only).

- **`SmallCardsContentItem.tsx`** — explicit `style={{ height }}`: `162px` (TV) / `234px`
  (desktop), sourced from Figma node 825-2728 (landscape SM rail-content `h-[162px]` on TV;
  318×182 pt media + ~52px text on desktop).
- **`largeCardsCollection.css`** (re-created, minimal) — scoped carousel item heights:
  `470px` (desktop) and `350px` (TV), sourced from portrait LG card Figma dims
  (318×420 pt desktop, 196×300 pt TV, plus ~50px text). Targets
  `.wl-carousel.large-cards-shelf .wl-carousel__item` — not the Grid organism cells.
- **`LargeCardsContentCollection.tsx`** — `className="large-cards-shelf"` added to `Carousel`
  to scope the CSS rule above. Grid collections are unaffected (Grid manages its own cell height).
- Banner hero carousel unaffected: `wl-banner` has built-in `aspect-ratio: 16/9`.

### feat/WLA-314-device-resolution — 2026-09-22

Rationale: WLA-314. The app had two independent device mechanisms that could disagree:
`data-device` on the root DOM element (hardcoded `"desktop"` in `public/index.html`) and
explicit `device` props on library components (`Card`, `Carousel`, `Rail`, `VideoDetails`,
`VideoDetailsLive`). Details screens hardcoded `device="tv"` while browse screens hardcoded
`device="desktop"`, so desktop-browser users were getting TV-mode details pages. Every FY26
feature ticket (#6, #7, #11, etc.) has both desktop and TV acceptance criteria; without one
agreed mechanism each would invent its own answer.

#### Added

- **`src/ui/config/deviceMode.ts`** — single-source-of-truth for device mode. Resolves in
  priority order: `REACT_APP_DEVICE_MODE` env var → `localStorage.getItem('WLA_DEVICE_MODE')`
  → user-agent detection (Tizen / webOS / SmartTV / VIDAA) → `'desktop'` default.
  Exports `DeviceMode` type, `DEVICE_MODE` constant, and `useDeviceMode()` hook.
- **`.claude/rules/device-mode.md`** — rule documenting the convention, resolution order,
  runtime-switch instructions, and covered components.

#### Changed

- **`src/index.js`** — stamps `data-device` on `#root` before first React render, so
  library components that read the ancestor attribute (`NavBar`, `SearchArea`, `Banner`)
  are always in sync with the resolved mode.
- **`src/ui/content_collection/CarouselContentCollection.tsx`**,
  **`LargeCardsContentCollection.tsx`**, **`SmallCardsContentCollection.tsx`**,
  **`SimilarContentRail.tsx`**, **`RailContentCollection.tsx`** — replace hardcoded
  `device="desktop"` with `device={deviceMode}` from `useDeviceMode()`.
- **`src/ui/content_page/DetailsScreenComponent.tsx`**,
  **`SeriesDetailsScreenComponent.tsx`**, **`ProgramDetailsScreenComponent.tsx`** — replace
  hardcoded `device="tv"` with `device={deviceMode}`; remove stale deferral comments.
- **`src/ui/content_page/TvGuideLayout.tsx`** — replace hardcoded
  `data-device="desktop"` with `data-device={DEVICE_MODE}`.
- **`docs/ui-library-adoption.md`** — adds device-mode convention section cross-referencing
  the new rule file.

#### Notes

- Runtime-switch: `localStorage.setItem('WLA_DEVICE_MODE', 'tv')` + page reload.
  Reset: `localStorage.removeItem('WLA_DEVICE_MODE')` + reload.
- Build-time switch: `REACT_APP_DEVICE_MODE=tv npm start`.
- Smart-TV user-agent detection (Tizen/webOS/Vidaa) will auto-select `'tv'` for
  future #16 builds without any code change.
- Phase task links: WLA-314.

### fix/bookmark-props-typecheck — 2026-09-22

Rationale: WLA-280 passed `isBookmarked` and `onBookmark` as props to `VideoDetails`
and `VideoDetailsLive` organisms, but those props are not in `@white-label/ui-react`'s
published types and are also absent from the package source — the props were never
accepted at runtime. This caused three TS2322 errors shown as a blocking CRA overlay.

#### Changed

- **`DetailsScreenComponent.tsx`**, **`SeriesDetailsScreenComponent.tsx`**,
  **`ProgramDetailsScreenComponent.tsx`** — removed `isBookmarked`/`onBookmark` props
  from the organism calls and the now-unused `useBookmark` hook destructuring and
  import. The `useBookmark` hook and the full bookmark domain layer
  (`IBookmarkRepository`, `LocalStorageBookmarkRepository`, `BookmarkUseCase`,
  `BookmarkModule`) are intact; the visual `FavoriteButton` overlay is a follow-up
  once `@white-label/ui-react` organisms expose a bookmark slot or the overlay is
  wired as a sibling element.

### feat/WLA-313-real-routes-home-search — 2026-09-22

Rationale: P0-R-3 (phase-0-foundation.md). The app served every screen from a single
wildcard route at `/`; URL bar never changed. Deep links, browser refresh on any screen,
and SEO-crawlable URLs were all broken. WLA-313 scopes the fix to Home and Search.

#### Added

- **`src/App.tsx`** — full React Router `<Route>` table replacing the two catch-all
  routes. `/` redirects to `/AVS_BASE` (replace). Explicit routes: `/AVS_BASE`,
  `/AVS_BASE/SEARCH`, `/AVS_BASE/SIGNIN`, `/AVS_BASE/EPG`,
  `/AVS_BASE/PAGE/DETAILS/VOD/:contentId/:slug`,
  `/AVS_BASE/PAGE/DETAILS/GROUP_OF_BUNDLES/*`,
  `/AVS_BASE/PAGE/DETAILS/PROGRAM/*`.

#### Changed

- **`src/ui/screen/ScreenLayout.tsx`** — `isSearchRoute` constant (pathname equality
  check) replaces `getNavSearchState().isVisible` for search screen detection.
  `navigate('/')` → `navigate('/AVS_BASE')` in `updateNavParams` and the first-navigation
  effect. `onSearch` callback now navigates to `/AVS_BASE/SEARCH` with `replace: true`
  (avoids a double history entry from the `setSearchVisibility` callback chain).
  First-navigation effect guarded on `isSearchRoute` to prevent auto-redirect away
  from the search URL on initial render.

#### Notes

- Grid mode (VOD/LIVE section selection) intentionally stays in `location.state`.
  Refresh on `/AVS_BASE` reloads the default home section. Addressable sections
  (e.g. `/AVS_BASE?section=<id>`) are a follow-up ticket.
- Three pre-existing typecheck failures from WLA-280 (`isBookmarked` prop on
  `VideoDetailsProps`) are unchanged — not introduced by this branch.
- Phase task: P0-R-3.

### feat/bookmark-button — 2026-09-10

Rationale: expose the `FavoriteButton` atom from `@white-label/ui-react` as a
bookmark control on all three content detail screens (VOD, series, EPG/live
programme). Bookmarks are persisted client-side in localStorage; the repository
layer is behind `IBookmarkRepository` so a backend favourites API can be swapped
in without touching UI or use cases.

#### Added

- **`src/domain/bookmarks/IBookmarkRepository.ts`** — `isBookmarked` / `toggle` / `getAll`
  interface; backend-agnostic contract for bookmark persistence.
- **`src/repositories/bookmarks/LocalStorageBookmarkRepository.ts`** — localStorage
  implementation under key `avs:bookmarks`; quota-error-safe.
- **`src/usecases/bookmarks/BookmarkUseCase.ts`** — thin use case delegating to the
  repository; the only layer UI calls for bookmark reads/writes.
- **`src/modules/BookmarkModule.ts`** — `GetBookmarkUseCase()` DI factory; wires
  `LocalStorageBookmarkRepository → BookmarkUseCase`. Swap point for the future
  HTTP-backed implementation.
- **`src/ui/elements/useBookmark.ts`** — React hook returning `{ isBookmarked, toggle }`
  for a given content ID; drives the `FavoriteButton` from a single `useState`.

#### Changed

- **`DetailsScreenComponent.tsx`** — wraps `<VideoDetails>` in a `position: relative`
  container; `FavoriteButton` (filled, pill, lg) overlaid `position: absolute` at
  top-right (48px inset). Bookmark key = `content.contentId`.
- **`SeriesDetailsScreenComponent.tsx`** — same overlay pattern; bookmark key =
  `seriesId`.
- **`ProgramDetailsScreenComponent.tsx`** — same overlay pattern; bookmark key =
  `epg:{contentId}` (prefixed to avoid namespace collision with VOD IDs).

#### Notes

- `VideoDetails.actions` and `VideoDetailsLive.actions` are `{ label, onClick }[]`
  typed arrays — no ReactNode slot — so the `FavoriteButton` cannot be injected
  into the organism's action row. The absolute-positioned overlay is the correct
  approach until the organism API gains a bookmark slot.
- Rebuild of `@white-label/ui-react` dist was required (`FavoriteButton` was in
  the source index but missing from the stale `node_modules` copy — rebuilt via
  `cd ../white-label-ui/platforms/react && npm run build`).
- Strings hardcoded (`"Add bookmark"` / `"Remove bookmark"`) — migrate to
  `Dictionary.getText` when P0-R-6 (Dictionary wiring) lands.

### chore/trim-agent-context — 2026-09-09

Rationale: agent context cost. Every enabled MCP server's tool schemas and the whole of
`CLAUDE.md` are re-sent on every request, and any file an agent reads stays in context and
is re-sent for the rest of the session. `CHANGELOG.md` had reached 97 KB (~24k tokens) while
`CLAUDE.md` mandates updating it every session, so each session paid to load it repeatedly.
No source, build, or runtime behaviour is touched.

#### Changed

- **`CHANGELOG.md` split — 97 KB → 24 KB.** Entries from July 2026 and earlier moved verbatim to the new `docs/CHANGELOG-archive.md` (73 KB); the `chore/repo-migration — 2026-06-19` group alone accounted for 66 KB. Split boundary is `### WLA-audioTabs-navigation — 2026-07-21`; the live file keeps August 2026 onward. Line accounting verified: 186 kept + 293 archived = 479 original. Header now documents the archive and a ~500-line threshold for the next rotation.
- **`CLAUDE.md` trimmed — 19.6 KB → 15.5 KB.** Removed prose that duplicated linked files rather than any rule: the Jira/Atlassian section now points to `docs/atlassian-mcp.md` instead of restating setup for bash and PowerShell; "Known sharp edges" keeps the two deploy blockers with their `file:line` citations (`GenericService.ts:29`, `AvsApiConfig.ts:116`) and defers the remaining eight to `phase-0-foundation.md`; the FY25 reality-check table drops the six `TRUE` rows (no actionable content) and keeps the four that contradict the scope sheet; smart-TV gaps and design-reference descriptions condensed. All 17 behavioural rules verified present after the edit.
- **`CLAUDE.md` CHANGELOG convention** now says to read only the first ~60 lines when appending, and documents the archive rotation.

#### Removed

- **`playwright` and `chrome-devtools` MCP servers** moved from `mcpServers` to a `_disabled` block in `.mcp.json`. Both duplicate Claude Code's built-in browser tools; `playwright` alone contributes ~25 tool definitions to every request's prefix. Re-enable by moving the entry back — the configs are preserved verbatim, not deleted.

#### Notes

- **`mcp-atlassian` was deliberately left enabled.** `docs/atlassian-mcp.md:9` records that the entry is parked intact so it self-activates once IT allowlists it. Because enterprise policy currently blocks it, it never loads and therefore costs no context — removing it would break a documented decision for zero saving.
- **`figma` and `context7` left enabled.** `figma` is load-bearing for FY26 #4 (Figma MCP integration) despite being the largest tool surface (~45 definitions); `context7` is only 2 definitions. If no Figma work is planned in a given month, parking `figma` in `_disabled` is a worthwhile temporary cut.
- Pre-push CHANGELOG hook (`.husky/pre-push`) still passes: it checks that `CHANGELOG.md` itself changed, which archiving does not affect.
- Pre-existing stale reference found, not fixed: `docs/ui-library-adoption.md:20` points at a `feat/ui-react-integration` CHANGELOG group that has never existed in this file (confirmed via `git log -S`). It predates this branch; the intended target is ambiguous between the `@white-label/ui-react` rebuild notes now at `CHANGELOG.md:189` and the npm-link note at `:160`.

### chore/jira-tooling-skills — 2026-09-09

#### Added

- **`.claude/skills/create-jira-ticket/SKILL.md` (405 lines) and `.claude/skills/amend-jira-ticket/SKILL.md` (307 lines)**, ported from `white-label-ui`. This repo previously had **no `SKILL.md` for either job**, and `.claude/skills/create-jira-ticket/` held a `template.md` with no `SKILL.md` next to it — an orphan directory that could not load at all. Both files were checked before porting: zero references to `white-label-ui`, `platforms/`, `tokens/`, Compose, SwiftUI, Storybook or the design system, so they are repo-neutral as-is.
- `.claude/skills/README.md` — rows for both skills in the AVS-specific table, plus a "when each skill fires" bullet pointing at the Jira credential setup in `CLAUDE.md`.

#### Removed

- **`.claude/commands/create-jira-ticket.md` and `.claude/commands/amend-jira-ticket.md`.** The ported skills are supersets of these command files — same `Step 0`–`Step 5` structure plus a sprint/estimation flow — so keeping both would have recreated the duplication this repo is trying to shed. `/create-jira-ticket` and `/amend-jira-ticket` still work; they now resolve to the skills. `.claude/commands/revise-claude-md.md` is untouched.

#### Notes

- **Stacked on `chore/revert-shared-atlassian-credentials`; merge that PR first.** Branching from `dev` instead would have produced a modify/delete conflict, since the revert edits the same two command files this branch deletes.
- **`.claude/skills/create-jira-ticket/template.md` was kept as-is, not overwritten from `white-label-ui`.** The two are semantically identical — the only differences are Prettier's (`_(mandatory)_` vs `*(mandatory)*`, table-cell padding). Verified by normalised diff.
- **Prettier reformatted the two ported files on commit** (`printWidth: 120`, and `.prettierignore` does not exclude `.claude/`). Expected; the resulting diff against `white-label-ui` is formatting, not drift.
- The real fix for the remaining ~1,592 duplicated lines of Jira tooling is a Claude Code plugin, not more copying. Recorded here so the next person does not re-derive it.

### chore/revert-shared-atlassian-credentials — 2026-09-09

#### Changed

- **Reverted `f5fdc24` — the shared Atlassian credential resolver is gone, and each repo owns its own repo-local `.env.atlassian.local` again.** The two repos stay separate. Setup is back to `cp .env.atlassian.example .env.atlassian.local` in the repo root, and `.mcp.json` passes `--env-file` `.env.atlassian.local` to `mcp-atlassian` again.
    - **Deleted `scripts/atlassian-env.sh` and `scripts/atlassian-env.ps1`.**
    - `.claude/commands/create-jira-ticket.md`, `.claude/commands/amend-jira-ticket.md`, `.claude/skills/create-jira-ticket/template.md` — every `source scripts/atlassian-env.sh` is back to `source .env.atlassian.local`, and the PowerShell resolver calls are back to the inline `foreach ($line in Get-Content .env.atlassian.local)` loader.
    - `.claude/hooks/check-atlassian-token-expiry.py` — back to the file-only version that reads `CLAUDE_PROJECT_DIR/.env.atlassian.local`; no environment-first lookup, no `$AVS_ATLASSIAN_ENV`.
    - `CLAUDE.md`, `docs/atlassian-mcp.md` — the Option A / Option B structure and every resolver reference are gone; the one-time setup is a single repo-local copy again.

#### Notes

- **Why.** The change deduplicated 85 of roughly 1,677 lines of Jira tooling while the other ~1,592 — commands, skills, `template.md`, the expiry hook — stayed duplicated, and it added two more files to the mirror set. Its `../.env.atlassian.local` fallback also required every developer to clone all repos as siblings under one parent, which is the same layout assumption the change set out to remove. A Claude Code plugin is the right fix for the duplication; there is no capacity for it now.
- **`.gitignore` keeps the `__pycache__/` entry `f5fdc24` added.** It is independently useful and unrelated to credentials, so it was deliberately excluded from the revert.
- **The `chore/shared-atlassian-credentials — 2026-09-07` entry below is left in place unmodified**, per the precedent recorded under `fix/wla-299-correct-ci-platform-docs`: CHANGELOG entries are historical records of what was believed at the time, and rewriting them would falsify the audit trail. This entry supersedes it.
- Mirrors `white-label-ui`, where the same change was already undone.

### chore/shared-atlassian-credentials — 2026-09-07

#### Changed

- **Environment variables are now the preferred credential store; the file is a fallback.** `JIRA_URL` / `JIRA_USERNAME` / `JIRA_API_TOKEN` / `JIRA_API_TOKEN_EXPIRES` set at user level mean nothing on disk, no path assumptions, and no per-repo duplication. `.mcp.json` **no longer passes `--env-file`** in either repo — `mcp-atlassian` inherits the variables from the Claude Code process, which removes the last consumer that ignored the resolver. Setting the variables is a manual step (documented in `docs/atlassian-mcp.md`), deliberately not scripted: it means handling the token in plaintext.
- **`.env.atlassian.local` moved to the workspace root and remains supported as the fallback.** It lives at `WLA/.env.atlassian.local`, one level above each repo, instead of being duplicated per repo — so if you stay on the file, the token is still rotated in exactly one place.
- **The expiry hook now reads `JIRA_API_TOKEN_EXPIRES` from the environment before looking for a file**, and honours `$AVS_ATLASSIAN_ENV`. Without this, moving credentials into the environment would have silently disabled expiry warnings, since the hook previously only ever parsed a file. Its warning text no longer assumes the value lives in `.env.atlassian.local`.
- **Added `scripts/atlassian-env.sh` + `scripts/atlassian-env.ps1` as the single place the credential location is decided.** Search order, first match wins: `$AVS_ATLASSIAN_ENV` → `./.env.atlassian.local` (repo-local override) → `../.env.atlassian.local` (workspace root). Credentials already exported in the environment win over all three, so no file is read at all — which is what makes a later move to user-level env vars or a vault a one-file change.
    - `.claude/commands/*`, `.claude/skills/*` and `docs/atlassian-mcp.md` — **13 bash and 2 PowerShell call sites collapsed** to `source scripts/atlassian-env.sh` / `. .\scripts\atlassian-env.ps1`. No call site resolves a path itself any more.
    - `CLAUDE.md`, `docs/atlassian-mcp.md` — setup is now presented as Option A (environment variables, preferred) and Option B (shared workspace-root file); the PowerShell troubleshooting entry points at the resolver instead of a hand-rolled `Import-DotEnv`.
    - `.gitignore` keeps its `.env.atlassian.local` entry so a repo-local override can never be committed.

#### Notes

- Verified end-to-end: `/rest/api/3/myself` authenticates from both repos; the `AVS_ATLASSIAN_ENV` override is honoured; pre-set environment variables take precedence and skip file reading; the not-found path prints the search order and returns 1 both sourced and executed; and the expiry hook warns correctly from an environment variable alone with no file reachable, stays silent when nothing is configured, and still reads the workspace file.
- The workspace root is **not** a git repository, so the fallback credential sits outside version control entirely rather than relying on a `.gitignore` rule.
- **Not empirically verified:** that `mcp-atlassian` authenticates from environment variables alone. It does not validate credentials at startup — it starts identically with and without them — so this rests on `--env-file` being documented as loading a `.env` into the environment, and on `JIRA_URL` / `JIRA_USERNAME` / `JIRA_API_TOKEN` being the server's own variable names. The server is blocked by Accenture enterprise policy today, so it cannot be exercised. If it misbehaves once unblocked, add `"--env-file", "../.env.atlassian.local"` back to its `args`.
- Mirrored in `white-label-ui` on the branch of the same name.

### docs/ui-library-adoption — 2026-09-07

#### Added

- **`docs/ui-library-adoption.md`** — cross-repo inventory of hardcoded UI in this app that can now be replaced with `@white-label/ui-react` components. The library has grown to **47** exports while this app uses **9**; the 18 components added over WLA-252 → WLA-281 (`Input`, `Alert`, `FavoriteButton`, `TabItem`, `ParentalGuidelines`, `SelectIndicator`, `List`/`ListItem`, `Select`, `Panel`, `PlayerControls`, `PlayPause`, `MediaSlider`, `ThumbnailPreview`, `Track`, `Stats`, `SliderIndicator`, `IconLabel`) are all unused, and several cover primitives this app still hand-rolls. Catalogue only — no sequencing, no source changes, no phase-task state changes.
    - Densest target is the EPG screen (`TvGuideLayout.tsx` 396 lines + `tvGuide.css` 613 lines), which imports nothing from the library and re-declares the design system in a local `--epg-*` token block.
    - Also covers: sign-in (100% hand-rolled), the three non-`RAIL` card/grid layouts, residue left in the already-migrated details screens, the player overlay, the submenu, and dead code.
    - Records what has **no** library equivalent (`Grid`, a `Tabs` container, `Modal`/`Dialog`) so those stay app-owned by decision rather than by omission.

#### Notes

- **Fixed a stale-dependency blocker found while auditing.** `node_modules/@white-label/ui-react/dist/` was dated Aug 12 and exported only 29 of 47 components, because the library's untracked `dist/` had never been rebuilt. Ran `npm run build` in `white-label-ui/platforms/react` (CSS 53→72 KB, types 80→99 KB) then `npm ci` here. All 47 exports now resolve; `npm run typecheck` exits 0. No committed change resulted — `package-lock.json` was only rewritten with CRLF (empty semantic diff) and was restored.
- **The refresh procedure is now documented, because the obvious command does not work.** `.npmrc` sets `install-links=true` (deliberate — it prevents the nested `node_modules/react` duplicate-hooks crash), so the `file:` dep is packed and copied. `npm install` **and `npm install --force` are both no-ops** on a stale copy; `npm ci` is required. Previously `CHANGELOG.md` only said the copy "must be kept in sync manually" without saying how.
- **`EpgPage` is deliberately excluded as an adoption target** even though the library exports it and `TvGuideLayout` already mimics its DOM. It is `white-label-ui` design-system **debt #1** — a template implemented in the library by mistake, slated for removal, since templates belong in the consuming apps. Adopting it would take on debt due to be deleted.
- **To raise with the library team:** `CardDevice`, `VideoDetailsTagItem`, `VideoDetailsAction` and `SearchMenuItem` are used in public prop signatures but missing from the root barrel. This is already being worked around here — `DetailsScreenComponent.tsx` and `SeriesDetailsScreenComponent.tsx` alias the `VideoDetailsLive` types for a `VideoDetails` render, which compiles only because the two pairs are structurally identical today.
- **Bug found, not fixed:** the EPG rating tag renders `'TV-' + Math.round(starRating * 3)`, producing TV-3 / TV-6 / TV-9 / TV-12 / TV-15 — none of which are real US TV ratings. Adopting `ParentalGuidelines` (whose union is the six real values) requires deciding what the backend field means first.
- Relates to **P3-R-2** (#7 Web EPG, IN PROGRESS) and **P3-R-6** (#16 smart-TV). Neither task changes state.

### fix/wla-299-correct-ci-platform-docs — 2026-09-06

#### Fixed

- **WLA-299: removed CI/CD platform misinformation from the agent-facing docs.** The docs named GitHub Actions as the CI target and GitHub Secrets / "Bitbucket secrets" as the destination for credentials. None of those apply. This repo is on **Bitbucket Server / Data Center** (`rit.accenture.com/avs-bitbucket`), which has **no Bitbucket Pipelines** — that is a Bitbucket Cloud product — and no repository-variables / secrets store. Verified 2026-09-06 by inspecting Repository Settings. An agent following the old text would have written inert pipeline config and pointed developers at a secrets store that does not exist.
    - `CLAUDE.md`, `.claude/rules/security.md` — security rules now name only destinations that exist today (env vars, gitignored config files) and state explicitly that no CI secrets store has been chosen.
    - `.claude/tasks/phase-1-infrastructure.md` — P1-R-1 is now **blocked on a CI-platform decision**; the first step is to ask the team / Bitbucket admins which CI system this org uses. Jenkins is recorded as an _observation only_ (the "Webhook to Jenkins for Bitbucket" add-on is registered instance-wide but disabled, with zero instances configured) — never as a chosen platform.
    - `.claude/tasks/phase-0-foundation.md`, `.claude/tasks/phase-2-cross-cutting.md`, `.claude/tasks/phase-3-feature-builds.md` — GitHub-specific runner labels (`ubuntu-latest`) and secret-store names replaced with platform-neutral wording.
    - `.claude/skills/create-jira-ticket/template.md` — the example Task summary no longer suggests "Set up Bitbucket Pipelines for token build".
    - `.claude/skills/avs-cross-stack-coordination/SKILL.md` — a cross-repo contract should be linked by its **Bitbucket** URL, not a GitHub URL.

#### Notes

- Implements **WLA-299**. Documentation-only — no source or build change.
- **`CHANGELOG.md` entries were deliberately left unmodified.** They are historical records of what was believed at the time; rewriting them would falsify the audit trail.
- **Removed the unused `.github/pull_request_template.md`.** Its own header stated it was "kept only so the `.github/` directory is not empty; it is not used". `.bitbucket/pull-request-template.md` is the live template and is unaffected. The `.github/` directory is now gone.

- **Local clone hygiene (not a repo change, no commit).** This clone carried a stale second remote named `origin` pointing at `https://github.com/BalticSong/avs-frontend-react.git` — the pre-migration GitHub repo — alongside the real Bitbucket remote named `bitbucket`. Local `dev` and `main` both tracked the **GitHub** refs, which were divergent from Bitbucket (`origin/dev` at `6483d7d` vs `bitbucket/dev` at `89522f6`), so a bare `git pull`/`git push` on `dev` would have hit the wrong host. Fixed in the working clone: the GitHub remote was removed, `bitbucket` was renamed to `origin` so this repo now matches the other two, and `dev` / `main` were re-pointed at the Bitbucket refs. Eleven long-merged `chore/*` branches lost their upstream in the process; their commits are intact. **Anyone with an older clone should check `git remote -v` and do the same.**
- Related: `white-label-ui` **WLA-298** fixed the same class of GitHub/Bitbucket error in that repo's `CLAUDE.md`.

### feat/wla-238-jira-tooling — 2026-08-25

#### Added

- **`.env.atlassian.example`** — credential template (`JIRA_URL`, `JIRA_USERNAME`, `JIRA_API_TOKEN`, `JIRA_API_TOKEN_EXPIRES`); `.env.atlassian.local` git-ignored.
- **`.claude/hooks/check-atlassian-token-expiry.py`** — `UserPromptSubmit` hook; warns when fewer than 10 days remain before token expiry; runs on macOS, Linux, and Windows (Python 3, no shell-specific commands); fires at most once per day via a dated sentinel file.
- **`.claude/commands/create-jira-ticket.md`** — `/create-jira-ticket` slash command; covers Story, Defect, Task, Sub-task, Epic and all mandatory/optional WLA fields (ADF description, all custom field IDs, account ID resolution, Windows PowerShell path).
- **`.claude/commands/amend-jira-ticket.md`** — `/amend-jira-ticket` slash command; supports field updates, status transitions, comments, and issue links via REST API.
- **`.claude/skills/create-jira-ticket/template.md`** — canonical WLA field reference (live from Jira create-meta); used by `/create-jira-ticket` to validate allowed values.
- **`.mcp.json`** — `mcp-atlassian` server entry added (blocked by Accenture enterprise policy today; self-activates when IT allowlists it; credentials shared with REST API).
- **`docs/atlassian-mcp.md`** — setup guide, REST API examples, token rotation, Windows PowerShell alternative, troubleshooting.

#### Changed

- **`.claude/settings.json`** — `UserPromptSubmit` hook registration added for token expiry check.
- **`.gitignore`** — `.env.atlassian.local` excluded.
- **`CLAUDE.md`** — Jira / Atlassian tooling section added with one-time setup instructions.

#### Notes

- Replicates the Atlassian integration from `white-label-ui` and `white-label-multiplatform` (WLA-237) into this repo so React developers can manage WLA Jira tickets from within their Claude Code session.
- No secrets committed; all credential handling goes through `.env.atlassian.local`.
- Relates to WLA-238.

### chore/rename-to-white-label-react — 2026-08-17

#### Changed

- **Renamed all internal doc references** from old repo names (`avs-frontend-react`, `avs-frontend-kmp`) to canonical Bitbucket names (`white-label-react`, `white-label-multiplatform`). Updated sister-repo host from GitHub to Bitbucket. Replaced "GitHub Secrets" with "Bitbucket secrets" in security posture section. Files updated: `CLAUDE.md`, `.github/pull_request_template.md`, `.bitbucket/pull-request-template.md`, `docs/architect-review/expected-vs-reality.md`.

### feat/video-details-live-integration — 2026-08-12

#### Added

- **`VideoDetailsLive` organism on the EPG programme details screen** — `ProgramDetailsScreenComponent` now renders the `VideoDetailsLive` organism from `@white-label/ui-react` instead of hand-rolled HTML+CSS. Props wired: `title`, `description`, `imageSrc`, `tags` (channel name + airing slot), live-progress bar (`liveProgressValue/StartTime/EndTime/RemainingTime` — on-air only), countdown (`countdown/countdownTitle` — upcoming only), `actions` (Watch Live), `expanded`/`onSeeMore`/`onSeeLess`/`expandedDetails` (detail rows for genre, rating, etc.), `onBack`. `device="tv"` follows the same convention as `DetailsScreenComponent` and `SeriesDetailsScreenComponent`. Error messages rendered below the organism (outside the organism's DOM) — see comment in the file for why.
- **`formatCountdown` helper** — small pure function in `ProgramDetailsScreenComponent.tsx` that formats milliseconds-until-start as `"Xh Ym Zs"` for the `VideoDetailsLive` countdown prop.

#### Changed

- **`DetailsScreenComponent` and `SeriesDetailsScreenComponent`** — updated to `VideoDetails` (renamed from `DetailsPage` in the UI lib). This is a companion fix required by the UI lib rebuild that also added `VideoDetailsLive`: the UI lib no longer exports `DetailsPage`. API differences addressed:
    - `buildTags` now returns `VideoDetailsLiveTagItem[]` (was `ReactNode`).
    - `actions` is now `VideoDetailsLiveAction[]` (was `ReactNode`). Loading state communicated via label (the typed array has no `disabled` field).
    - Error message moved outside the organism in both screens — same pattern as `ProgramDetailsScreenComponent`.
    - `SeriesDetailsScreenComponent`: `seriesTitle`/`seriesSelection` props dropped by the UI lib (no slot equivalent in `VideoDetails`). Season tabs and episode carousel now render below the organism in a plain `<div>`. A comment marks the spot for when the UI lib adds a slot.
- **`@white-label/ui-react` dist rebuilt** — the `dist/` in `node_modules` was stale (pre-`VideoDetailsLive`). Rebuilt `white-label-ui/platforms/react` with `npm run build` and copied into `node_modules`.

#### Removed

- **`src/ui/styles/content_page/programDetails.css`** — deleted. Styles are now owned by the `VideoDetailsLive` organism's built-in CSS.

#### Notes

- Relates to P3-R-1 (`phase-3-feature-builds.md`).
- `VideoDetailsLiveTagItem` / `VideoDetailsLiveAction` types used as aliases in `DetailsScreenComponent` and `SeriesDetailsScreenComponent` — `VideoDetails` defines matching internal types that are not yet re-exported from the package root; this should be raised with the UI lib team to export them (or the alias can be cleaned up when they are).
- The `node_modules` copy of `@white-label/ui-react` must be kept in sync manually until `npm install` reliably re-copies `file:` deps on dist change. Consider switching to a `npm link` or workspace-based setup.

### WLA-145-figma-design-epg-react — 2026-08-11

#### Changed

- **`src/ui/content_page/TvGuideLayout.tsx`** — rewrote from mobile vertical layout to desktop horizontal timeline grid matching Figma node 1593-7678 (Desktop 1440×1024). Adopts the `wl-epg-page` organism DOM structure with named slots: `detail-panel` (programme banner with poster, title, tags, description, Watch Now / View Details actions), `date-nav` (Now Showing inverse pill + scrollable day tabs), `channel-col` (Favourite Channels toggle + 276px sidebar), `time-nav` (JS-synced ruler viewport), `programme-grid` (absolute-positioned blocks, 90px rows, 74px blocks, 4px brand-purple progress bar). Scroll sync: `channelListRef.scrollTop` and `rulerViewportRef.scrollLeft` driven by programme grid scroll events; auto-scrolls to "now" on load.
- **`src/ui/styles/content_page/tvGuide.css`** — replaced mobile styles with desktop dark-theme styles (background `#131314`, brand `#a100fe`, inverse `#d9dfe9`, border `#4c586b`). Channel column 276px, row height 90px, programme block 74px. Includes blue-glass rating tags (`rgba(0,123,199,0.16)`), favourite toggle switch, day-tab active/inactive states, and now-line indicator.
- **`src/ui/content_page/TvGuideLayout.tsx`** — removed unused `CHANNEL_LABEL_WIDTH` import (ESLint warning).

### feat/search-area-integration — 2026-08-06

### Changed

- **`src/ui/screen/SearchLayout.tsx`** — migrated from `SearchPage` to `SearchArea` organism (`@white-label/ui-react`). `tabs: string[]` replaced by `tabOptions: [ToggleButtonOption, ToggleButtonOption]` (ToggleButton atom constraint — exactly 2 options; gracefully omitted if backend returns fewer than 2 tabs). Added `onHistoryPress` slot (unwired pending history feature). `FilterItem.leadIcon/trailIcon` → `startIcon/endIcon` handled transparently (filter chips passed as plain strings). Rebuilt `@white-label/ui-react` package and force-reinstalled.

### feat/search-area-integration — 2026-08-04

### Changed

- **`src/ui/screen/SearchLayout.tsx`** — rewritten as a full adapter around `SearchPage` from `@white-label/ui-react`. Wires the `SearchPage` organism to domain state: tabs from `IMenuState.getMenuData().items` (backend `/MENU/search` response), filter chips from the active tab's `menuItems` sub-items, tab/filter clicks delegated to `menuState.click()` which triggers content reload via the existing `onRetrieveItems` callback chain. Debounce logic (1 s polling, 3 s settle, ≥3 chars or empty) retained to bridge per-keystroke `onQueryChange` to `ISearchState.changeSearchString`. Accepts `children` passed through to `SearchPage`'s results slot.
- **`src/ui/screen/ScreenLayout.tsx`** — search block simplified: removed the `MapMenuLayout` for the search zone (tabs now owned by `SearchLayout`); passes `menuState` and content results (`ContentPageComponent` + `GridPageComponent`) as children into `SearchLayout`. Standalone content components suppressed while search is active to prevent duplicate rendering.

### Removed

- **`src/ui/styles/content_page/searchComponent.css`** — deleted; was imported only by the old `SearchLayout` and is no longer referenced.

### Notes

- `@white-label/ui-react` must be rebuilt (`npm run build` in `white-label-ui/platforms/react`) before running `npm install` here when the UI package source changes, as npm copies the `dist/` snapshot at install time.

## Older entries

Entries from July 2026 and earlier live in
[`docs/CHANGELOG-archive.md`](docs/CHANGELOG-archive.md).
