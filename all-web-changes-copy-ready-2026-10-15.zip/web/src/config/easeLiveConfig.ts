import type { EaseLiveConfig } from '../../../packages/shared-sdk/web/easelive';

/** Demo overlay settings. Keep these independent of the stream and ad schedule. */
export const easeLiveConfig: EaseLiveConfig = {
  accountId: 'accenture',
  projectId: '8ea341d6-5140-4c0b-8bc8-cda5418746fe',
  programId: 'a40736be-2342-41ab-8a9c-4c8a59a76a1a',
  env: 'prod',
};

export const adsEaseLiveConfig: EaseLiveConfig = {
  accountId: 'accenture',
  projectId: '21a7191d-5a1e-428c-a68c-2ead3f041c16',
  programId: 'b35b48a8-4d2b-4944-b898-444c9a25994f',
  env: 'prod',
};

/** Ease Live's kickoff timecode, corresponding to position zero in the demo video. */
export const footballKickoffTimecodeMs = 1784487976165;
