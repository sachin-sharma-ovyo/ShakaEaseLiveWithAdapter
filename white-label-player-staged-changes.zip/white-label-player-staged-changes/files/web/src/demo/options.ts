import type { EaseLiveConfig } from '../../../packages/shared-sdk/web/easelive';
import type { PlaybackContent } from '../content/PlaybackContent';
import { movieContent, seriesContent } from '../mocks/content';
import { adsEaseLiveConfig, footballEaseLiveConfig } from '../mocks/easeLiveConfig';

export interface DemoOptions {
  content: PlaybackContent;
  streamUrl: string;
  startTime?: number;
  episodeNumber?: number;
  autoplayNext: boolean;
  useMockTracks: boolean;
  hasEpisodePlaylist: boolean;
  easeLiveConfig: EaseLiveConfig;
}

export function readDemoOptions(page: URL): DemoOptions {
  const params = page.searchParams;
  const content = params.get('content') === 'movie' ? movieContent : seriesContent;
  const streamOverride = params.get('stream');
  const startTime = Number(params.get('start'));
  return {
    content,
    streamUrl: streamOverride || content.streamUrl,
    startTime: Number.isFinite(startTime) && startTime > 0 ? startTime : undefined,
    episodeNumber: params.has('episode') ? Number(params.get('episode')) : undefined,
    autoplayNext: params.get('autoplayNext') !== 'false',
    useMockTracks: !streamOverride,
    hasEpisodePlaylist: content.type === 'series' && !streamOverride,
    easeLiveConfig: params.get('easelive') === 'ads' ? adsEaseLiveConfig : footballEaseLiveConfig,
  };
}
