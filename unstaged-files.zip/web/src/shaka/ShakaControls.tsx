import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  PlaybackControl,
  type Episode,
  type VideoConfigItem,
  type VideoConfigProps,
  type VideoConfigType,
} from '@white-label/ui-react';
import type {
  IPlaybackSettingsState,
  IPlaybackTime,
} from '../player/PlaybackBridge';
import type { Marker } from './ShakaPlaybackBridge';
import { ShakaPlaybackBridge } from './ShakaPlaybackBridge';
import './ShakaControls.css';

const SKIP_SECONDS = 30;
const EMPTY_TIME: IPlaybackTime = {
  currentTime: 0, duration: 0, positionPercent: 0, isLive: false,
};

type SettingsList = Exclude<VideoConfigType, 'main'>;
type Section = {
  list: SettingsList;
  label: string;
  icon: VideoConfigItem['startIcon'];
  options: string[];
  selectedIndex: number;
  select: (index: number) => void;
};

export interface ShakaControlsLabels {
  play: string; pause: string; seek: string; mute: string; unmute: string;
  live: string; episodes: string; speed: string; quality: string;
  subtitles: string; audioLanguage: string; auto: string;
  off: string; normal: string;
}

const LABELS: ShakaControlsLabels = {
  play: 'Play', pause: 'Pause', seek: 'Seek', mute: 'Mute',
  unmute: 'Unmute', live: 'Live', episodes: 'Episodes', speed: 'Speed',
  quality: 'Quality', subtitles: 'Subtitles', audioLanguage: 'Audio Language',
  auto: 'Auto', off: 'Off', normal: 'Normal',
};

export interface ShakaControlsProps {
  bridge: ShakaPlaybackBridge;
  device?: 'tv' | 'desktop';
  title?: string;
  seriesTitle?: string;
  genres?: string[];
  seasonNumber?: number;
  episodeNumber?: number;
  episodes?: Episode[];
  onBack?: () => void,
  labels?: Partial<ShakaControlsLabels>;
  fullscreenTarget?: React.RefObject<HTMLElement | null>;
  className?: string;
}

function clock(value: number): string {
  const t = Math.max(0, Math.floor(value));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = t % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(s).padStart(2, '0');
  return h ? `${String(h).padStart(2, '0')}:${mm}:${ss}` : `${mm}:${ss}`;
}

function remaining(t: IPlaybackTime, live: string): string {
  if (t.isLive) return live;
  return t.duration > 0 ? `-${clock(t.duration - t.currentTime)}` : '-00:00';
}

function settingsSections(
  state: IPlaybackSettingsState | null,
  bridge: ShakaPlaybackBridge,
  labels: ShakaControlsLabels,
): Section[] {
  if (!state) return [];
  const settings = bridge.settings;
  const sections: Section[] = [];
  if (state.speeds.length > 0) {
    sections.push({
      list: 'speed', label: labels.speed, icon: 'playback-speed-circle',
      options: state.speeds.map((speed) => speed === 1 ? labels.normal : `${speed}x`),
      selectedIndex: state.speeds.indexOf(state.speed),
      select: (index) => settings.setSpeed(state.speeds[index]),
    });
  }
  if (state.qualities.length > 0) {
    sections.push({
      list: 'quality', label: labels.quality, icon: 'settings',
      options: [labels.auto, ...state.qualities.map((item) => item.label)],
      selectedIndex: Math.max(0, state.qualities.findIndex(
        (item) => item.id === state.quality,
      ) + 1),
      select: (index) => settings.setQuality(index === 0
        ? null : state.qualities[index - 1]?.id ?? null),
    });
  }
  if (state.subtitles.length > 0) {
    sections.push({
      list: 'subtitles', label: labels.subtitles, icon: 'subtitles',
      options: [labels.off, ...state.subtitles.map((item) => item.label)],
      selectedIndex: Math.max(0, state.subtitles.findIndex(
        (item) => item.id === state.subtitle,
      ) + 1),
      select: (index) => settings.setSubtitle(index === 0
        ? null : state.subtitles[index - 1]?.id ?? null),
    });
  }
  if (state.audioTracks.length > 1) {
    sections.push({
      list: 'audio-language', label: labels.audioLanguage, icon: 'language',
      options: state.audioTracks.map((item) => item.label),
      selectedIndex: Math.max(0, state.audioTracks.findIndex(
        (item) => item.id === state.audioTrack,
      )),
      select: (index) => {
        const id = state.audioTracks[index]?.id;
        if (id) settings.setAudioTrack(id);
      },
    });
  }
  return sections;
}

/** Ad markers are a sibling overlay, never injected into React's slider DOM. */
function SliderMarkers({ markers }: { markers: Marker[] }): React.ReactElement | null {
  const [bounds, setBounds] = useState<React.CSSProperties | null>(null);
  const wrapper = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = wrapper.current;
    if (!node) return;
    const find = () => {
      const target = node.parentElement?.querySelector<HTMLElement>('.ui-time-slider');
      if (!target) { setBounds(null); return; }
      const outer = node.parentElement!.getBoundingClientRect();
      const rect = target.getBoundingClientRect();
      setBounds({
        left: rect.left - outer.left,
        top: rect.top - outer.top,
        width: rect.width,
        height: rect.height,
      });
    };
    find();
    window.addEventListener('resize', find);
    const observer = typeof ResizeObserver !== 'undefined'
      ? new ResizeObserver(find) : null;
    if (node.parentElement && observer) observer.observe(node.parentElement);
    return () => {
      window.removeEventListener('resize', find);
      observer?.disconnect();
    };
  }, [markers.length]);
  if (!bounds || markers.length === 0) return <div ref={wrapper} />;
  return (
    <div ref={wrapper} className="shaka-ui-marker-anchor">
      <div className="shaka-ui-markers" style={bounds} aria-hidden="true">
        {markers.map((marker, index) => (
          <span key={`${marker.kind}-${marker.percent}-${index}`}
            className={`shaka-ui-marker shaka-ui-marker-${marker.kind}`}
            style={{ left: `${marker.percent}%` }} />
        ))}
      </div>
    </div>
  );
}

export const ShakaControls: React.FC<ShakaControlsProps> = ({
  bridge, device = 'desktop', title, seriesTitle, episodes = [], onBack,
  genres, seasonNumber, episodeNumber,
  labels: translations, fullscreenTarget, className,
}) => {
  const labels = { ...LABELS, ...translations };
  const [playing, setPlaying] = useState(false);
  const [buffering, setBuffering] = useState(true);
  const [time, setTime] = useState<IPlaybackTime>(EMPTY_TIME);
  const [volumePercent, setVolumePercent] = useState(100);
  const [settings, setSettings] = useState<IPlaybackSettingsState | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [episodesOpen, setEpisodesOpen] = useState(false);
  const [settingsList, setSettingsList] = useState<SettingsList | null>(null);
  const [markers, setMarkers] = useState<Marker[]>([]);
  const previousVolume = useRef(100);
  const enteredFullscreen = useRef(false);

  useEffect(() => {
    const unsubs = [
      bridge.onPlayStateChange(setPlaying),
      bridge.onTimeUpdate(setTime),
      bridge.onVolumeChange((volume) => {
        setVolumePercent(volume);
        if (volume > 0) previousVolume.current = volume;
      }),
      bridge.onBufferingChange(setBuffering),
      bridge.settings.onSettingsChange(setSettings),
      bridge.onAdMarkersChange(setMarkers),
    ];
    return () => unsubs.forEach((unsubscribe) => unsubscribe());
  }, [bridge]);

  useEffect(() => () => {
    if (enteredFullscreen.current && document.fullscreenElement) {
      void document.exitFullscreen().catch(() => undefined);
    }
  }, []);

  const togglePlay = useCallback(() => {
    if (playing) bridge.pause(); else bridge.play();
  }, [bridge, playing]);

  const skip = useCallback((seconds: number) => {
    if (time.isLive || time.duration <= 0 || bridge.isAdActive()) return;
    bridge.seekTo((time.currentTime + seconds) / time.duration * 100);
  }, [bridge, time]);

  const restart = useCallback(() => {
    if (time.isLive || time.duration <= 0 || bridge.isAdActive()) return;
    bridge.seekTo(0);
  }, [bridge, time]);

  const toggleMute = useCallback(() => {
    bridge.setVolume(volumePercent > 0 ? 0 : previousVolume.current || 100);
  }, [bridge, volumePercent]);

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) {
      enteredFullscreen.current = false;
      void document.exitFullscreen().catch(() => undefined);
      return;
    }
    const target = fullscreenTarget?.current ?? document.documentElement;
    void target.requestFullscreen().then(() => {
      enteredFullscreen.current = true;
    }).catch(() => undefined);
  }, [fullscreenTarget]);

  const seekFromPointer = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (rect.width > 0) bridge.seekTo((e.clientX - rect.left) / rect.width * 100);
  }, [bridge]);

  const seekFromKey = useCallback((e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowLeft') { e.preventDefault(); skip(-SKIP_SECONDS); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); skip(SKIP_SECONDS); }
    else if (e.key === 'Home') { e.preventDefault(); bridge.seekTo(0); }
    else if (e.key === 'End') { e.preventDefault(); bridge.seekTo(100); }
  }, [bridge, skip]);

  const sections = settingsSections(settings, bridge, labels);
  const openSection = sections.find((section) => section.list === settingsList);
  const videoConfigProps: Omit<VideoConfigProps, 'className'> = openSection ? {
    type: openSection.list,
    items: openSection.options.map((label) => ({ label })),
    selectedIndex: openSection.selectedIndex,
    onSelectItem: (index) => {
      openSection.select(index);
      setSettingsList(null);
    },
  } : {
    type: 'main',
    items: sections.map((section) => ({
      label: section.label,
      startIcon: section.icon,
      secondaryText: section.options[section.selectedIndex] ?? '',
      endIcon: 'chevron-right',
    })),
    onSelectItem: (index) => {
      const section = sections[index];
      if (section) setSettingsList(section.list);
    },
  };
  const sliderA11y = {
    role: 'slider',
    'aria-label': labels.seek,
    'aria-valuemin': 0,
    'aria-valuemax': 100,
    'aria-valuenow': Math.round(time.positionPercent),
    'aria-valuetext': clock(time.currentTime),
  };
  const episodeNumberLabel = [
    seasonNumber != null ? `S${seasonNumber}` : '',
    episodeNumber != null ? `E${episodeNumber}` : '',
  ].filter(Boolean).join(' ');
  const episodeLabel = seriesTitle ? [episodeNumberLabel, title].filter(Boolean).join(' - ') : '';
  const volumeIcon: 'mute' | 'low' | 'high' = volumePercent === 0
    ? 'mute' : volumePercent < 50 ? 'low' : 'high';

  return (
    <div className="shaka-controls">
      <PlaybackControl
        className={className ? `wlp-controls ${className}` : 'wlp-controls'}
        device={device}
        onBack={onBack}
        backwardsFocus={false}
        onwardsFocus={false}
        scrim={false}
        seriesTitle={seriesTitle || title || ''}
        episodeTitle={episodeLabel}
        tags={genres}
        remainingTime={remaining(time, labels.live)}
        seekStepSeconds={SKIP_SECONDS}
        onSeekBackward={() => skip(-SKIP_SECONDS)}
        onSeekForward={() => skip(SKIP_SECONDS)}
        onRestart={restart}
        hasPrevious={false}
        hasNext={false}
        playPauseProps={{
          label: playing ? labels.pause : labels.play,
          isPlaying: playing,
          buffering,
          onClick: togglePlay,
        }}
        timeSliderProps={time.isLive ? {
          ...sliderA11y, value: time.positionPercent,
          thumbnailPreview: false, trackThumb: false, tabIndex: -1,
          'aria-disabled': true,
        } : {
          ...sliderA11y, value: time.positionPercent,
          thumbnailPreview: false, trackThumb: false, tabIndex: 0,
          onClick: seekFromPointer, onKeyDown: seekFromKey,
        }}
        volumeControlProps={{
          volume: volumeIcon, value: volumePercent, sliderControl: true,
          onValueChange: (value) => bridge.setVolume(value),
          onVolumeClick: toggleMute,
          label: volumePercent > 0 ? labels.mute : labels.unmute,
        }}
        settingsProps={sections.length > 0 ? {
          collapsed: !settingsOpen,
          onToggle: () => {
            setSettingsOpen((open) => !open);
            setSettingsList(null);
          },
          videoConfigProps,
        } : { style: { display: 'none' } }}
        episodesProps={episodes.length > 0 ? {
          collapsed: !episodesOpen,
          onToggle: () => setEpisodesOpen((open) => !open),
          episodeSelectionProps: { episodes, sectionLabel: labels.episodes },
        } : { style: { display: 'none' } }}
        fullscreenProps={{ onToggle: toggleFullscreen }}
      />
      <SliderMarkers markers={markers} />
    </div>
  );
};
