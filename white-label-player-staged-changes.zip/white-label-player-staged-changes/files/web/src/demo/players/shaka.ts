import { createAdBreaks } from '../../ads/adBreaks';
import { adRequestConfig } from '../../mocks/advertising';
import { ShakaPlayer } from '../../shaka/ShakaPlayer';
import { ShakaContentAds } from '../../shaka/ShakaContentAds';
import { mountShakaControls } from '../../shaka/mountShakaControls';
import type { DemoPlayerFactory } from '../DemoPlayer';

export const createDemoPlayer: DemoPlayerFactory = (
  { wrapper, video, status, view, adContainer }, content,
) => {
  const player = new ShakaPlayer(video);
  player.onError((message) => { status.textContent = message; });
  const controls = mountShakaControls({ wrapper, video, player, onBack: () => window.history.back() });
  const breaks = createAdBreaks(content.advertisingInfoList, adRequestConfig.tagUrls);
  const advertising = breaks.length ? new ShakaContentAds(
    player, controls.bridge, video, adContainer, breaks, adRequestConfig.timeoutMs,
    (active) => {
      wrapper.querySelector('#shaka-controls')
        ?.toggleAttribute('hidden', active || !player.areControlsVisible());
      wrapper.classList.toggle('ad-break', active);
      view.classList.toggle('ad-break', active);
    },
  ) : undefined;

  return {
    bridge: controls.bridge,
    advertising,
    load: (streamUrl, startTime) => player.load(streamUrl, undefined, startTime),
    getPlayer: () => player,
    updateControls: (state) => controls.update(state),
    hasSubtitles: () => player.getInstance().getTextTracks().length > 0,
    async addSubtitle(track) {
      await player.getInstance().addTextTrackAsync(
        track.url, track.lang, 'subtitles', 'text/vtt', '', track.label,
      );
    },
    async destroy() {
      try { await controls.dispose(); }
      finally { await player.destroy(); }
    },
  };
};
