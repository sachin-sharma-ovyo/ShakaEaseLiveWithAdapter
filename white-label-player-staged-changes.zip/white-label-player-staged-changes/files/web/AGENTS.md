# Web engineering rules

This file governs `web/` and Web work in `packages/shared-sdk/web/`, Web package
metadata, and Web-only root tooling. Read the [Web development skill](../.agents/skills/web-development/SKILL.md)
for task routing and conditional workflows. References use repository-relative
source paths and link to the actual files.

## Scope and working tree

- Keep changes limited to Web. Do not modify native apps, Kotlin/Swift sources,
  Gradle/Xcode configuration, native packages, or native vendored artifacts.
- Inspect `git status --short` and relevant staged/unstaged diffs before editing.
  Preserve unrelated work and untracked files; do not reset, clean, blanket
  stash, stage, commit, push, or publish without the user's authorization.
- Do not edit generated output or `node_modules` to fix source. The shared UI is
  a vendored React dependency, not locally owned component source. The existing
  UI sync script also rewrites native artifacts and is unsuitable for Web-only
  work; see the architecture reference.

## Architectural anchors

- `web/src/index.ts` is the webpack demo entry, not the library entry. Library
  subpaths are `web/src/shaka/index.ts`, `web/src/bitmovin/index.ts`, and
  `web/src/easelive/index.ts`, built by tsup. A demo fix does not automatically
  reach reusable hosts.
- `IPlaybackBridge` in `web/src/player/PlaybackBridge.ts` is the host/controls
  contract. Player-specific bridges translate media/SDK events to host state.
  `IWebPlayer` in `web/src/player/IWebPlayer.ts` is the different, narrower
  player contract used by the Ease Live adapter. Keep those responsibilities
  distinct; inspect both when a change crosses them.
- Controls render ui-react `PlaybackControl`; settings adapters expose stream
  choices. Wrappers own SDK translation. `web/src/plugin/WebPlayerPlugin.ts`
  maps player behavior to Ease Live. `packages/shared-sdk/web/` supplies the
  TypeScript content/event contracts and Ease Live component, not a generated
  Kotlin dependency. It must not depend back on `web/src/`.
- The demo wires IMA through Shaka only. Public bridge mounting and
  `attachEaseLive` do not wire ad scheduling. Ad support is not implied by a
  common interface or by the presence of an underlying SDK capability.

## Rules that affect implementation

- Trace the requested behavior to its owner, its callers, state/event consumers,
  and cleanup. Keep local tasks local. Use a short impact plan for changes that
  cross contracts, lifecycle, configuration, exports, or subsystems.
- Preserve time units: media/seek/resume values are seconds; percentages are
  0–100; Ease Live timecodes and scale transition duration are milliseconds.
  Live/DVR windows are not interchangeable with VOD duration.
- Distinguish commands from observed state. Register SDK/media listeners early
  enough for load/autoplay; retain immediate subscription snapshots where
  provided. Keep SDK-only Ease Live command listeners from receiving their own
  emitted notifications.
- Treat content, ads, overlay, and React controls as separately owned resources.
  Identify who creates and destroys each. Clean up new listeners, timers,
  observers, DOM, and pending asynchronous work. Test repeated mount/teardown
  when ownership or timing changes; existing cleanup is incomplete.
- Preserve ad transport locking, overlay visibility/scaling rules, keyboard and
  accessible names, pointer pass-through, and fullscreen ownership when affected.
  Do not assume visual hiding disables commands or that menu selection proves
  captions are rendered.
- When an unfamiliar or changing dependency is involved, consult official,
  version-matched documentation during that task. Verify the installed version
  against the lockfile, map required capabilities, and document unsupported
  cases. Do not prescribe a future SDK or copy another integration's recipe.
- Library configuration comes from host arguments. `BITMOVIN_KEY` is webpack
  demo configuration only. Preserve the package's public subpaths, declaration
  files, CSS exports, and both module formats when changing public behavior.

## References and verification

Use the [skill's routing table](../.agents/skills/web-development/SKILL.md#find-the-responsible-path)
to choose subsystem references. Check the recorded limitations before treating
an existing pattern or comment as a guarantee.

Available root checks are `npm run typecheck`, `npm run build` (library), and
`npm run build:demo` (webpack demo); `npm start` serves the demo on port 8080.
There is no configured Web test, lint, or browser-test script. Choose checks
proportional to the change using [verification guidance](../.agents/skills/web-development/references/verification.md).
A documentation-only change needs link/path/frontmatter and source accuracy
checks, not dependency installation or a product rebuild.

For behavioral work, distinguish static checks, simulated state/lifecycle tests,
package-consumer checks, builds, and observed browser behavior. Report exact
failures and unverified scenarios. Keep documentation and capability claims
consistent with the final source, including after shelving an experiment.
