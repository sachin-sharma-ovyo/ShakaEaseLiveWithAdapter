import type { MovieContent, SeriesContent } from '../content/PlaybackContent';
import { advertisingInfoList } from './advertising';
import { demoEpisodes } from './episodes';
import { demoSubtitleTracks } from './subtitleTracks';
import { demoStreamUrl } from './stream';

// Both fixtures reuse the existing sample video; labels/captions are illustrative.
export const movieContent: MovieContent = {
  type: 'movie',
  title: 'Matchday: The Movie',
  genres: ['Sport', 'Documentary'],
  streamUrl: demoStreamUrl,
  advertisingInfoList,
  subtitleTracks: demoSubtitleTracks,
};

export const seriesContent: SeriesContent = {
  type: 'series',
  title: 'The Warm-Up',
  seriesTitle: 'Matchday Stories',
  genres: ['Sport', 'Documentary'],
  seasonNumber: 1,
  episodeNumber: 1,
  episodes: demoEpisodes,
  streamUrl: demoStreamUrl,
  advertisingInfoList,
  subtitleTracks: demoSubtitleTracks,
};
