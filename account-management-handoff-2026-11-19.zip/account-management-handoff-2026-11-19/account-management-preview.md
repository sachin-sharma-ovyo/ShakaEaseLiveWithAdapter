# Account management

The former fixture preview is now an authenticated screen at `/AVS_BASE/ACCOUNT_MANAGEMENT`.
The header avatar navigates here. `/preview/account-management` redirects to the same protected route;
it no longer renders a public preview outside `GlobalProvider`.

## Routing and session

The account route lives in `AppRoutes` under the normal session provider and renders through
`ScreenComponent` / `ScreenLayout`, including the app navigation and config bootstrap.
`RequireSession` waits for session restoration and redirects anonymous visitors to `/AVS_BASE/SIGNIN`.
ScreenLayout treats Account Management as a standalone screen so menu initialization does not
redirect an account deep link to Home.

## Account details

`AccountManagementScreen` loads the current session's profile using
`GetAccountProfileUseCase → GetProfileUseCase → AuthRepository → AuthService.fetchProfile()`.
The existing cookie-authenticated `GET /USER/PROFILE` supplies the data. No fixtures are displayed.
The field names were checked against the public AVS SDK schemas and the live browser response
on 2026-11-19. Live responses wrap the account in `resultObj.profile.profileData`; direct
`resultObj` account payloads from the SDK schema are also supported.

- `userProfileData.firstName` → First Name
- `userProfileData.surname` → Last Name
- `userProfileData.gender` → Gender (`M`/`F` normalized for the existing selector)
- `userProfileData.birthdate` (epoch seconds; `birthDate` also accepted) → ISO Date of Birth
- `userProfileData.email` → Email
- `mobilePhone` → Phone Number

Missing fields stay empty. Password fields start empty. Loading and failure states keep the
form hidden until real profile data is available; failures offer a retry. Pending responses
are ignored after unmount so navigation cannot populate another screen with stale data.

## Existing UI scope

The existing library composition and styling are retained: `VerticalNavigation`,
`PersonalInformation`, `Button`, and `Alert` from `@white-label/ui-react`.
The app owns view/edit state, password visibility and confirmation, Save/Cancel, and local
photo selection. Save still applies only to this mounted screen; it does not update the
backend. Its message explicitly explains that reloading restores account details.
Profile updates, password changes, uploads, deletion, and additional sidebar screens are
not implemented by this integration.

The forward-compatible props remain documented in
[accountManagementUiContract.ts](../src/ui/screen/account-management/accountManagementUiContract.ts)
and [the library handoff](account-management-ui-library-handoff.md).

## Verification

Focused tests cover avatar navigation without logout, authenticated direct access, session
restoration, anonymous redirects from both URLs, AVS profile mapping, populated view mode,
loading failure/retry, and the existing local edit controls.

```sh
npm run typecheck
CI=true node node_modules/react-scripts/bin/react-scripts.js test \
  --watchAll=false --watchman=false --runInBand \
  --moduleNameMapper='{"^react$":"<rootDir>/node_modules/react"}' \
  --runTestsByPath src/App.test.tsx src/repositories/auth/AuthRepository.test.ts \
  src/ui/screen/account-management/AccountManagementScreen.test.tsx
```
