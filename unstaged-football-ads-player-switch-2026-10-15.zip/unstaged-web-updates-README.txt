Unstaged web updates only

This ZIP contains only the current unstaged Git diff. It does not contain
the staged morning refactor, staged white-label-player.zip, or the earlier
football ZIP.

The patch adds the football Ease Live configuration and kickoff timecode,
the Ads-demo configuration selected with ?easelive=ads, and explicit
?player=shaka selection. It changes six files.

In the other repository, first ensure the morning refactor is present.
From its root, extract this ZIP and run:

  git apply --check unstaged-web-updates.patch
  git apply unstaged-web-updates.patch

The changes will remain unstaged. Review them with:

  git diff
