# Account management: UI library handoff

Implement these changes later in `white-label-ui/platforms/react`; no library source changes are included in the app patch. Preserve existing consumers and compose existing atoms/molecules.

## Current app contract

`white-label-react/src/ui/screen/account-management/AccountManagementScreen.tsx` is now an authenticated screen at `/AVS_BASE/ACCOUNT_MANAGEMENT`, inside the session provider and normal app layout. The former `/preview/account-management` URL redirects to it. Profile reads use cookie-authenticated `GET /USER/PROFILE`; the live payload is `resultObj.profile.profileData.userProfileData`, with `mobilePhone` on `profileData`.

The screen passes future props as well as today's supported props. Implement the exact names/types in the adjacent `accountManagementUiContract.ts` so a library rebuild/sync activates them without further app edits. The app owns drafts, validation, photo selection, view/edit and independent password visibility states; Save/Cancel reset visibility. Save and photo selection remain local only; profile/password updates, uploads and deletion are not connected. See [the confirmed gaps list](account-management-ui-library-gaps.md) for short, platform-neutral gaps and their responsible components. Change Password and Delete Account require placeholders only; functional actions are out of scope.

| Already passed by the app | Library must consume |
| --- | --- |
| All fields | `value`, `onChange`, `type`, `id`, `name`, `readOnly`, `disabled`, localized `label`/`placeholder` where applicable, appropriate `autoComplete`; confirmation also carries `error`/`helperText`. Forward relevant native input/ARIA props. |
| Date of birth | `type: 'date'`, an ISO `YYYY-MM-DD` profile value, `autoComplete: 'bday'`. Maintain ISO `YYYY-MM-DD` values in change events; browser owns localized display and native calendar. No age policy/min/max supplied because none was specified. Avoid a duplicate decorative calendar beside the native picker. |
| Both password fields | `type`, `endIcon`, `onEndIconTap`, `endIconAccessibilityLabel`, `autoComplete: 'new-password'`; independent visibility handlers already work at the prop boundary. |
| Form mode/actions | `mode: 'view' | 'edit'`, `disabled`, `saving` (currently false), `showActions`, `onSave`, `onCancel`, `onSubmit` (prevents navigation and calls Save). Ensure submit does not also invoke onSave a second time. |
| Edit action | `showEditAction: false`, `editLabel`, `onEdit`: the app already supplies the visible Edit button; do not duplicate it. |
| Password/delete actions | `showPasswordFields`, `showConfirmPassword`, `showChangePassword`, `changePasswordLabel`, `onChangePassword`, `showDeleteAccount`, `deleteAccountLabel`, `onDeleteAccount`. Visibility follows edit mode. Change-password callback announces local-only instructions; Delete callback only announces that deletion is unavailable. |
| Gender | `id`, `label`, `placeholder`, `aria-label`, `disabled`, `readOnly`, `value`, `onChange`, `isOpen`, `onOpenChange`, plus localized `genderOptions`. |
| Avatar/navigation | Avatar source/label/edit callback/accessibility label and navigation labels, selected state, end icons/click callbacks already supplied. |

The current library ignores unsupported additions. A native date picker and password eyes will appear only after the library forwards these props. Existing page fieldset/CSS keeps view mode usable meanwhile; preserve the library class names used by that fallback so library-only adoption remains compatible. Native date ISO values currently display as text until the update.

## Required library changes

| Component/area | Gap and requested support |
| --- | --- |
| PersonalInformation password props | TextField/Input already support `type`, `endIcon`, `onEndIconTap`, `endIconAccessibilityLabel`. Expose and forward these on both `password` and `confirmPassword`; default type to `password`. Do not build another eye button. |
| PersonalInformation view/edit states | Consume the supplied mode, visibility flags and Edit callback, hide Save/Cancel and password editing in view mode, and prevent all form interaction there. Today the app uses a disabled fieldset and scoped CSS; Select's custom combobox remains focusable. |
| PersonalInformation edit design | Show Change Password and Delete Account placeholders only; functional actions are out of scope. Keep confirmation-field visibility configurable and never prefill an actual password. |
| Date of birth | Forward the supplied native date input type and ISO values; support optional constraints when provided. A custom calendar action is only needed if replacing the native picker. The current calendar icon is decorative; only text entry works. |
| Form state | Add saving/loading and disabled actions; forward field readOnly/disabled, IDs, ARIA attributes, autocomplete and validation constraints. Provide form/submit support if owned by the organism. |
| Input accessibility | Associate visible labels with inputs using generated/stable IDs and label/htmlFor. Associate helper/error text through aria-describedby. |
| Select accessibility/behavior | Add accessible name and announced selection, appropriate option semantics, Enter/Space selection, arrow navigation, Escape/focus handling, outside-click close, and disabled/readOnly/error support. Avoid preventing keyboard activation on child options. |
| VerticalNavigation | Expose page-navigation semantics and aria-current; existing selected flags/click callbacks work. Nested expandable items and collapsed navigation are additional gaps; implement only when those screens/designs are in scope. |
| Localization | Expose field labels/placeholders and accessible action labels. Title/subtitle, Save/Cancel labels and navigation labels are already configurable. |
| Design fidelity | Reconcile sidebar label alignment, row padding, and form field sizes/type with the provided Figma/PNGs. Select currently needs app CSS for full width. Add organism responsiveness so the app need not target internal column classes. |
| Avatar | Expose the existing Avatar icon prop or a designed placeholder option through PersonalInformation. Photo source/edit callback already work. |

## Password data already sent by the app

The app now sends this shape for each password field. The library must forward it to its existing TextField, retaining password as the default type for older consumers.

```tsx
password={{
  value: draft.password,
  onChange: handlePasswordChange,
  type: passwordVisible ? 'text' : 'password',
  endIcon: passwordVisible ? 'eye' : 'eye-off',
  onEndIconTap: () => setPasswordVisible(value => !value),
  endIconAccessibilityLabel: passwordVisible ? 'Hide password' : 'Show password',
}}
```

Confirmation receives independent state and localized accessible labels. `eye` and `eye-off` glyphs already exist. The compatibility tests inspect props sent to the real organism; they do not claim that the unchanged library renders the controls yet.

## References and acceptance

Use root `figma-design.json` (frame `74:16124`) and the new-user PNG for layout; root `Desktop.png` for the filled/edit design. The filled-form folder PNG is nearly blank. Desktop frame: 1440 × 976, horizontal inset 48, top 24, bottom 32, sidebar 318, gap 24, form 1002. Use library tokens and verify responsive layout and keyboard access. Nested/collapsed navigation and avatar icon placeholders remain optional follow-ups: the current account screen does not need those props. No app data is required for internal label association, keyboard, alignment, or responsive styling fixes.

Verify backward compatibility, independent eye toggles, no value loss when toggling, view/edit/Save/Cancel transitions, disabled/loading actions, label associations and Select keyboard behavior. Rebuild and sync the library's installed app copy before browser QA; this repository uses a copied local dependency.
