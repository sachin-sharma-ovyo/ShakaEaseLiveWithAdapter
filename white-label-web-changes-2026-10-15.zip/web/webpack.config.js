const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { DefinePlugin } = require('webpack');

// Demo-only secrets from web/.env (gitignored, see .env.example). The Bitmovin license key is
// inlined into the demo bundle; the library never reads environment variables.
function readDemoEnv() {
  const file = path.resolve(__dirname, '.env');
  const parsed = fs.existsSync(file) ? dotenv.parse(fs.readFileSync(file)) : {};
  return { BITMOVIN_KEY: parsed.BITMOVIN_KEY || process.env.BITMOVIN_KEY || '' };
}

// Bundles the demo page only. The library build (`dist/`) is tsup, see tsup.config.ts.
module.exports = {
  entry: './src/index.ts',
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist-demo'),
    clean: true,
  },
  resolve: {
    extensions: ['.ts', '.tsx', '.js', '.css'],
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './index.html',
    }),
    new DefinePlugin({
      'process.env.BITMOVIN_KEY': JSON.stringify(readDemoEnv().BITMOVIN_KEY),
    }),
  ],
  devServer: {
    port: 8080,
    hot: true,
  },
};
