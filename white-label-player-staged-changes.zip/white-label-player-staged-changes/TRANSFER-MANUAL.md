# Transfer manual: staged Web player changes

This package moves the staged changes to another copy of the same codebase.
It contains exactly the Git index versions captured when the package was made.

## Package contents

- Source base commit: `840c0044cfb598ac5712b22fe8664bc9bbc571db`.
- 50 staged change records: 27 added, 13 modified,
  9 deleted, and 1 renamed.
- `files/`: 41 added/modified/renamed destination files, with repository-relative paths.
- `staged-changes.patch`: complete staged patch, including deletions and file modes.
- `DELETE-FILES.txt`: 10 old paths to remove, including the source of the rename.
- `CHANGE-LIST.txt`: every staged change, showing old/new paths for the rename.
- `MANIFEST.json`: base commit, change list, Git blob IDs, and SHA-256 hashes.
- `TRANSFER-MANUAL.md`: these instructions.

The patch represents the rename as a deletion plus an addition. Applying it gives
exactly the same files as the staged snapshot; Git can detect the rename again.

Only staged files are exported. Unchanged baseline files, `.git/`, installed
`node_modules/`, generated builds, and ignored local `.env` files are not included.
The existing codebase on the other machine supplies the unchanged files.

## Recommended method: apply the Git patch

These commands work in a terminal with Git installed (macOS/Linux, Git Bash, or
PowerShell). Replace the example paths with your actual paths.

1. Copy `white-label-player-staged-changes.zip` to the other system and extract
   it outside that system's repository. Open the extracted
   `white-label-player-staged-changes` folder.
2. Open a terminal at the root of the destination repository, the folder containing
   `package.json`, `web/`, and `packages/`:

   ```sh
   cd "/path/to/your/white-label-player"
   git status --short
   git rev-parse HEAD
   ```

   Start with a clean working tree and index. If there is local work, preserve it
   separately before applying this package. The intended base is the commit shown
   above. If the destination has a different commit, the check below must still
   pass before applying; do not force the patch onto mismatched files.
3. Check the patch without changing destination files:

   ```sh
   git apply --check --index "/path/to/extracted/white-label-player-staged-changes/staged-changes.patch"
   ```

   Successful checks print nothing. If it reports an error, stop and compare the
   destination base/local changes; do not continue with a partial manual copy.
4. Apply the patch to both the destination files and its Git staging area:

   ```sh
   git apply --index "/path/to/extracted/white-label-player-staged-changes/staged-changes.patch"
   git status --short
   git diff --cached --stat
   ```

   This transfers additions, modifications, deletions, and the rename. It does
   not commit anything. Do not also copy `files/` after applying the patch.

   If you want the changes to remain unstaged instead, use this alternative in
   place of steps 3 and 4 (choose one method, not both):

   ```sh
   git apply --check "/path/to/extracted/white-label-player-staged-changes/staged-changes.patch"
   git apply "/path/to/extracted/white-label-player-staged-changes/staged-changes.patch"
   ```

## File-copy alternative

Use this only if you cannot use the patch method:

1. Begin with the same clean baseline repository described above.
2. Copy the CONTENTS of `files/` into the repository root, retaining all relative
   paths and replacing the corresponding existing files. Do not copy the outer
   `files` folder itself into the repository.
3. Include hidden paths such as `.agents/` and `web/.env.example`; some file
   managers hide them. On macOS/Linux, from the destination repository root:

   ```sh
   cp -R "/path/to/extracted/white-label-player-staged-changes/files/." .
   ```

4. Remove every exact path listed in `DELETE-FILES.txt`. These deletions are
   essential: copying files alone does not remove the old skill/config/demo files.
   The renamed Ease Live config must end at `web/src/mocks/easeLiveConfig.ts`,
   with its old `web/src/config/easeLiveConfig.ts` path removed.
5. Compare `git status --short` with `CHANGE-LIST.txt`. This method leaves the
   transferred files unstaged; the recommended patch method can reproduce staging.

## Install, configure, and verify

No dependency manifests or lockfiles changed in this transfer. If the destination
already has the repository's matching dependencies, reuse them. If dependencies
are absent, use the existing lockfiles from the repository root:

```sh
npm ci --prefix packages/shared-sdk/web
npm ci --prefix web
```

Use the project's existing registry access/configuration if npm requires it.
For Bitmovin, configure `BITMOVIN_KEY` according to `web/.env.example`. If no
`web/.env` exists, copy that template to `web/.env` first; keep an existing local
`.env` file. Local `.env` values were not transferred by this package.
Restart the dev server after changing `.env`.

Run from the destination repository root:

```sh
npm run typecheck
npm run build
npm run build:demo
npm start
```

Open these URLs after the dev server starts:

- Shaka series + Ease Live ads overlay:
  http://localhost:8080/?player=shaka&easelive=ads
- Shaka movie + Ease Live ads overlay:
  http://localhost:8080/?player=shaka&content=movie&easelive=ads
- Bitmovin series + Ease Live ads overlay:
  http://localhost:8080/?player=bitmovin&easelive=ads
- Bitmovin movie + Ease Live ads overlay:
  http://localhost:8080/?player=bitmovin&content=movie&easelive=ads

Series defaults to episode 1. `&episode=3` selects episode 3.
Automatic next-episode playback is enabled by default; append
`&autoplayNext=false` to disable it. Manual Previous/Next still works.
Google IMA ads are integrated on Shaka only; `easelive=ads` selects the graphics
program and does not add Google ads to Bitmovin.

Check Next/Previous, automatic progression and final-episode stop, movie controls,
Settings > Subtitles, and cached browser Back/Forward navigation. On Shaka, check
preroll, midroll and postroll, including postroll completion before the next
preroll. All mock episodes reuse the sample video. External ad/overlay services
and the destination browser/license setup need to work for live playback checks.

## Optional undo of the Git-patch method

If no transferred files have been edited since application, the staged patch
method can be reversed from the destination repository root:

```sh
git apply --reverse --check --index "/path/to/extracted/white-label-player-staged-changes/staged-changes.patch"
git apply --reverse --index "/path/to/extracted/white-label-player-staged-changes/staged-changes.patch"
```

If the reverse check fails, stop and preserve subsequent work before resolving
it. No reset, clean, commit, or push is needed for this transfer.
