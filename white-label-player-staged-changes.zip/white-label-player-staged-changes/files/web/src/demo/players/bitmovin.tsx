import React from 'react';
import { createRoot } from 'react-dom/client';
import { BitmovinControls } from '../../bitmovin/BitmovinControls';
import { BitmovinPlaybackBridge } from '../../bitmovin/BitmovinPlaybackBridge';
import type { DemoPlayerFactory } from '../DemoPlayer';

export const createDemoPlayer: DemoPlayerFactory = ({ wrapper, video, status }) => {
  const licenseKey = process.env.BITMOVIN_KEY;
  if (!licenseKey) {
    throw new Error('Set BITMOVIN_KEY in web/.env (see web/.env.example), then restart npm start.');
  }
  // Bitmovin owns its video element.
  video.remove();
  const host = document.createElement('div');
  host.id = 'bitmovin-host';
  wrapper.prepend(host);
  const layer = document.createElement('div');
  layer.id = 'bitmovin-controls';
  layer.dataset.theme = 'dark';
  layer.dataset.device = 'desktop';
  wrapper.appendChild(layer);

  const bridge = new BitmovinPlaybackBridge({ licenseKey });
  const root = createRoot(layer);
  const fullscreenTarget = { current: wrapper };
  const onBack = () => window.history.back();
  let disposed = false;

  return {
    bridge,
    load(streamUrl, startTime) {
      const promise = bridge.mount(host, streamUrl, undefined, startTime);
      const player = bridge.getPlayer();
      player?.onError((message) => { if (!disposed) status.textContent = message; });
      player?.onControlsVisibility((visible) => { if (!disposed) layer.hidden = !visible; });
      return promise;
    },
    getPlayer: () => bridge.getPlayer(),
    updateControls(state) {
      if (!disposed) root.render(
        <BitmovinControls {...state} bridge={bridge} fullscreenTarget={fullscreenTarget} onBack={onBack} />,
      );
    },
    hasSubtitles: () => (bridge.getPlayer()?.getInstance().subtitles.list().length ?? 0) > 0,
    async addSubtitle(track) {
      bridge.getPlayer()?.getInstance().subtitles.add({ ...track, kind: 'subtitle', enabled: false });
    },
    async destroy() {
      if (disposed) return;
      disposed = true;
      root.unmount();
      try { await bridge.destroy(); }
      finally { layer.remove(); host.remove(); }
    },
  };
};
