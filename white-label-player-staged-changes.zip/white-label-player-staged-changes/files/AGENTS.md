# Web work entry point

For Web tasks, read [web/AGENTS.md](web/AGENTS.md) before editing. It also governs
Web changes in `packages/shared-sdk/web/`, Web package metadata, and Web-only
build configuration and scripts.

Use the repository's [Web development skill](.agents/skills/web-development/SKILL.md)
for investigation, implementation, and verification. Open that file manually if
your AI tool does not discover local skills; no specialized tooling is required.

This guidance covers Web only. Do not extend a Web task into Android, Android TV,
iOS, tvOS, Kotlin, Swift, native dependencies, or native vendored artifacts.
Preserve unrelated staged, unstaged, and untracked work. This entry point defines
no native-platform workflow.
