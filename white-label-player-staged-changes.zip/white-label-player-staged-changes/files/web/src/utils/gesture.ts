/**
 * Resolves on the first click or Enter / MediaPlay key.
 * `begin` runs inside that gesture so IMA can initialize its display container.
 */
export function waitForStartGesture(
  target: HTMLElement,
  begin: () => boolean,
  shouldStart?: (event: Event) => boolean,
): Promise<boolean> {
  return createStartGesture(target, begin, shouldStart).ready;
}

/** A navigation click can start playback directly, using the same gesture as Play. */
export function createStartGesture(
  target: HTMLElement,
  begin: () => boolean,
  shouldStart?: (event: Event) => boolean,
): { ready: Promise<boolean>; start(): void; cancel(): void } {
  let settled = false;
  let complete: (ready: boolean) => void = () => undefined;
  const ready = new Promise<boolean>((resolve) => { complete = resolve; });
  const cleanup = () => {
    target.removeEventListener('click', onClick, true);
    window.removeEventListener('keydown', onKey, true);
  };
  const start = (event?: Event) => {
    if (settled) return;
    if (event instanceof KeyboardEvent && !isStartKey(event)) return;
    if (event && shouldStart && !shouldStart(event)) return;
    settled = true;
    cleanup();
    complete(begin());
  };
  const onClick = (event: MouseEvent) => start(event);
  const onKey = (event: KeyboardEvent) => start(event);
  target.addEventListener('click', onClick, true);
  window.addEventListener('keydown', onKey, true);
  return {
    ready,
    start: () => start(),
    cancel: () => {
      if (settled) return;
      settled = true;
      cleanup();
      complete(false);
    },
  };
}

/** Enter, MediaPlay, and the Samsung TV key codes for those keys. */
function isStartKey(event: KeyboardEvent): boolean {
  return (
    event.key === 'Enter' ||
    event.key === 'MediaPlay' ||
    event.keyCode === 13 ||
    event.keyCode === 415
  );
}
