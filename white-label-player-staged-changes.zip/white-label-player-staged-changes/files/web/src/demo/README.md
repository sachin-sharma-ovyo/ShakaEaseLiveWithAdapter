# Web playback demo

Copy `web/.env.example` to `web/.env` for free local Bitmovin testing, then run
`npm start` from the repository root and open one of the URLs below. Restart the
server after changing `web/.env`. Its `BITMOVIN_KEY=localhost` placeholder works
only on `localhost` and `127.0.0.1`; other hosts need your own player license key.

| Content | Shaka | Bitmovin |
| --- | --- | --- |
| Series (default) | `http://127.0.0.1:8080/?player=shaka` | `http://127.0.0.1:8080/?player=bitmovin` |
| Movie | `http://127.0.0.1:8080/?player=shaka&content=movie` | `http://127.0.0.1:8080/?player=bitmovin&content=movie` |

## Ownership

- `src/index.ts` selects and lazy-loads a player adapter.
- `demo/options.ts` translates query parameters into content and demo configuration.
- `demo/runDemo.ts` owns page status, URL updates, overlay setup, subtitle fallback,
  and teardown for every player. Cached Back/Forward navigation keeps the session;
  a non-cached page exit disposes it.
- `content/PlaybackContent.ts` defines explicit `movie` / `series` types.
  `content/ContentNavigation.ts` supplies metadata and adjacent episode callbacks;
  it has no dependency on mock data, a player SDK, React, or browser history.
- `player/ContentPlaybackSession.ts` owns gesture startup, autoplay, and episode
  restarts through the shared bridge and an optional advertising lifecycle.
- `demo/players/` contains SDK construction, controls mounting, and subtitle API
  translation. A new player supplies the same `DemoPlayer` adapter and an entry
  in `src/index.ts`; content/session logic stays shared.
- `shaka/ShakaContentAds.ts` connects the existing Shaka IMA controller and markers
  to that lifecycle. Ad integration remains Shaka-only.

All hardcoded fixtures are in `src/mocks/`: movie/series metadata, stream URL,
episodes, subtitles (including the VTT files), ad cues/tags, and overlay programs.
Reusable controls still receive metadata and callbacks from their host.

## Behavior

- Series content shows the library's Episodes panel and starts at episode 1.
  `episode=<number>` selects another mock episode; invalid values fall back to
  the default. Movies omit episode metadata and the Episodes panel, with
  Previous/Next disabled through the UI library's availability props.
- Previous/Next update the URL and metadata, remove `start`, and autoplay from
  zero in the same player session. Previous is disabled on the first episode;
  Next is disabled on the last. All mock episodes reuse the sample video.
  Clicking either direction before initial load also starts the startup flow.
- Automatic episode progression is enabled by default for both players through
  the shared `autoplayNext` option. Append `&autoplayNext=false` to stop at the end
  of the current episode; manual Previous/Next still work. With progression
  enabled, content completion starts the next episode when one exists, without
  wrapping at the last episode. Movies, live streams and custom streams without
  a playlist never advance automatically.
- Shaka resets preroll, midroll, and postroll schedules on each transition and
  plays the fresh preroll before content. Navigation stays locked during ads;
  ad initialization failures, request errors, and timeouts still allow content.
  Automatic transitions finish the current postroll queue before requesting the
  next preroll. Ad-only/premature media end events do not advance the playlist.
- `stream=<url>` overrides the fixture stream and disables mock episode navigation
  and sample captions. `start=<seconds>` sets the initial VOD position.
- Both content types receive English/Spanish demo captions only for the default
  VOD when the stream has no subtitle tracks. Captions start Off and are illustrative,
  not a transcript. Select them through **Settings → Subtitles**.
- The pinned UI library has no standalone subtitle button or PiP control in
  `PlaybackControl`. Its Episodes panel has no image field or episode-selection
  callback; it displays the supplied number, title, and duration.
