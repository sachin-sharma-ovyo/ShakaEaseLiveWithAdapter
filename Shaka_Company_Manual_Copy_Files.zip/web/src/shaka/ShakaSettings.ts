import shaka from 'shaka-player/dist/shaka-player.ui.js';
import type {
  IPlaybackOption,
  IPlaybackSettings,
  IPlaybackSettingsState,
  Unsubscribe,
} from '../player/PlaybackBridge';

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];
type Variant = ReturnType<shaka.Player['getVariantTracks']>[number];
type TextTrack = ReturnType<shaka.Player['getTextTracks']>[number];
type Listener = (state: IPlaybackSettingsState) => void;

function languageName(code: string): string {
  if (!code || code === 'und') return 'Unknown';
  try {
    const translated = new Intl.DisplayNames([code], { type: 'language' }).of(code);
    return translated || code;
  } catch {
    return code;
  }
}

function qualityLabel(track: Variant): string {
  const height = track.height || 0;
  const bandwidth = track.bandwidth || 0;
  return height > 0
    ? `${height}p${bandwidth ? ` (${Math.round(bandwidth / 1000)} kbps)` : ''}`
    : `${Math.round(bandwidth / 1000)} kbps`;
}

function subtitleLabel(track: TextTrack): string {
  const base = languageName(track.language);
  return track.kind === 'caption' ? `${base} (CC)` : base;
}

/** Maps Shaka's tracks and configuration onto the company settings contract. */
export class ShakaSettings implements IPlaybackSettings {
  private player: shaka.Player | null = null;
  private video: HTMLVideoElement | null = null;
  private readonly listeners = new Set<Listener>();
  private readonly removeEvents: Array<() => void> = [];

  attach(player: shaka.Player, video: HTMLVideoElement): void {
    this.detach();
    this.player = player;
    this.video = video;
    const publish = () => this.emit();
    for (const name of [
      'trackschanged', 'variantchanged', 'adaptation', 'abrstatuschanged',
      'textchanged', 'texttrackvisibility', 'loading', 'loaded',
    ]) {
      player.addEventListener(name, publish);
      this.removeEvents.push(() => player.removeEventListener(name, publish));
    }
    video.addEventListener('ratechange', publish);
    this.removeEvents.push(() => video.removeEventListener('ratechange', publish));
    this.emit();
  }

  detach(): void {
    this.listeners.clear();
    this.removeEvents.splice(0).forEach((remove) => remove());
    this.player = null;
    this.video = null;
  }

  onSettingsChange(cb: Listener): Unsubscribe {
    this.listeners.add(cb);
    const state = this.read();
    if (state) cb(state);
    return () => { this.listeners.delete(cb); };
  }

  setSpeed(speed: number): void {
    if (!this.video || !SPEEDS.includes(speed) || this.player?.isLive()) return;
    this.video.playbackRate = speed;
    this.emit();
  }

  setQuality(id: string | null): void {
    const player = this.player;
    if (!player) return;
    if (id === null) {
      player.configure({ abr: { enabled: true } });
      this.emit();
      return;
    }
    const track = player.getVariantTracks().find((candidate) => String(candidate.id) === id);
    if (!track) return;
    player.configure({ abr: { enabled: false } });
    player.selectVariantTrack(track, false);
    this.emit();
  }

  setSubtitle(id: string | null): void {
    const player = this.player;
    if (!player) return;
    if (id === null) {
      void player.setTextTrackVisibility(false);
      this.emit();
      return;
    }
    const track = player.getTextTracks().find((item) => String(item.id) === id);
    if (!track) return;
    player.selectTextTrack(track);
    void player.setTextTrackVisibility(true);
    this.emit();
  }

  setAudioTrack(id: string): void {
    const player = this.player;
    if (!player) return;
    const match = player.getVariantTracks().find((track) => this.audioId(track) === id);
    if (!match) return;
    player.selectAudioLanguage(match.language || 'und', match.roles?.[0]);
    this.emit();
  }

  private audioId(track: Variant): string {
    return `${track.language || 'und'}|${(track.roles || []).join(',')}`;
  }

  private emit(): void {
    if (this.listeners.size === 0) return;
    const state = this.read();
    if (state) this.listeners.forEach((listener) => listener(state));
  }

  private read(): IPlaybackSettingsState | null {
    const player = this.player;
    const video = this.video;
    if (!player || !video) return null;
    const tracks = player.getVariantTracks();
    const selected = tracks.find((track) => track.active);
    const abrEnabled = player.getConfiguration().abr.enabled;
    const language = selected?.language;
    const selectable = language
      ? tracks.filter((track) => track.language === language)
      : tracks;
    const qualities: IPlaybackOption[] = [];
    const qualityKeys = new Set<string>();
    for (const track of selectable) {
      const key = `${track.height || 0}|${track.bandwidth || 0}`;
      if (qualityKeys.has(key)) continue;
      qualityKeys.add(key);
      qualities.push({ id: String(track.id), label: qualityLabel(track) });
    }
    qualities.sort((left, right) => {
      const l = selectable.find((t) => String(t.id) === left.id);
      const r = selectable.find((t) => String(t.id) === right.id);
      return (r?.height || 0) - (l?.height || 0);
    });
    const textTracks = player.getTextTracks();
    const subtitles: IPlaybackOption[] = textTracks.map((track) => ({
      id: String(track.id), label: subtitleLabel(track),
    }));
    const activeText = textTracks.find((track) => track.active);
    const audioTracks: IPlaybackOption[] = [];
    const used = new Set<string>();
    for (const track of tracks) {
      const id = this.audioId(track);
      if (used.has(id)) continue;
      used.add(id);
      audioTracks.push({ id, label: languageName(track.language) });
    }
    return {
      speeds: player.isLive() ? [] : SPEEDS,
      speed: video.playbackRate,
      qualities,
      quality: abrEnabled ? null : String(selected?.id ?? ''),
      subtitles,
      subtitle: player.isTextTrackVisible() && activeText ? String(activeText.id) : null,
      audioTracks,
      audioTrack: selected ? this.audioId(selected) : null,
    };
  }
}
