# Account Management patch — application manual

Packaged 19 November 2026 (Asia/Kolkata). Includes the Account Management UI work from 18 November and the protected routing, profile loading and live-response fix completed on 19 November. This is a source patch for **white-label-react**, not a deployment or a UI-library patch.

## Contents

- `account-management.patch`: all 20 changed/added app files, including the updated repository CHANGELOG and the gaps documents.
- `CHANGELOG.md`: a readable copy of the updated changelog, also included in the patch.
- `account-management-ui-library-gaps.md`: short, platform-neutral list of confirmed gaps with component ownership, suitable for review in ULL / white-label-ui. Change Password and Delete Account are placeholders only; functional actions are out of scope.
- `accountManagementUiContract.ts`: companion prop contract for that AI session.
- `account-management-ui-library-handoff.md`: detailed library adoption notes.
- `account-management-preview.md`: current authenticated account integration notes (the filename is retained from the original preview).
- `FILES_CHANGED.md`: scope and file summary.
- `MANIFEST.json`: base revision and SHA-256 values of each patched file after LF normalization.
- `SHA256SUMS`: checksums for the bundle files, excluding this checksum list itself.

## 1. Prepare the correct repository

Unzip outside the repository. The patch paths are relative to the white-label-react root. The baseline is:

```text
Branch at packaging: dev
Base commit: 98f18c45d35010e2a1cd1a24f9c8e33d535bc5cc
```

Use a clean checkout at that revision, or a compatible descendant where these account changes are not already applied. Keep a backup/commit of your own work first. Do not reset or discard existing changes to make the patch apply. This current source workspace already contains the changes; do not apply the patch here a second time.

For an exact baseline in a clean checkout:

```sh
cd /path/to/white-label-react
git status --short
git switch -c feat/account-management-handoff 98f18c45d35010e2a1cd1a24f9c8e33d535bc5cc
```

If the base commit is not available locally, fetch the appropriate existing repository remote using your normal workflow. The ZIP does not include Git history or unrelated features/dependencies.

## 2. Check and apply

Replace the example absolute bundle path with the extracted folder's actual path. `git apply` does not create a commit or stage the result.

```sh
git apply --check /absolute/path/account-management-handoff-2026-11-19/account-management.patch
git apply /absolute/path/account-management-handoff-2026-11-19/account-management.patch
git diff --stat
git status --short
```

The patch is UTF-8 text with LF endings. If your worktree uses CRLF and the normal check fails **only because of whitespace/line endings**, use the tested alternative consistently for check and application:

```sh
git apply --ignore-space-change --check /absolute/path/account-management-handoff-2026-11-19/account-management.patch
git apply --ignore-space-change /absolute/path/account-management-handoff-2026-11-19/account-management.patch
```

Do not use `--reject` or skip a failed check without reviewing the reason. Other failures usually mean the changes already exist, the baseline differs, or a same-named untracked file exists. Use a clean compatible branch and resolve those differences first.

## 3. Install dependencies and validate

Use the repository's normal supported Node/npm setup. Existing dependency declarations are unchanged. A compatible `white-label-ui` sibling checkout is needed because the app declares `file:../white-label-ui/platforms/react`; the existing vendored player package must also be present. The ZIP does not contain node_modules, third-party packages or UI-library source.

If dependencies are not installed, run the normal repository install (`npm ci`) after preparing the sibling library. If already installed and compatible, no install is required for this patch.

```sh
npm run typecheck
CI=true node node_modules/react-scripts/bin/react-scripts.js test \
  --watchAll=false --watchman=false --runInBand \
  --moduleNameMapper='{"^react$":"<rootDir>/node_modules/react"}' \
  --runTestsByPath src/App.test.tsx src/repositories/auth/AuthRepository.test.ts \
  src/ui/screen/account-management/AccountManagementScreen.test.tsx
npm run build
```

The React module override matches the packaging machine's nested dependency setup and keeps the tests on the app's React copy. CRA test files contain the required CSS export mocks. Run any further checks required by your target branch's contribution rules before committing.

Evidence from this work: TypeScript and all 17 focused tests passed after the final profile-response fix. The production build passed before that final mapper correction with existing Shaka source-map, CRA dependency and Browserslist warnings. The corrected screen was verified in the actual signed-in browser after reload. Packaging additionally checked forward/reverse patch applicability and compared all 20 patched files against the intended final content; this does not claim a fresh production build in the receiving environment.

## 4. Verify in the browser

```sh
PORT=3000 BROWSER=none npm start
```

1. Sign in using a valid account. Click the header avatar: the URL should become `/AVS_BASE/ACCOUNT_MANAGEMENT` and the session must remain signed in.
2. Confirm that First Name, Last Name, Gender, Date of Birth, Email and Phone display available values from that user, with blanks for missing fields. Passwords start empty. The profile mapper supports `resultObj.profile.profileData` and the direct SDK response shape.
3. Reload the account URL. Session restoration should complete before the protected route renders; a valid session should remain on Account Management.
4. In a separate signed-out/incognito browser, open `/AVS_BASE/ACCOUNT_MANAGEMENT` and `/preview/account-management`: both should lead to `/AVS_BASE/SIGNIN` without account details rendering.
5. Verify a failed profile request shows the retry state, and retry loads the real form after the backend recovers.
6. Verify existing local Edit/Save/Cancel behavior. Save and photo selection are local only and do not update the server. The UI library still needs the listed prop/interaction improvements; receiving compatibility props is not evidence that the library renders those features.

## 5. Give the gaps to an AI working in ULL

Paste `account-management-ui-library-gaps.md` into the AI session in **white-label-ui**, and provide `accountManagementUiContract.ts` and the handoff document as reference. Each gap identifies its responsible organism, molecule, atom or account integration. Only component gaps belong to the UI library. App routing/authentication/profile reads already work and must remain app-owned. Change Password and Delete Account require placeholders only; do not implement their functional actions. Other account integration gaps require separate app/backend work.

After library changes are built, use the app's existing `npm run ui:sync` workflow to refresh the installed dependency, then rerun app checks and browser QA. Do not silently bypass peer-resolution errors; follow the repositories' dependency workflow. No ULL changes have been made by creating this bundle.

## 6. Reverse the patch if needed

Only use this before further edits to the affected files, and only if the reverse check succeeds:

```sh
git apply --reverse --check /absolute/path/account-management-handoff-2026-11-19/account-management.patch
git apply --reverse /absolute/path/account-management-handoff-2026-11-19/account-management.patch
```

For CRLF worktrees, add `--ignore-space-change` to both reverse commands if required. If you have staged or committed the patch, reversing the worktree does not automatically update the index or undo the commit; use your normal reviewed Git revert workflow. Do not discard unrelated edits.
