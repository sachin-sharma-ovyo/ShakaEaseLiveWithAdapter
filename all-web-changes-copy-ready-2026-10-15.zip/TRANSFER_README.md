# All web changes: copy instructions

This ZIP contains the latest complete files for all staged and unstaged source
changes in the source repository. It combines the morning refactor, football
demo, Ads demo selector, and explicit Shaka player selection.

You can use this package whether or not the earlier morning changes have
already been copied to the destination. Copy the files at the paths below and
remove the obsolete files listed afterward. The destination should otherwise
have the same repository structure and existing player/UI integration.

## How to move the code

1. Extract this ZIP into a separate folder.
2. Open the destination repository root (the folder containing `web`,
   `packages`, and the root `package.json`).
3. Copy each included file to exactly the same relative path in that root.
   Create the missing `web/src/config` folder if needed. Replace individual
   files; do not replace whole folders because they contain other project code.
4. Remove the 13 obsolete files listed below, if they still exist.
5. Run the verification commands below, then review `git diff` and
   `git diff --cached` in the destination before staging or committing.

Full files replace the destination versions. If you have unrelated edits in
one of these files, compare and merge those edits before replacing it.
Copying files does not automatically stage them. `TRANSFER_README.md` is an
instruction document; copying it into the destination is optional.

## Create or replace these files

All paths are relative to the destination repository root. A file marked
"Create" may already exist if you copied an earlier package; replace it with
the included latest version in that case.

| Action | Path | What it contains |
| --- | --- | --- |
| Modify | `README.md` | Web setup, configuration, and runtime URL instructions. |
| Modify | `packages/shared-sdk/web/easelive/EaseLiveComponent.ts` | Independent Ease Live config type, without the brand dependency. |
| Modify | `packages/shared-sdk/web/easelive/index.ts` | Exports the Ease Live config type. |
| Modify | `packages/shared-sdk/web/package.json` | Removes obsolete brand exports. |
| Modify | `web/src/ads/AdController.ts` | Schedules metadata-based Shaka/IMA ad breaks. |
| Create | `web/src/ads/adBreaks.ts` | Converts, filters, and updates the ad schedule and markers. |
| Create | `web/src/ads/adRequestConfig.ts` | Separate mock VAST tags and request timeout. |
| Modify | `web/src/app.css` | Removes brand theme variables. |
| Create | `web/src/config/contentMetadata.ts` | Football HLS URL and mock advertising data. |
| Create | `web/src/config/easeLiveConfig.ts` | Football/Ads program IDs and football kickoff anchor. |
| Modify | `web/src/demo/bitmovinDemo.tsx` | Receives the selected Ease Live config and timecode anchor. |
| Modify | `web/src/index.ts` | Runtime player/demo selection and Shaka initialization. |
| Modify | `web/src/plugin/WebPlayerPlugin.ts` | Calculates football timecodes from content playback position. |
| Modify | `web/src/shaka/playercontrols/PlayerControls.css` | Removes brand color variables. |
| Modify | `web/webpack.config.js` | Removes brand JSON copying from the demo build. |

## Delete these obsolete files

Delete only the listed files if present. Leave any other files in these
directories in place.

- `brands/ads-non-skippable.json`
- `brands/ads-skippable.json`
- `brands/ads.json`
- `brands/brandA.json`
- `brands/brandB.json`
- `brands/default.json`
- `default.json`
- `packages/shared-sdk/web/brand/AdsConfig.ts`
- `packages/shared-sdk/web/brand/BrandConfig.ts`
- `packages/shared-sdk/web/brand/applyBrandTheme.ts`
- `packages/shared-sdk/web/brand/brand-config.schema.json`
- `packages/shared-sdk/web/brand/index.ts`
- `packages/shared-sdk/web/brand/loadBrandConfig.ts`

## Verify and run

From the destination repository root:

```bash
npm run typecheck --prefix web
npm run build:demo --prefix web
npm start --prefix web
```

If dependencies are missing, first run the repository's `npm run install:deps`.
The Bitmovin demo also needs the existing `BITMOVIN_KEY` setting in `web/.env`.

| Demo | URL |
| --- | --- |
| Shaka + football | `http://localhost:8080/?player=shaka` |
| Shaka + Ads demo | `http://localhost:8080/?player=shaka&easelive=ads` |
| Bitmovin + football | `http://localhost:8080/?player=bitmovin` |
| Bitmovin + Ads demo | `http://localhost:8080/?player=bitmovin&easelive=ads` |

Shaka requires the exact lowercase `?player=shaka` value; a missing or unknown
player value shows the player-selection message. Ads remain Shaka-only.

Football timecode is `1784487976165 + contentPlaybackSeconds * 1000`, sent
every 250 ms while content is active. The Ads demo uses the same default
stream and Shaka ad schedule, without the football kickoff anchor, because
no separate Ads-demo stream or timecode was supplied. A `?stream=` override
also omits that football anchor.

Mock ad positions are pre-roll at start, mid-roll at 3600 seconds, and timed
post-roll at 7200 seconds. Set the post-roll `contentTimePosition` to `0` in
content metadata to run it when the content ends.

The package includes 15 complete repository files and this instruction file.
It excludes backup ZIPs, patches, dependencies, build output, and `.git` data.
