# Ease Live changes — copy guide

This package contains the seven changed repository files from the current working copy on 15 October 2026, including staged and unstaged changes. It is an update for another checkout of this player repository, not a standalone app. The original source and Git staging state were not changed while preparing this package.

## Quick copy steps

1. Extract the ZIP and open the `ease-live-changes` folder.
2. Back up or commit your destination repo's existing changes before replacing files.
3. Open `files/`. Copy its **contents** into the destination repository root (the folder containing `web/`, `packages/`, and the root `package.json`). Merge folders and replace the seven matching files. Do not copy `files/` itself as a new folder in the repo.
4. If the destination files contain changes you want to keep, merge the relevant edits using `changes.patch` and `CHANGE-DETAILS.md` instead of replacing those files wholesale. For a differently structured repo, adapt import paths and call sites as described below.
5. Open a terminal at the destination repo root. If dependencies are not already installed, run:

   ```sh
   npm run install:deps
   ```

   This uses the destination repo's existing manifests, lockfiles, registry configuration, and vendored UI package. None of those dependencies are bundled in this ZIP.

6. Validate and start:

   ```sh
   npm run typecheck
   npm run build:demo
   npm run start
   ```

7. Open one of these Shaka URLs:

   - Football: http://localhost:8080/?player=shaka&easelive=football
   - Ads: http://localhost:8080/?player=shaka&easelive=ads
   - Default football: http://localhost:8080/?player=shaka

8. To stop the server, press Ctrl+C in its terminal.

## Exact URL spelling matters

The latest `web/src/index.ts` uses **lowercase `easelive`**:

```ts
const easeLiveConfig = params.get('easelive') === 'ads'
  ? adsEaseLiveConfig
  : footballEaseLiveConfig;
```

Only `easelive=ads` selects Ads. A missing parameter or any other value selects Football. Query names and values are case-sensitive: `easeLive=ads` with a capital L will select Football in this packaged version.

The included repository `README.md` still contains the earlier camelCase `easeLive` examples. It is included unchanged to preserve the exact current working copy. Use this guide's lowercase URLs; optionally change those examples to `easelive` in your destination README after copying.

The explicit `if (params.get('player') === 'shaka')` condition is preserved, so include `player=shaka` for Shaka. Selection happens when the page loads: navigate to the other URL or reload after changing the query. It is not an in-page live switch.

## Where each file goes

Paths inside `files/` map directly to paths under the destination repo root:

| Packaged file | Destination file | Purpose |
| --- | --- | --- |
| `files/README.md` | `README.md` | Existing repo documentation changes; see casing note above. |
| `files/packages/shared-sdk/web/content/ContentMetadata.ts` | `packages/shared-sdk/web/content/ContentMetadata.ts` | Optional media-position-zero epoch field. |
| `files/web/src/config/contentMetadata.ts` | `web/src/config/contentMetadata.ts` | Football HLS URL and kickoff timestamp. |
| `files/web/src/config/easeLiveConfig.ts` | `web/src/config/easeLiveConfig.ts` | Two plain Ease Live config exports. |
| `files/web/src/demo/bitmovinDemo.tsx` | `web/src/demo/bitmovinDemo.tsx` | Pass configured epoch into the Bitmovin adapter. |
| `files/web/src/index.ts` | `web/src/index.ts` | Simple URL selection, explicit player branches, and timecode forwarding. |
| `files/web/src/plugin/WebPlayerPlugin.ts` | `web/src/plugin/WebPlayerPlugin.ts` | Compute Ease Live time from epoch plus media position. |

## Optional patch method

`changes.patch` contains all seven files' changes relative to source commit `8a1583460d511ad5182753ff14c0ad2b6660ca91`, combining staged and unstaged changes. Use the patch method **instead of** copying the complete files. It works best when the destination has matching original code.

From the destination repo root, replace the example absolute patch path:

```sh
git apply --check "/absolute/path/to/ease-live-changes/changes.patch"
git apply "/absolute/path/to/ease-live-changes/changes.patch"
```

If the check fails, do not force it; use the diff and file-by-file notes to merge the edits into your destination's current code. A different repo may have an unrelated Git history; that is fine if the affected source layout and code match. The patch does not include dependency installation or permission changes.

## Existing npm permission issue

The earlier `webpack: Permission denied` error was fixed locally by restoring executable bits on files in `web/node_modules/.bin`. `node_modules` is not copied because installed binaries and symlinks should be created on the destination machine.

If the same error occurs after copying an old dependency folder, from the destination repo root run:

```sh
find web/node_modules/.bin -type f -exec chmod 755 {} +
npm run start
```

If a `.bin` entry is a symlink to a non-executable target, reinstall dependencies using the destination repo's setup process instead. Use `npm`, not `npn`.

## Confirm the result

- Football: the overlay should request project `8ea341d6-5140-4c0b-8bc8-cda5418746fe` and program `a40736be-2342-41ab-8a9c-4c8a59a76a1a`.
- Ads: the overlay should request project `21a7191d-5a1e-428c-a68c-2ead3f041c16` and program `b35b48a8-4d2b-4944-b898-444c9a25994f`.
- Both use account `accenture` and environment `prod`.
- At playback position 0, the mapped timecode is `1784487976165`; at 10 seconds it is `1784487986165`. Pausing holds the media position and seeking changes the corresponding timecode.
- Existing Shaka Google IMA pre/mid/post-roll behavior is preserved. Ease Live overlay selection is separate from those IMA ads.
- The Ads preset shares the football stream and kickoff mapping because no separate Ads stream or epoch was supplied. Use `stream=<URL-encoded URL>` and `timecode=<positive epoch milliseconds>` if you have different demo values.
- Optional Bitmovin URLs: `?player=bitmovin&easelive=football` and `?player=bitmovin&easelive=ads`; these still require `BITMOVIN_KEY` in the destination's `web/.env`.

## Package contents and verification

- `files/`: the seven complete replacement files, with original relative paths.
- `changes.patch`: exact combined source diff for reviewing or applying.
- `CHANGE-DETAILS.md`: per-file changes, behavior, prerequisites, and verification limits.
- `VALIDATION.txt`: local typecheck/build results and archive verification summary.
- `SHA256SUMS.txt`: checksums for the files and documentation (excluding this checksum file itself).

On macOS/Linux, verify the extracted files from inside `ease-live-changes/`:

```sh
shasum -a 256 -c SHA256SUMS.txt
```

The ZIP excludes `.env`, credentials, `.git`, `node_modules`, generated bundles, and unchanged native app files. No package manifests or lockfiles changed for this update. The other repo must already contain the shared Ease Live bridge, Shaka/Bitmovin wrappers, controls, ads code, webpack/TypeScript setup, and their dependencies, or you will need to port those prerequisites separately.
