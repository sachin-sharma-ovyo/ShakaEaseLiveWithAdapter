import { createStartGesture } from '../utils/gesture';
import type { AdvertisingState } from '../ads/AdvertisingState';
import type { IPlaybackBridge } from './PlaybackBridge';

/** Optional ad lifecycle. SDK-specific initialization and markers stay in the adapter. */
export interface ContentAdvertising extends AdvertisingState {
  initialize(): boolean;
  resetForContent(): boolean;
  playPrerolls(isCurrent: () => boolean, onPreroll: () => void): Promise<void>;
  resumeContent(): void;
  finishContent(): Promise<void>;
  destroy(): void;
}

/** Owns initial playback and episode restarts for any playback bridge. */
export class ContentPlaybackSession {
  private loaded = false;
  private restartRequested = false;
  private disposed = false;
  private restarting = false;
  private contentGeneration = 0;
  private ending: Promise<void> | null = null;
  private startGesture: ReturnType<typeof createStartGesture> | null = null;

  constructor(
    private readonly bridge: IPlaybackBridge,
    private readonly play: () => Promise<void>,
    private readonly advertising?: ContentAdvertising,
    private readonly onPreroll: () => void = () => undefined,
  ) {}

  get isActive(): boolean { return !this.disposed; }
  get canNavigate(): boolean {
    return this.isActive && !this.restarting && !this.advertising?.isAdPlaying;
  }

  async start({ load, startTime, gestureTarget, shouldStart, onWaiting, onLoading }: {
    load: (startTime?: number) => Promise<void>;
    startTime?: number;
    gestureTarget: HTMLElement;
    shouldStart: (event: Event) => boolean;
    onWaiting: () => void;
    onLoading: () => void;
  }): Promise<void> {
    if (!this.isActive) return;
    const ads = this.advertising;
    if (ads) {
      onWaiting();
      // Initialize inside the original click/key event, including Next/Previous.
      this.startGesture = createStartGesture(gestureTarget, () => ads.initialize(), shouldStart);
      const ready = await this.startGesture.ready;
      if (!this.isActive) return;
      if (ready) {
        await ads.playPrerolls(() => this.isActive, this.onPreroll);
        if (!this.isActive) return;
        ads.resumeContent();
      }
    }
    onLoading();
    await load(this.restartRequested ? undefined : startTime);
    if (!this.isActive) return;
    this.loaded = true;
    if (this.restartRequested) this.bridge.seekTo(0);
    if (ads || this.restartRequested) await this.play();
  }

  async restart(): Promise<boolean> {
    if (!this.canNavigate) return false;
    this.contentGeneration++;
    this.ending = null;
    this.restartRequested = true;
    if (!this.loaded) {
      this.startGesture?.start();
      return false;
    }
    this.restarting = true;
    try {
      const ads = this.advertising;
      // Initialized IMA is reused for automatic transitions; manual clicks can retry init.
      ads?.initialize();
      if (ads && !ads.resetForContent()) return false;
      if (ads) this.bridge.pause();
      this.bridge.seekTo(0);
      if (ads) {
        await ads.playPrerolls(() => this.isActive, this.onPreroll);
        if (!this.isActive) return false;
        // An ad SDK may restore the old content playhead after its preroll.
        this.bridge.seekTo(0);
        ads.resumeContent();
      }
      if (this.isActive) await this.play();
      return this.isActive;
    } finally {
      this.restarting = false;
    }
  }

  /** Finish this episode's ads before advancing; ignore duplicate/ad-only end events. */
  onContentEnded(onNext?: () => void): Promise<void> {
    if (!this.loaded || !this.canNavigate) return Promise.resolve();
    if (this.ending) return this.ending;
    const generation = this.contentGeneration;
    const pending = (async () => {
      await this.advertising?.finishContent();
      // A manual navigation or disposal while awaiting postroll cancels advancement.
      if (this.isActive && generation === this.contentGeneration) onNext?.();
    })().finally(() => {
      if (this.ending === pending) this.ending = null;
    });
    this.ending = pending;
    return pending;
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.startGesture?.cancel();
    this.advertising?.destroy();
  }
}
