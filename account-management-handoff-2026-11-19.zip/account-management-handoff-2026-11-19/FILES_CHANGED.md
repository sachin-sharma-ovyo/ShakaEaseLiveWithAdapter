# Files in the patch

Base: `98f18c45d35010e2a1cd1a24f9c8e33d535bc5cc` (`dev`).

20 files: 8 modified, 12 added.

```text
 CHANGELOG.md                                       |  22 ++
 docs/account-management-preview.md                 |  62 ++++
 docs/account-management-ui-library-gaps.md         |  16 +
 docs/account-management-ui-library-handoff.md      |  61 ++++
 src/App.test.tsx                                   |  69 ++++
 src/App.tsx                                        |  46 +--
 src/domain/auth/Auth.ts                            |  10 +
 src/modules/AuthModule.ts                          |   5 +
 src/repositories/auth/AuthRepository.test.ts       |  91 ++++++
 src/repositories/auth/AuthRepository.ts            |  55 +++-
 src/ui/menu/NavBarLayout.tsx                       |   5 +-
 src/ui/screen/RequireSession.tsx                   |  10 +
 src/ui/screen/ScreenLayout.tsx                     |  22 +-
 .../AccountManagementScreen.test.tsx               | 139 ++++++++
 .../account-management/AccountManagementScreen.tsx | 364 +++++++++++++++++++++
 .../accountManagementPreview.css                   |  78 +++++
 .../account-management/accountManagementRoute.ts   |   5 +
 .../accountManagementUiContract.ts                 |  57 ++++
 src/usecases/RepositoryInterfaces.ts               |   3 +-
 src/usecases/auth/GetProfileUseCase.ts             |  10 +
 20 files changed, 1102 insertions(+), 28 deletions(-)
```

Only Account Management and its changelog/documentation are included. Existing staged CRLF-only changes, dependencies, environment files, credentials, node_modules, build output, player changes, and UI-library source are excluded.
