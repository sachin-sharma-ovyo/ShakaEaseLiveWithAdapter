import type { ContentControls, PlaybackContent } from './PlaybackContent';

/** Content selection is independent of the player SDK, URL, and rendering framework. */
export function createContentNavigation({
  content, episodeNumber, enabled = true, canNavigate = () => true, onNavigate,
}: {
  content: PlaybackContent;
  episodeNumber?: number;
  enabled?: boolean;
  canNavigate?: () => boolean;
  onNavigate: (state: ContentControls) => void;
}): { getState(): ContentControls } {
  const episodes = content.type === 'series' ? content.episodes : [];
  const requestedIndex = episodes.findIndex((episode) => episode.number === episodeNumber);
  let index = requestedIndex >= 0 ? requestedIndex : 0;

  const select = (offset: number) => {
    if (!enabled || !episodes[index + offset] || !canNavigate()) return;
    index += offset;
    onNavigate(getState());
  };
  const getState = (): ContentControls => {
    const base = { title: content.title ?? '', genres: content.genres };
    if (content.type === 'movie') return base;
    const episode = enabled ? episodes[index] : undefined;
    return {
      ...base,
      title: episode?.title ?? base.title,
      seriesTitle: content.seriesTitle,
      seasonNumber: content.seasonNumber,
      episodeNumber: episode?.number ?? content.episodeNumber,
      episodes,
      onPrevious: enabled && index > 0 ? () => select(-1) : undefined,
      onNext: enabled && index + 1 < episodes.length ? () => select(1) : undefined,
    };
  };
  return { getState };
}
