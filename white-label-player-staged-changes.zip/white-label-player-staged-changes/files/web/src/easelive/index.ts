/**
 * Public Ease Live module: puts an Ease Live overlay on a bridge from `./shaka` or `./bitmovin`.
 * A separate entry so the Ease Live SDK is only loaded by hosts that use it.
 */
import { EaseLiveComponent, type EaseLiveConfig } from '../../../packages/shared-sdk/web/easelive';
import type { AppStatus } from '../../../packages/shared-sdk/web/plugininterface';
import type { IWebPlayer } from '../player/IWebPlayer';
import type { IPlaybackBridge, Unsubscribe } from '../player/PlaybackBridge';
import { createWebPlayerPlugin } from '../plugin/WebPlayerPlugin';

export interface EaseLiveHandlers {
  onStatus?(status: AppStatus): void;
  /** The overlay hit a fatal error and has been torn down. Playback carries on. */
  onFatal?(message: string): void;
}

export interface EaseLiveAttachment {
  /**
   * Ease Live asks to show or hide the host's control bar (stage clicks, PiP / L-Bar scenes).
   * The host applies it to whatever controls it renders.
   */
  onControlsVisibility(cb: (visible: boolean) => void): Unsubscribe;
  /** Removes the overlay. Call before destroying the bridge. */
  destroy(): Promise<void>;
}

// Both bridges expose their wrapped player. Checked structurally so this entry imports
// neither player.
interface PlayerHolder {
  getPlayer(): IWebPlayer | null;
}

function hasPlayer(bridge: IPlaybackBridge): bridge is IPlaybackBridge & PlayerHolder {
  return typeof (bridge as Partial<PlayerHolder>).getPlayer === 'function';
}

/**
 * Attaches Ease Live to `bridge`, rendering the overlay into `view` (an element above the
 * video). Call it right after `bridge.mount()` starts, without awaiting it: the player
 * exists by then, and Ease Live waits for the same stream load.
 */
export function attachEaseLive(
  bridge: IPlaybackBridge,
  view: HTMLElement,
  config: EaseLiveConfig,
  handlers: EaseLiveHandlers = {},
): EaseLiveAttachment {
  const player = hasPlayer(bridge) ? bridge.getPlayer() : null;
  if (!player) {
    throw new Error('attachEaseLive: call after bridge.mount() starts, on a bridge from ./shaka or ./bitmovin.');
  }

  const listeners = new Set<(visible: boolean) => void>();
  player.onControlsVisibility((visible) => listeners.forEach((cb) => cb(visible)));

  const startTimecode = config.startTimeCode ?? Date.now();
  const component = new EaseLiveComponent(
    view,
    createWebPlayerPlugin(player, null, startTimecode),
    config,
    handlers,
  );
  component.init();

  return {
    onControlsVisibility(cb) {
      listeners.add(cb);
      return () => { listeners.delete(cb); };
    },
    destroy() {
      listeners.clear();
      return component.destroy();
    },
  };
}

/** Demo programmes and stream, until the content service provides them. */
export { adsEaseLiveConfig, footballEaseLiveConfig } from '../mocks/easeLiveConfig';
export { demoStreamUrl as easeLiveDemoStreamUrl } from '../mocks/stream';

export type { EaseLiveConfig };
export type { AppStatus as EaseLiveStatus } from '../../../packages/shared-sdk/web/plugininterface';
export type { IPlaybackBridge, Unsubscribe } from '../player/PlaybackBridge';
