import type { ContentEpisode } from '../content/PlaybackContent';

/** Demo metadata only. Reusable controls receive their episode list from the host. */
export const demoEpisodes: ContentEpisode[] = [
  { number: 1, title: 'The Warm-Up', duration: '42m' },
  { number: 2, title: 'The Opening Match', duration: '1h 28m' },
  { number: 3, title: 'Derby Day', duration: '48m' },
  { number: 4, title: 'Under the Lights', duration: '45m' },
  { number: 5, title: 'The Final Whistle', duration: '52m' },
];
