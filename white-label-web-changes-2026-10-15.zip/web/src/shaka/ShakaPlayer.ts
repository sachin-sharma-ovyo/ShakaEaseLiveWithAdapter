// Full file name: the library's ESM build is consumed by bundlers that require fully specified paths.
import shaka from 'shaka-player/dist/shaka-player.ui.js';
import 'shaka-player/dist/controls.css';
import type { PlayerState } from '../../../packages/shared-sdk/web/plugininterface';
import {
  removeWatchedMarker,
  type AdBreakMarkerSchedule,
  type AdBreakPosition,
} from '../ads/adBreaks';
import type { IWebPlayer, VideoScale } from '../player/IWebPlayer';

export type { VideoScale };

type StateListener = (state: PlayerState) => void;
type DestroyListener = () => void;
type ErrorListener = (message: string) => void;
type ControlsListener = (visible: boolean) => void;

const TRANSPORT_KEYS = new Set([
  ' ',
  'Spacebar',
  'ArrowLeft',
  'ArrowRight',
  'ArrowUp',
  'ArrowDown',
  'PageUp',
  'PageDown',
  'Home',
  'End',
  'MediaPlay',
  'MediaPause',
  'MediaStop',
  'MediaFastForward',
  'MediaRewind',
  'MediaPlayPause',
]);

/** Samsung TV media keys. Enter is left alone so an ad skip control can take it. */
const TRANSPORT_KEY_CODES = new Set([415, 19, 413, 417, 412, 10252]);

interface BufferingEvent extends Event {
  buffering: boolean;
}

interface PlayerErrorEvent extends Event {
  detail?: {
    code?: number;
    message?: string;
  };
}

/**
 * Shaka playback wrapper. The adapter is the only class that talks to Ease Live.
 * Shaka's built-in UI is disabled. The host renders ui-react controls over
 * the video, while the remaining Shaka overlay does not intercept clicks.
 *
 * `getPlayheadDate()` is the Unix time source for `player.time` when the manifest
 * has `EXT-X-PROGRAM-DATE-TIME`. The adapter interpolates when that date is missing.
 */
export class ShakaPlayer implements IWebPlayer {
  private readonly video: HTMLVideoElement;
  private readonly player: shaka.Player;
  private readonly ui: shaka.ui.Overlay;
  private loadPromise: Promise<void> | null = null;
  private lastState: PlayerState | null = null;
  private transportLocked = false;
  // state for  Integrated Player Ui Controls
  private controlsVisible = true;
  // state for native shaka controls 
  private controlsWereVisible = true;
  private adBreakMarkerSchedule: AdBreakMarkerSchedule | null = null;
  private adBreakMarkerLayer: HTMLElement | null = null;
  private lastAdBreakMarkerSignature = '';
  private readonly stateListeners = new Set<StateListener>();
  private readonly destroyListeners = new Set<DestroyListener>();
  private readonly errorListeners = new Set<ErrorListener>();
  private readonly controlsListeners = new Set<ControlsListener>();

  constructor(video: HTMLVideoElement) {
    if (!shaka.Player.isBrowserSupported()) {
      throw new Error('This browser is not supported by Shaka Player.');
    }

    shaka.polyfill.installAll();
    this.video = video;
    // Native controls paint a full-video click layer. Ease Live needs that surface.
    this.video.controls = false;
    this.video.removeAttribute('controls');
    this.video.preload = 'auto';
    this.player = new shaka.Player();
    // First play was waiting 1–2s. The default live start sits 5s inside the
    // window and may fetch the previous segment when close to a boundary.
    // A short offset starts on the segment already in hand.
    this.player.configure({
      streaming: {
        rebufferingGoal: 0,
        safeSeekOffset: 1,
        inaccurateManifestTolerance: 0,
      },
    });

    const container = video.parentElement;
    if (!container) {
      throw new Error('The video element needs a parent for the Shaka UI.');
    }
    this.ui = new shaka.ui.Overlay(this.player, container, video);
    // The big play button sits in the middle of the video, where the overlay needs clicks.
    this.ui.configure({ addBigPlayButton: false, enableKeyboardPlaybackControls: false });

    this.ui.setEnabled(false);

    this.bindVideoEvents();
    this.bindPlayerEvents();
    window.addEventListener('keydown', this.onTransportKeyDown, true);
  }

  /**
   * `drmLicenseUrl` is used as the Widevine and PlayReady license server.
   * `startTime`: seconds from the start of a VOD.
   */
  load(url: string, drmLicenseUrl?: string, startTime?: number): Promise<void> {
    if (!this.loadPromise) {
      if (drmLicenseUrl) {
        this.player.configure({
          drm: {
            servers: {
              'com.widevine.alpha': drmLicenseUrl,
              'com.microsoft.playready': drmLicenseUrl,
            },
          },
        });
      }
      this.loadPromise = this.start(url, startTime);
    }
    return this.loadPromise;
  }

  whenReady(): Promise<void> {
    if (!this.loadPromise) {
      return Promise.reject(new Error('Stream load has not started.'));
    }
    return this.loadPromise;
  }

  play(): Promise<void> {
    if (this.transportLocked) {
      return Promise.resolve();
    }
    // Call play() in the click turn so the browser accepts the gesture.
    // If the media source is not attached yet, retry once the load finishes.
    const started = this.video.play();
    if (!this.loadPromise) {
      return started;
    }
    return started.catch(async () => {
      await this.loadPromise;
      if (!this.video.paused) {
        return;
      }
      await this.video.play();
    });
  }

  pause(): void {
    if (this.transportLocked) {
      return;
    }
    this.video.pause();
  }

  seekBy(seconds: number): void {
    if (this.transportLocked) {
      return;
    }
    const range = this.player.seekRange();
    const next = this.video.currentTime + seconds;
    const clamped = Math.min(range.end, Math.max(range.start, next));
    this.video.currentTime = clamped;
  }

  getCurrentTime(): number {
    return this.video.currentTime;
  }

  getPlayheadDate(): Date | null {
    return this.player.getPlayheadTimeAsDate();
  }

  getSeekWindow(): { start: number; end: number } {
    return this.player.seekRange();
  }

  isPaused(): boolean {
    return this.video.paused;
  }

  hasEnded(): boolean {
    return this.video.ended;
  }

  /**
   * Blocks content transport while a linear ad owns the surface.
   * IMA's own controls stay in `#ad-container` and are not part of this lock.
   */
  setTransportLocked(locked: boolean): void {
    if (locked === this.transportLocked) {
      return;
    }
    if (locked) {
      // Remember the  Player Ui controls visibility.
      this.controlsWereVisible = this.controlsVisible;
      // Lock playback during the advertisement.
      this.transportLocked = true;
      this.getContainer()?.classList.add('ad-break');
      // Hide the  Player Ui control
      this.setControlsVisible(false);
      return;
    }
    // Advertisement has finished.
    this.transportLocked = false;
    this.getContainer()?.classList.remove('ad-break');
    // Restore the Player Ui control
    this.setControlsVisible(this.controlsWereVisible);
  }

  isLive(): boolean {
    return this.player.isLive();
  }

  getInstance(): shaka.Player {
    return this.player;
  }

  getContainer(): HTMLElement | null {
    return this.video.parentElement;
  }

  /**
   * Adds the configured pre-, mid-, and post-roll positions to Shaka's seek bar.
   * Mid-roll offsets are content times, so they are placed relative to Shaka's
   * current seek range and automatically hidden when outside a live window.
   */
  setAdBreakMarkers(schedule: AdBreakMarkerSchedule): void {
    this.adBreakMarkerSchedule = {
      hasPreRoll: schedule.hasPreRoll,
      midRollOffsetsSec: schedule.midRollOffsetsSec
        .filter((offset) => Number.isFinite(offset) && offset >= 0)
        .sort((left, right) => left - right),
      postRollOffsetsSec: schedule.postRollOffsetsSec
        .filter((offset) => Number.isFinite(offset) && offset > 0)
        .sort((left, right) => left - right),
      hasEndPostRoll: schedule.hasEndPostRoll,
    };
    this.renderAdBreakMarkers();
  }

  /** Removes a watched ad break from the in-memory marker schedule. */
  markAdBreakWatched(position: AdBreakPosition): void {
    const schedule = this.adBreakMarkerSchedule;
    if (!schedule) {
      return;
    }
    this.adBreakMarkerSchedule = removeWatchedMarker(schedule, position);
    this.renderAdBreakMarkers();
  }

  /**
   * Scales the video surface around the pivot, so `scaleX: 0.8, pivotX: 0`
   * keeps the left edge and frees the right 20% for the overlay.
   */
  setVideoScale({ scaleX, scaleY, pivotX, pivotY, duration }: VideoScale): void {
    const style = this.video.style;
    style.transformOrigin = `${pivotX * 100}% ${pivotY * 100}%`;
    style.transition = `transform ${Number.isFinite(duration) ? Math.max(0, duration) : 0}ms ease`;
    style.transform = scaleX === 1 && scaleY === 1 ? '' : `scale(${scaleX}, ${scaleY})`;
  }

  areControlsVisible(): boolean {
    return this.controlsVisible;
  }

  /** Shaka fades the controls out again after its idle timeout. */
  setControlsVisible(visible: boolean): void {
    const next = visible && !this.transportLocked;
    if (this.controlsVisible === next) {
      return;
    }
    this.controlsVisible = next;
    this.controlsListeners.forEach((listener) => {
      listener(next);
    });
  }

  onControlsVisibility(listener: ControlsListener): void {
    this.controlsListeners.add(listener);
    // Immediately inform the host of the current state.
    listener(this.controlsVisible);
  }

  onPlaybackState(listener: StateListener): void {
    this.stateListeners.add(listener);
  }

  onError(listener: ErrorListener): void {
    this.errorListeners.add(listener);
  }

  onDestroy(listener: DestroyListener): void {
    this.destroyListeners.add(listener);
  }

  destroy(): Promise<void> {
    window.removeEventListener('keydown', this.onTransportKeyDown, true);
    this.destroyListeners.forEach((listener) => listener());
    this.destroyListeners.clear();

    this.controlsListeners.clear();

    // Also destroys the Shaka Player instance.
    return this.ui.destroy();
  }

  private async start(url: string, startTime?: number): Promise<void> {
    await this.player.attach(this.video);
    const start =
      startTime !== undefined && Number.isFinite(startTime) && startTime > 0 ? startTime : undefined;
    await this.player.load(url, start);
  }

  private readonly onTransportKeyDown = (event: KeyboardEvent): void => {
    if (!this.transportLocked || !isTransportKey(event)) {
      return;
    }
    const adContainer = this.getContainer()?.querySelector('#ad-container');
    if (adContainer && event.target instanceof Node && adContainer.contains(event.target)) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
  };

  private emitState(state: PlayerState): void {
    if (state === this.lastState) {
      return;
    }
    this.lastState = state;
    this.stateListeners.forEach((listener) => listener(state));
  }

  private bindVideoEvents(): void {
    this.video.addEventListener('playing', () => this.emitState('playing'));
    this.video.addEventListener('durationchange', () => this.renderAdBreakMarkers());
    this.video.addEventListener('timeupdate', () => {
      if (this.player.isLive()) {
        this.renderAdBreakMarkers();
      }
    });
    this.video.addEventListener('pause', () => {
      if (!this.video.ended) {
        this.emitState('paused');
      }
    });
    this.video.addEventListener('ended', () => this.emitState('stopped'));
    this.video.addEventListener('seeking', () => this.emitState('seeking'));
    this.video.addEventListener('seeked', () => {
      this.emitState(this.video.paused ? 'paused' : 'playing');
    });
  }

  private bindPlayerEvents(): void {
    this.player.addEventListener('loaded', () => this.renderAdBreakMarkers());
    this.player.addEventListener('buffering', (event) => {
      const buffering = (event as BufferingEvent).buffering;
      if (buffering) {
        this.emitState('buffering');
        return;
      }
      this.emitState(this.video.paused ? 'paused' : 'playing');
    });

    this.player.addEventListener('error', (event) => {
      const detail = (event as PlayerErrorEvent).detail;
      const message = detail?.message || `Shaka Player error ${detail?.code ?? ''}`.trim();
      this.errorListeners.forEach((listener) => listener(message));
    });
  }

  private renderAdBreakMarkers(): void {
    const schedule = this.adBreakMarkerSchedule;
    const layer = this.getAdBreakMarkerLayer();
    if (!schedule || !layer) {
      return;
    }

    const seekRange = this.player.seekRange();
    const seekRangeSize = seekRange.end - seekRange.start;
    if (!Number.isFinite(seekRangeSize) || seekRangeSize <= 0) {
      return;
    }

    const markers: Array<{ kind: 'pre' | 'mid' | 'post'; position: number }> = [];
    if (schedule.hasPreRoll) {
      markers.push({ kind: 'pre', position: 0 });
    }
    for (const offset of schedule.midRollOffsetsSec) {
      if (offset < seekRange.start || offset > seekRange.end) {
        continue;
      }
      markers.push({
        kind: 'mid',
        position: (offset - seekRange.start) / seekRangeSize,
      });
    }
    for (const offset of schedule.postRollOffsetsSec) {
      if (offset < seekRange.start || offset > seekRange.end) continue;
      markers.push({
        kind: 'post',
        position: (offset - seekRange.start) / seekRangeSize,
      });
    }
    if (schedule.hasEndPostRoll) {
      markers.push({ kind: 'post', position: 1 });
    }

    const signature = markers
      .map(({ kind, position }) => `${kind}:${position.toFixed(5)}`)
      .join('|');
    if (signature === this.lastAdBreakMarkerSignature) {
      return;
    }
    this.lastAdBreakMarkerSignature = signature;

    const fragment = document.createDocumentFragment();
    for (const { kind, position } of markers) {
      const marker = document.createElement('span');
      marker.className = `app-ad-marker app-ad-marker-${kind}`;
      marker.style.left = `${position * 100}%`;
      fragment.appendChild(marker);
    }
    layer.replaceChildren(fragment);
  }

  private getAdBreakMarkerLayer(): HTMLElement | null {
    if (this.adBreakMarkerLayer?.isConnected) {
      return this.adBreakMarkerLayer;
    }
    const seekBar = this.getContainer()?.querySelector<HTMLElement>('.shaka-seek-bar-container');
    if (!seekBar) {
      return null;
    }
    const layer = document.createElement('div');
    layer.className = 'app-ad-markers';
    layer.setAttribute('aria-hidden', 'true');
    seekBar.prepend(layer);
    this.adBreakMarkerLayer = layer;
    this.lastAdBreakMarkerSignature = '';
    return layer;
  }
}

function isTransportKey(event: KeyboardEvent): boolean {
  return TRANSPORT_KEYS.has(event.key) || TRANSPORT_KEY_CODES.has(event.keyCode);
}
