# White-label web player changes

This archive contains complete copies of the changed files, preserving their paths
relative to the repository root. It excludes build output, dependencies, and the
files listed for deletion below. Extract it at the root of the same repository
on the other system; replace existing files at the listed paths. Then delete the
obsolete files listed below.

## Modified files (replace existing copies)

| Path | Change |
| --- | --- |
| `README.md` | Documents the new web demo config and post-roll behavior. |
| `packages/shared-sdk/web/easelive/EaseLiveComponent.ts` | Uses a standalone `EaseLiveConfig` instead of a brand type. |
| `packages/shared-sdk/web/easelive/index.ts` | Exports `EaseLiveConfig`. |
| `packages/shared-sdk/web/package.json` | Removes brand exports and exports the content metadata type. |
| `web/index.html` | Removes the brand heading identifier and updates the control-layer comment. |
| `web/src/ads/AdController.ts` | Loads IMA requests from derived ad breaks and handles timed/stream-end post-rolls. |
| `web/src/app.css` | Removes brand theme variables and keeps Shaka's built-in controls hidden. |
| `web/src/demo/bitmovinDemo.tsx` | Receives title and Ease Live settings directly; no Bitmovin ad behavior was added. |
| `web/src/index.ts` | Removes brand loading, defaults to Shaka, and wires mock metadata to ads. |
| `web/src/shaka/ShakaPlaybackBridge.ts` | Shows and updates metadata-derived ad markers in the ui-react controls. |
| `web/src/shaka/ShakaPlayer.ts` | Shows and updates timed post-roll markers; clarifies disabled built-in controls. |
| `web/src/shaka/playercontrols/PlayerControls.css` | Removes unused brand color variables. |
| `web/webpack.config.js` | Stops copying brand JSON into the demo bundle. |

## Created files (copy into place)

| Path | Purpose |
| --- | --- |
| `packages/shared-sdk/web/content/ContentMetadata.ts` | Types for `streamUrl`, `advertisingInfoList`, and cue points. |
| `web/src/config/easeLiveConfig.ts` | Standalone Ease Live demo settings. |
| `web/src/config/contentMetadata.ts` | Mock metadata matching the supplied screenshot: pre-roll 0, mid-roll 3600, post-roll 7200. |
| `web/src/ads/adBreaks.ts` | Converts cue points to IMA breaks, filters due breaks, and updates markers. |
| `web/src/ads/adRequestConfig.ts` | Demo VAST URLs and timeout, kept outside `advertisingInfoList`. |

## Deleted files (remove these on the other system)

- `brands/ads-non-skippable.json`
- `brands/ads-skippable.json`
- `brands/ads.json`
- `brands/brandA.json`
- `brands/brandB.json`
- `brands/default.json`
- `default.json`
- `packages/shared-sdk/web/brand/AdsConfig.ts`
- `packages/shared-sdk/web/brand/BrandConfig.ts`
- `packages/shared-sdk/web/brand/applyBrandTheme.ts`
- `packages/shared-sdk/web/brand/brand-config.schema.json`
- `packages/shared-sdk/web/brand/index.ts`
- `packages/shared-sdk/web/brand/loadBrandConfig.ts`

Empty `brands/` and `packages/shared-sdk/web/brand/` directories may also be
removed after their files are deleted.

## Verify after copying

From the repository root, run `npm run typecheck`, `npm run build`, and
`npm run build:demo`. The mock post-roll at 7200 is timed; change its
`contentTimePosition` to `0` in `web/src/config/contentMetadata.ts` to have it
play when the stream completes.
