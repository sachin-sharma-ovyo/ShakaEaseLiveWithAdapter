import type { AdvertisingBreak, AdvertisingInfo } from '../config/contentMetadata';
import { adRequestConfig } from './adRequestConfig';

export interface ScheduledAdBreak extends AdvertisingBreak {
  tagUrl: string;
  watched: boolean;
}

/** Flatten content-service data into the schedule shared by IMA, Shaka and the controls. */
export function createAdBreaks(infoList: AdvertisingInfo[]): ScheduledAdBreak[] {
  return infoList.flatMap((info) => info.adBreaks.map((adBreak) => ({
    ...adBreak,
    tagUrl: adRequestConfig.tagUrls[adBreak.position],
    watched: false,
  })));
}

export function getAdBreaks(
  breaks: ScheduledAdBreak[],
  position: AdvertisingBreak['position'],
): ScheduledAdBreak[] {
  return breaks.filter((adBreak) => adBreak.position === position && !adBreak.watched);
}

export function markAdBreaksWatched(breaks: ScheduledAdBreak[], watched: ScheduledAdBreak[]): void {
  watched.forEach((adBreak) => {
    const scheduled = breaks.find((item) => item === adBreak);
    if (scheduled) scheduled.watched = true;
  });
}

export function getAdBreakMarkers(breaks: ScheduledAdBreak[]): {
  hasPreRoll: boolean;
  midRollOffsetsSec: number[];
  hasPostRoll: boolean;
} {
  return {
    hasPreRoll: getAdBreaks(breaks, 'PREROLL').length > 0,
    midRollOffsetsSec: getAdBreaks(breaks, 'MIDROLL').map((adBreak) => adBreak.contentTimePosition),
    hasPostRoll: getAdBreaks(breaks, 'POSTROLL').length > 0,
  };
}
