# Shaka / IMA advertising

Use when changing cues, markers, playback locking, ad/content restoration or
overlay behavior around ads. Current Web ad orchestration is **Shaka demo only**.
It is not installed by public bridge `mount` or by `attachEaseLive`, and there is
no Bitmovin Web ad wiring. An SDK's advertising capability is not repository
support until its full ownership and lifecycle path exists.

## Sources and scheduling

| Source | Role |
| --- | --- |
| [ContentMetadata.ts](../../../../packages/shared-sdk/web/content/ContentMetadata.ts) | Service-shaped `advertisingInfoList`, nested cue points; content positions in seconds |
| [content.ts](../../../../web/src/mocks/content.ts), [advertising.ts](../../../../web/src/mocks/advertising.ts) | Movie/series fixtures; service-shaped cues (pre 0, mid 90, end-post 0), sample tag URLs and 8000ms startup timeout |
| [adBreaks.ts](../../../../web/src/ads/adBreaks.ts) | Pure transformations: requests, due selection, positions and marker removal |
| [AdController.ts](../../../../web/src/ads/AdController.ts) | IMA init, requests, timed/end queues, generation/timeout handling, ad state and watched notifications |
| [ShakaContentAds.ts](../../../../web/src/shaka/ShakaContentAds.ts), [shaka.ts](../../../../web/src/demo/players/shaka.ts) | Connect controller state to wrapper/bridge locks, CSS and markers; implement the shared optional ad lifecycle |
| [ContentPlaybackSession.ts](../../../../web/src/player/ContentPlaybackSession.ts), [runDemo.ts](../../../../web/src/demo/runDemo.ts) | Common initial playback/restart sequencing, overlay setup and page teardown |
| [google-ima.d.ts](../../../../web/src/ads/google-ima.d.ts), [web/index.html](../../../../web/index.html) | Minimal local types and runtime CDN script; declarations do not load or prove the SDK |

`createAdBreaks` preserves metadata traversal order, rejects nonfinite/negative
offsets and missing kind/tag, creates a unique metadata-derived ID and maps
PREROLL/MIDROLL/POSTROLL to pre/mid/post. It does not schedule by `sequence`,
`adFormat`, `contentEndTimePosition` or `timeToNextAdUnit`. Do not infer pod or
duration behavior from those unused fields.

Positive post offsets are timed content positions; zero post means content end.
Mid-roll zero is a timed cue at zero, not a pre-roll. Timed due selection removes
all offsets `<= currentTime` and sorts them by offset; forward seeking can queue
multiple breaks, and backward seeking does not replay removed cues. Pre-rolls
are awaited in demo metadata order. Timed/end breaks serialize through a promise
queue; end-posts are queued only once per content schedule. On episode restart,
`resetForContent` rearms timed/end cues, invalidates old queued jobs and pauses
scheduling until prerolls finish. `ShakaContentAds` also resets both marker paths.
`onContentEnded` returns the same queued postroll work to both its media listener
and `ShakaContentAds.finishContent`. The shared session awaits this before automatic
episode advancement, then rearms ads and plays the next preroll before content.
All mock episodes reuse the sample video; these are in-memory session rules.

## Startup and ownership transitions

```text
metadata -> ad breaks + marker schedule -> lock/visibility subscribers
 -> first click or Enter/MediaPlay gesture -> tryInit
 -> sequential pre-roll requests -> bind content time/seek/end -> load content

due content cue -> queue -> playBreak
 -> active/loading -> requestClientSideAds
 -> ima-ad-manager-loaded -> ad-started -> active/playing
 -> ad-complete or ad-skipped -> watched marker update
 -> ad-stopped or ad-error (or startup timeout) -> idle/unlock
```

`ContentPlaybackSession` uses `createStartGesture` to invoke init inside the
click/key turn. It removes capture listeners when started or cancelled. A
Next/Previous click can start the same pending gesture explicitly; browsing
settings/episodes does not start ads. IMA initialization must remain gesture-bound;
moving it behind awaited work can lose browser authorization. `tryInit` checks
the SDK/ad manager, sets Shaka `ads.skipPlayDetection`, and calls
`initClientSide(adContainer, video, null)`. Failure returns false so the demo
continues content; initial failure does not bind later content cues. Episode
restart retries initialization in its navigation gesture and rearms the schedule.

The controller publishes `active: true` from request start, not only after an ad
has begun. The demo responds in several places:

- Shaka wrapper locks content play/pause/relative seek, remembers current
  controls visibility, hides controls, and adds `ad-break` to its container.
- Shaka playback bridge marks ad active, suppressing its percentage seek and
  host ended notification during active ads. Volume/settings remain distinct.
- Demo hides the React controls layer, toggles wrapper/view CSS classes, and
  hides Ease Live during ad ownership. CSS keeps IMA's own controls clickable.
- The overlay plugin suppresses content sync/commands and emits ad-related
  buffering/paused and hidden-controls signals. This wiring is initialized
  after pre-rolls in the current demo, so it does not observe those pre-rolls.

The wrapper's capture key handler blocks content transport keys while locked
and exempts events targeting `#ad-container`; Enter is left for IMA skip controls.
Check both pointer and keyboard behavior. A visual hide is not a replacement for
command gating, and a global key lock must not disable ad controls.

Shaka/IMA, rather than `AdController`, own actual media pause/play and restoration.
The controller never snapshots/restores content source, playhead or paused intent.
The installed Shaka 4.16.51 client-side manager pauses linear content and emits
`ad-stopped` before its own content `play()` call; it also calls
`adsLoader.contentComplete()` on media end. This was inspected in dependency
source, not observed in a browser. Verify the version's official behavior and
real event ordering for a restoration change. The controller's `ad-stopped`
callback and overlay idle report are not proof restoration has completed.

`bindContent` listens on both `timeupdate` and `seeked`. It ignores media `ended`
while ads are active and ignores premature content end when a finite duration is
more than 0.5s beyond the current position (`web/src/utils/media.ts`). This guards
against an ad reusing the content element. Do not replace it with an unconditional
post-roll on every media-ended event. The Shaka bridge also rejects premature
end notifications and suppresses them while ads are active; the session ignores
completion during startup/restart and awaits postroll before advancing.

## Failure handling and races

Each `playBreak` increments generation, resets its started flag, sets an
active break and starts a timeout. It catches request errors and finishes idle.
The timeout only covers an ad that has not started; starting clears it. Late
IMA manager/ad-start events with no matching active generation are stopped.
An `ad-stopped` before start is ignored because requesting a new tag can stop
the old manager even after the next one loads. Error finishes the active break.

`destroy` invalidates generations, unbinds content events, removes SDK listeners,
clears callback sets/timers, resolves a pending break and stops the retained IMA
manager. `bindContent` is idempotent for the same video and removes prior media
listeners when rebound. The shared session cancels pending gestures and prevents
its own post-disposal continuations from restarting content.

Important limits of that implementation:

- A started ad that never produces stop/error has no completion watchdog;
  teardown can finish it, but startup timeout no longer applies after start.
- Generation is controller state, not a correlation ID carried by every SDK
  callback. Test stale callbacks when a newer request is active; do not claim
  all late-event races are solved.
- Timed/end callers use the queue, but `playBreak` is public and not internally
  serialized. Concurrent direct calls can overwrite an unresolved finisher.
- Init failure, request failure and timeout let content proceed without a watched
  notification; their markers can remain even though timed cues were consumed.
- At idle the wrapper restores saved controls visibility, then overlay arbitration
  may hide it again. Prior paused intent is not saved by the controller, and
  the overlay plugin infers playing unless content has ended.
- Current pre/mid tags are single skippable VAST ads. Full pod/VMAP semantics
  are not established: replacing a tag with a pod still marks the break watched
  on its first complete/skip event.

For changes here, explicitly model loading/playing/failed/stopped ownership,
restoration and cancellation as needed by the task; the implemented cleanup does
not prove every SDK callback/restoration race is handled.

## Marker paths

`createAdBreakMarkerSchedule` creates pre, mid-offset, positive-post-offset and
end-post marker data. The demo copies it into both the wrapper's legacy Shaka
seek-bar renderer and the bridge used by React controls. `onWatched` removes
from both. Complete/skip marks once per active break only after start; stop or
error alone is not watched. Removing a marker at an offset removes all matching
offsets of that kind; markers do not identify individual requests at one offset.

The wrapper can inject `.app-ad-markers` into Shaka's seek bar, which is hidden
with the disabled stock controls. The active React UI uses bridge percentages
and `SliderMarkers`, a sibling layer measuring `.ui-time-slider`; it is
`aria-hidden` and pointer-transparent. Window shifts can change live marker
positions. Test invalid/unknown ranges, duplicate offsets, watched removal,
seek crossings, resizing and UI dependency selector changes when relevant.
