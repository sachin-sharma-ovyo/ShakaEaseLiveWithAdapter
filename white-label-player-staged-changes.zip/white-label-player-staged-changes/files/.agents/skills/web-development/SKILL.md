---
name: web-development
description: Investigate and implement changes to this repository's Web player application and reusable library, from local UI fixes to architectural features and integrations. Covers Web TypeScript contracts and tooling; excludes native platforms.
---

# Web development

Read [Web engineering rules](../../../web/AGENTS.md). This skill supports the
requested Web result; it does not authorize native changes, dependency upgrades,
publication, or unrelated repairs. Read only the references needed for the task.

## Find the responsible path

Start with `git status --short`, the relevant diff, and the requested observable
behavior. Search with `rg` for visible text, a prop, event, configuration field,
or exported symbol. Follow imports and callers in both directions. Determine
whether the affected consumer is the demo, a reusable package host, or both.

| Task or uncertainty | Read |
| --- | --- |
| Entry points, ownership, configuration, public types, dependencies, packaging | [Architecture and contracts](references/architecture.md) |
| UI, CSS, playback commands, settings, captions, keyboard, fullscreen, live/VOD | [Playback and controls](references/playback-controls.md) |
| Overlay readiness, synchronization, event direction, visibility, scaling | [Ease Live](references/ease-live.md) |
| Cue scheduling, ad ownership, locks, timeout, restoration, markers | [Advertising](references/advertising.md) |
| Mounting, cleanup, cancellation, listeners, resource ownership | [Lifecycle and races](references/lifecycle.md) |
| Larger features, contract evolution, unfamiliar libraries, another integration | [Extension workflow](references/extensions.md) |
| Available checks, focused tests, package consumers, browser scenarios, shelving | [Verification and work preservation](references/verification.md) |

## Scale work to the change

- **Local adjustment:** trace the immediate component/handler and its consumer;
  make the smallest coherent edit. Check the relevant appearance or behavior and
  types when applicable. Do not require an architecture plan or new test suite
  for a text, spacing, or other low-risk local change.
- **Behavior or lifecycle fix:** reproduce or define the failing transition;
  trace command → SDK/media event → bridge state → UI/overlay and teardown.
  Check affected settings, ad locks, units, subscriptions, and asynchronous
  completion. Add a focused regression test or harness when it proves the fix.
- **Large feature or architectural change:** use the extension workflow to map
  requirements, affected consumers/contracts, ownership, capability gaps, and
  verification before implementation. Deliver a complete vertical path through
  configuration, implementation, state/events, UI, cleanup, exports, and docs
  wherever the requested behavior requires them.

Ask for clarification only if missing information materially changes the result
and cannot be inferred from source or existing context. Continue independent
investigation while resolving that uncertainty. Routine implementation choices
do not require a separate approval step.

## Evidence and completion

These references describe a source snapshot, not a guarantee of runtime support.
Recheck touched code, lockfiles, and installed dependency versions. For an
unfamiliar or changing library, consult its official documentation for the
version actually in use; map documented capabilities to repository requirements
and record unsupported features and consequential decisions. Do not substitute
another integration's SDK assumptions for that research.

Keep existing behavior, known limitations, and proposed approaches distinct.
Match capability claims and documentation to the source left after the change,
including when an experiment is shelved. Report what changed, what each check
actually proved, failures or checks not run, and remaining gaps. Never describe
a mock SDK test or successful build as observed browser playback.
