import { AdController } from '../ads/AdController';
import { createAdBreakMarkerSchedule, type AdBreak } from '../ads/adBreaks';
import type { AdBreakState } from '../ads/AdvertisingState';
import type { ContentAdvertising } from '../player/ContentPlaybackSession';
import type { ShakaPlayer } from './ShakaPlayer';
import type { ShakaPlaybackBridge } from './ShakaPlaybackBridge';

/** Shaka's ad commands and marker synchronization behind the shared session lifecycle. */
export class ShakaContentAds implements ContentAdvertising {
  private readonly controller: AdController;

  constructor(
    private readonly player: ShakaPlayer,
    private readonly bridge: ShakaPlaybackBridge,
    private readonly video: HTMLVideoElement,
    private readonly adContainer: HTMLElement,
    private readonly breaks: AdBreak[],
    timeoutMs: number,
    onChange: (active: boolean) => void,
  ) {
    this.controller = new AdController(player.getInstance(), breaks, timeoutMs);
    this.setMarkers();
    this.controller.onChange((state) => {
      player.setTransportLocked(state.active);
      bridge.setAdActive(state.active);
      onChange(state.active);
    });
    this.controller.onWatched((position) => {
      player.markAdBreakWatched(position);
      bridge.markAdBreakWatched(position);
    });
  }

  get isAdPlaying(): boolean { return this.controller.isAdPlaying; }

  onChange(listener: (state: AdBreakState) => void): () => void {
    return this.controller.onChange(listener);
  }

  initialize(): boolean { return this.controller.tryInit(this.adContainer, this.video); }

  resetForContent(): boolean {
    if (!this.controller.resetForContent(this.breaks)) return false;
    this.setMarkers();
    return true;
  }

  async playPrerolls(isCurrent: () => boolean, onPreroll: () => void): Promise<void> {
    for (const adBreak of this.breaks.filter((item) => item.kind === 'pre')) {
      if (!isCurrent()) return;
      onPreroll();
      await this.controller.playBreak(adBreak);
    }
  }

  resumeContent(): void {
    this.controller.bindContent(this.video);
    this.controller.resumeContentScheduling();
  }

  finishContent(): Promise<void> { return this.controller.onContentEnded(); }

  destroy(): void { this.controller.destroy(); }

  private setMarkers(): void {
    const markers = createAdBreakMarkerSchedule(this.breaks);
    this.player.setAdBreakMarkers(markers);
    this.bridge.setAdBreakMarkers(markers);
  }
}
