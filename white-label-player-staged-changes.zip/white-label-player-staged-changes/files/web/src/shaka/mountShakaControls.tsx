import React from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { ShakaPlayer } from './ShakaPlayer';
import { ShakaPlaybackBridge } from './ShakaPlaybackBridge';
import { ShakaControls, type ShakaControlsProps } from './ShakaControls';

type ControlsOptions = Pick<ShakaControlsProps,
  'title' | 'episodes' | 'onBack' | 'seriesTitle' | 'genres'
  | 'seasonNumber' | 'episodeNumber' | 'onPrevious' | 'onNext'
>;

export interface MountedShakaControls {
  bridge: ShakaPlaybackBridge;
  /** Update metadata and host callbacks while retaining the player and React subscriptions. */
  update(props: Partial<ControlsOptions>): void;
  dispose(): Promise<void>;
}

/** Mount controls without constructing a second Shaka player or video. */
export function mountShakaControls({
  wrapper, video, player, title, episodes, onBack, onPrevious, onNext,
  seriesTitle, genres, seasonNumber, episodeNumber,
}: {
  wrapper: HTMLElement;
  video: HTMLVideoElement;
  player: ShakaPlayer;
} & ControlsOptions): MountedShakaControls {
  const layer = document.createElement('div');
  layer.id = 'shaka-controls';
  layer.className = 'shaka-controls-layer';
  wrapper.appendChild(layer);
  const bridge = new ShakaPlaybackBridge();
  bridge.connect(player, video);
  const root: Root = createRoot(layer);
  const fullscreenTarget = { current: wrapper };
  let props: ControlsOptions = {
    title, episodes, onBack, onPrevious, onNext, seriesTitle, genres, seasonNumber, episodeNumber,
  };
  const render = () => root.render(
    <ShakaControls {...props} bridge={bridge} fullscreenTarget={fullscreenTarget} />,
  );
  render();
  let disposed = false;
  // Existing IWebPlayer controls state remains the Ease Live contract.
  player.onControlsVisibility((visible) => {
    if (!disposed) layer.hidden = !visible || bridge.isAdActive();
  });
  return {
    bridge,
    update(nextProps) {
      if (disposed) return;
      props = { ...props, ...nextProps };
      render();
    },
    async dispose() {
      if (disposed) return;
      disposed = true;
      root.unmount();
      await bridge.destroy(); // The existing ShakaPlayer is NOT destroyed here.
      layer.remove();
    },
  };
}
