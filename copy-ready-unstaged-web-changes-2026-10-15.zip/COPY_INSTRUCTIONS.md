# Copy-ready web changes

This archive contains complete files, not a patch. It includes only the six
files with unstaged edits from the source repository. The earlier staged-only
files, the old ZIPs, and generated build output are not included.

## Before copying

Apply or stage the earlier morning refactor in the destination repository
first. These are full file snapshots, so they also contain the morning code
already present in those six files. If the destination has other local edits
to any listed file, compare and merge instead of overwriting them.

## Copy into the destination repository

Extract this ZIP somewhere outside the destination repository. Copy each file
to the same relative path from the destination repository root, replacing the
destination version:

| ZIP path | Purpose |
| --- | --- |
| `README.md` | Documents the football demo, Ads demo switch, and required player parameter. |
| `web/src/config/contentMetadata.ts` | Sets the football HLS stream URL. |
| `web/src/config/easeLiveConfig.ts` | Contains football and Ads Ease Live IDs plus football kickoff timecode. |
| `web/src/demo/bitmovinDemo.tsx` | Passes the selected timecode anchor to the shared player plugin. |
| `web/src/index.ts` | Selects the Ease Live demo and requires `?player=shaka` for Shaka. |
| `web/src/plugin/WebPlayerPlugin.ts` | Emits the anchored football timecode during content playback. |

Do not copy this instruction file into the app unless you want to keep it.
Copying files does not stage them.

## Verify

From the destination repository root, run `npm run typecheck --prefix web`.
Use `git diff` to review the new unstaged edits before staging them.

Open `http://localhost:8080/?player=shaka` for football or
`http://localhost:8080/?player=shaka&easelive=ads` for the Ads demo.
Bitmovin uses `?player=bitmovin` with the optional `&easelive=ads` switch.
The Ads demo shares the current stream and Shaka ad schedule; no Ads-demo
stream or timecode was supplied, so the football kickoff anchor is not used
for that demo.
