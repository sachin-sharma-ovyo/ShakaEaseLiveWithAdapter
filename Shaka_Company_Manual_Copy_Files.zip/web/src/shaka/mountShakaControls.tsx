import React from 'react';
import { createRoot, type Root } from 'react-dom/client';
import type { Episode } from '@white-label/ui-react';
import { ShakaPlayer } from './ShakaPlayer';
import { ShakaPlaybackBridge } from './ShakaPlaybackBridge';
import { ShakaControls } from './ShakaControls';

export interface MountedShakaControls {
  bridge: ShakaPlaybackBridge;
  dispose(): Promise<void>;
}

/** Mount controls without constructing a second Shaka player or video. */
export function mountShakaControls({
  wrapper, video, player, title, episodes,
}: {
  wrapper: HTMLElement;
  video: HTMLVideoElement;
  player: ShakaPlayer;
  title?: string;
  episodes?: Episode[];
}): MountedShakaControls {
  const layer = document.createElement('div');
  layer.id = 'shaka-company-controls';
  layer.className = 'shaka-controls-layer';
  wrapper.appendChild(layer);
  const bridge = new ShakaPlaybackBridge();
  bridge.connect(player, video);
  const root: Root = createRoot(layer);
  const fullscreenTarget = { current: wrapper };
  root.render(
    <ShakaControls bridge={bridge} title={title} episodes={episodes}
      fullscreenTarget={fullscreenTarget} />,
  );
  let disposed = false;
  // Existing IWebPlayer controls state remains the Ease Live contract.
  player.onControlsVisibility((visible) => {
    if (!disposed) layer.hidden = !visible || bridge.isAdActive();
  });
  return {
    bridge,
    async dispose() {
      if (disposed) return;
      disposed = true;
      root.unmount();
      await bridge.destroy(); // The existing ShakaPlayer is NOT destroyed here.
      layer.remove();
    },
  };
}
