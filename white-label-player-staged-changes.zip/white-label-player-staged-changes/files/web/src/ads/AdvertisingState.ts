export interface AdBreakState {
  active: boolean;
  phase: 'loading' | 'playing';
}

/** The overlay observes ad ownership without depending on an SDK-specific controller. */
export interface AdvertisingState {
  readonly isAdPlaying: boolean;
  onChange(listener: (state: AdBreakState) => void): () => void;
}
