import type { EaseLiveConfig } from '../../../packages/shared-sdk/web/easelive';

export const easeLiveConfig: EaseLiveConfig = {
  accountId: 'autotests',
  projectId: '5b07b1ee-62cb-4c06-9fe5-fc98d4b3a1f0',
  programId: 'ease-live-ui-test-1',
  env: 'prod',
};
