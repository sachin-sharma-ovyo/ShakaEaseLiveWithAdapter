# Larger features and architectural extensions

Use when a change crosses subsystems, adds capabilities/configuration, evolves
contracts, or introduces an integration. Adding another player is one example;
the same workflow applies to content-service wiring, richer captions, analytics,
playlist behavior, controls reuse, ad support, or a lifecycle redesign.
Read [architecture](architecture.md) and only the affected subsystem references.

## Define the vertical result

Describe the requested observable behavior and its acceptance cases. Determine
which consumers need it: webpack demo, reusable player entries, public overlay
entry, or an external host. An external host is not present here, so label any
assumptions and use a consumer fixture/check when it is unavailable.

Trace a representative input to its final effect and cleanup before choosing
files. For example, a new settings choice needs configuration/track discovery,
an adapter option and setter, state events, selection UI, loading/unavailable
behavior and teardown. Exposing a button or adding an SDK call alone does not
complete that feature. A content-service feature needs data validation/mapping
and load/error/lifecycle paths; there is no existing fetch layer to silently
assume. Keep requirements driven by the request, not by an exhaustive wishlist.

Use a short impact map for the boundaries actually touched:

| Boundary | Questions that change the implementation |
| --- | --- |
| Entry/configuration | Who supplies data, credentials, content URL, DRM, resume and defaults? Is this demo-only or reusable? |
| Contracts/consumers | Which props, `PlayerConfig`, bridge/settings methods, shared types or exported declarations change? Who reads them? |
| Implementation/state | Which wrapper/adapter owns commands and observed state? How do live, VOD, buffering, error and absent-capability states differ? |
| Presentation/input | Which controls/CSS/caption renderer, accessibility, keyboard, fullscreen and pointer layers are affected? |
| Overlay/ads | Are time units, readiness, command direction, visibility/scaling and content/ad ownership involved? |
| Lifecycle | Who creates/disposes resources? What happens on failed load, close while pending, repeated mount, stale events or teardown failure? |
| Delivery | What entry exports, CSS, declarations, external/bundled dependencies, demo selection and consumer checks are needed? |

Ask for clarification only when an unresolved choice materially changes the
required result (for example, demo proof versus a supported public capability).
Make routine reversible implementation choices from existing context. Record
consequential decisions and unsupported cases where the reviewer/next assistant
can find them; a brief implementation note is often enough.

## Research an unfamiliar or changing library during the task

Do not hardcode a future SDK, dependency set, version or feature recipe from
this skill. Identify the exact version from manifests, lockfiles and installed
metadata. Consult the library's official documentation, API reference, release
notes and type definitions for that version. If only current docs are available,
identify the mismatch and verify the needed APIs against the installed version.
Do not rely on remembered APIs, third-party snippets or another provider's event
names as compatibility evidence.

Map documented capabilities to the repository requirements before depending on
them. A useful decision record has these columns, filled only for relevant needs:

| Required behavior | Documented version/API evidence | Repository owner/mapping | Support or gap | Verification |
| --- | --- | --- | --- | --- |
| A requested capability | Official page/installed declaration | Wrapper, bridge, adapter, host, etc. | Supported, partial, unsupported, or needs a product decision | Types, focused state test, consumer and/or browser case |

Check source formats and query-bearing URLs, DRM systems, absolute/relative
time, live windows, readiness, event order, render surfaces, captions and cleanup
only as the feature requires. State unsupported features explicitly; do not
implement no-op methods that make a capability appear supported. Decide whether
the right outcome is omission, an optional capability, an error/fallback, or a
contract change. Avoid a second source of truth for the same state.

For consequential choices, record the chosen behavior, evidence, tradeoff and
runtime gaps. Do not copy SDK manuals into repository references or label an
unexecuted demo as an integration guarantee. Dependency changes require the
task's authorization and Web-only scope; the native UI synchronization script
is not an acceptable shortcut.

## Examples of extension placement

**A new control or setting:** start in the active React controls and bridge/settings
contract. Reuse a documented UI prop if the vendored version supplies it. Keep
provider-specific SDK mapping in the relevant adapter. When an option changes
midstream, refresh its advertised state and preserve valid selection/Off/Auto
semantics. Verify the effect on playback/captions, not just row highlighting.

**A new host-facing capability:** evolve the smallest appropriate Web interface
and update current implementors/callers/exports together. `IPlaybackBridge` and
`IWebPlayer` serve different consumers. A shared event-map edit also affects a
cross-platform-shaped contract and is not the default route for Web-only SDK
events. The existing Web plugin handles extra SDK events locally.

**Another player integration:** map its documented API to the host bridge and,
if requested, the overlay's `IWebPlayer` surface. Determine which SDK/container
resources it owns and whether it draws its own controls/captions. Existing
Shaka/Bitmovin wrappers illustrate different strategies; neither is a universal
recipe. Keep the shared overlay adapter reusable where semantics match, and
make capability differences explicit where they do not. The current attachment
also requires a usable `getPlayer()` after mount begins. If a public player
subpath is requested, wire its entry, declarations, export/type mappings, CSS
and consumer use; if demo selection is requested, wire that independently.
Ads require their own supported orchestration; they do not follow automatically
from implementing a playback interface.

**Reusable advertising or overlay lifecycle:** current demo wiring and missing
disposal are described in [advertising](advertising.md), [Ease Live](ease-live.md)
and [lifecycle](lifecycle.md). Decide the public ownership/configuration boundary
before moving code. Include restore/failure/cancel paths and make callback/timer
disposal explicit. Do not simply move a demo function and advertise lifecycle
or multi-player support that has not been implemented.

## Implement and close the scope

Implement coherent slices with checks at each affected boundary; do not require
a fixed number of layers or adapters. Preserve backwards compatibility where
practical, or identify deliberate public behavior/type changes. Avoid refactoring
unrelated providers to match a new integration unless the shared contract needs
it. Keep optional features optional and small fixes small.

Use [verification](verification.md) to select focused state/lifecycle tests,
builds, consumer checks and browser cases. Update documentation to match the
source actually retained. If a spike is shelved, remove only its code/wiring and
claims while keeping independently useful, accurate documentation. Describe
unsupported requirements and unverified runtime behavior before calling the
feature complete.
