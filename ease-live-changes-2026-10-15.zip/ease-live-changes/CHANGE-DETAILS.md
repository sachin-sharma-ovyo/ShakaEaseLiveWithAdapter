# All included changes

Snapshot: 15 October 2026. Source base commit: `8a1583460d511ad5182753ff14c0ad2b6660ca91`.

## 1. web/src/config/easeLiveConfig.ts

Replaces the original single autotest config with two typed, plain exports:

| Setting | footballEaseLiveConfig | adsEaseLiveConfig |
| --- | --- | --- |
| accountId | accenture | accenture |
| projectId | 8ea341d6-5140-4c0b-8bc8-cda5418746fe | 21a7191d-5a1e-428c-a68c-2ead3f041c16 |
| programId | a40736be-2342-41ab-8a9c-4c8a59a76a1a | b35b48a8-4d2b-4944-b898-444c9a25994f |
| env | prod | prod |

There is no preset resolver or custom account/project/program URL override machinery. The Ads program ID is stored without the leading slash from the supplied message.

If the destination has other imports of the old `easeLiveConfig` export, update those callers to import a named config or choose one in their entry point. This package updates the current demo callers.

## 2. packages/shared-sdk/web/content/ContentMetadata.ts

Adds optional `startTimecode?: number` to `ContentMetadata`. It represents Unix epoch milliseconds at media position 0. Existing metadata objects remain valid because the new field is optional. The advertising metadata shape is unchanged.

## 3. web/src/config/contentMetadata.ts

Replaces the Mux sample stream with:

```text
https://vz-d1c9ca6b-f40.b-cdn.net/0d6ae227-bc97-4080-ae53-7b8e9a07ba4e/playlist.m3u8
```

Sets `startTimecode: 1784487976165`. Existing advertising cue points are retained: pre-roll, mid-roll at 90 content seconds, and post-roll at content end. The repository README's older sample-offset description is not a source of current cue-point values; inspect this metadata file.

## 4. web/src/plugin/WebPlayerPlugin.ts

Extends the adapter signature compatibly:

```ts
createWebPlayerPlugin(player, ads = null, startTimecode?)
```

When a start timecode is configured, the emitted timecode is:

```ts
Math.floor(startTimecode + player.getCurrentTime() * 1000)
```

The existing timer remains 250 milliseconds (4 updates/second), which is more frequent than the demo's example of one update every 0.5 seconds. It uses playback position rather than elapsed wall-clock time, so pauses, seeking, and buffering follow the media timeline. Existing suppression of time emissions during IMA ads remains in place. Without an explicit epoch, the existing manifest-date and interpolation fallback behavior is preserved.

## 5. web/src/demo/bitmovinDemo.tsx

Adds optional `startTimecode` to `DemoPage` and passes it to `createWebPlayerPlugin(player, null, startTimecode)`. The selected Ease Live config is still supplied by the entry point. Existing license-key requirements and UI behavior are retained.

## 6. web/src/index.ts

- Imports both plain config exports.
- Selects Ads only for `params.get('easelive') === 'ads'`; otherwise selects Football.
- Preserves the explicit `if (params.get('player') === 'shaka')` branch and the Bitmovin branch.
- Keeps the stream and starting-position query parameters.
- Adds a positive, finite `timecode` query override; otherwise uses `contentMetadata.startTimecode`.
- Forwards the selected config and start timecode to both player implementations.
- Moves helper functions outside the Shaka block and aligns indentation; the helpers still live within `main()`.

The current unstaged local edit uses lowercase `easelive`, whereas the earlier staged version used `easeLive`. This package deliberately captures the latest working copy, including that edit. Lowercase URLs in START-HERE.md match the packaged code. No source changes were made merely to build this archive.

Changing URL parameters takes effect on page navigation/reload, not through a hot in-page selector. Missing or unknown `player` values do not initialize Shaka because the requested explicit condition is retained. The `timecode` mapping is shared by both presets, not inferred from the Ease Live program.

## 7. README.md

Documents explicit player selection, the two configs, the optional timecode parameter, and the metadata epoch field. This file is the exact working-copy file; its Ease Live URL examples still use the earlier capital-L spelling. Follow START-HERE.md or update the examples to lowercase `easelive` in the destination.

## Earlier local permission repair

Executable permissions were restored for installed regular-file launchers in `web/node_modules/.bin` to resolve webpack exit code 126. This is an installation repair, not a tracked source change. No dependency files or installed binaries are included; START-HERE.md explains how to handle the same error on the destination.

## Prerequisites and limits

This is a seven-file update for an existing player checkout. It does not add the underlying Ease Live SDK, shared component, wrappers, IMA integration, UI package, or build setup. The source uses `@ease-live/ease-live-bridge-web` 1.22.0 through the existing shared SDK package. If your target repo has a different layout, adapt relative imports and apply the edits manually.

Type checking and production compilation are checked against the source checkout. The archive payload and patch are checked against that source snapshot. These checks do not prove playback or Ease Live overlays in an unseen destination repo, and the packaging task does not start a server. The production build reports bundle-size/performance warnings; see VALIDATION.txt for the result.
