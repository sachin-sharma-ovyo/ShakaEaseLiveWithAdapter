# Bookmark Resume Fix — Patch Manual

This package contains the bookmark-related changes for series playback. It fixes both the hero **Play** button and episode-card **Play** buttons so they fetch the selected episode's saved position from the bookmark API and resume from it.

The patch also supports the live bookmark response shape where the content ID is nested under `bookmarkSet.contentId`, while retaining support for the older direct `contentId` shape.

No white-label player-library change or dependency update is required. The existing player bridge already accepts the `startTime` supplied by the React app.

## Package contents

- `bookmark-resume-fix.patch` — source and regression-test changes.
- `README_APPLY_PATCH.md` — this application manual.
- `MANIFEST.sha256` — checksums for package verification.

## Expected repository baseline

- Repository: `white-label-react`
- Branch when generated: `dev`
- Base commit: `98f18c45d35010e2a1cd1a24f9c8e33d535bc5cc`

The patch can apply to a later branch if the affected files have not changed incompatibly.

## Apply the patch

Assume the ZIP was extracted beside the `white-label-react` directory:

```text
white-label-libraries/
├── white-label-react/
└── bookmark-resume-handoff-2026-11-20/
```

From the parent directory, run:

```bash
cd white-label-react
git status --short
git apply --check ../bookmark-resume-handoff-2026-11-20/bookmark-resume-fix.patch
git apply ../bookmark-resume-handoff-2026-11-20/bookmark-resume-fix.patch
```

Review the applied files:

```bash
git diff --stat
git diff --check
```

If `git apply --check` reports context conflicts because the target branch has moved forward, try Git's three-way merge:

```bash
git apply --3way ../bookmark-resume-handoff-2026-11-20/bookmark-resume-fix.patch
```

Resolve any reported conflicts before testing. Do not run both normal apply and three-way apply after the normal apply has already succeeded.

## Verify the change

No dependency installation is needed if the app is already set up. Run:

```bash
npm run typecheck
CI=true node node_modules/react-scripts/bin/react-scripts.js test \
  --watchAll=false \
  --watchman=false \
  --runInBand \
  --moduleNameMapper='{"^react$":"<rootDir>/node_modules/react"}' \
  --runTestsByPath \
  src/ui/content_page/SeriesPlayback.test.tsx \
  src/repositories/content_page/BookmarkRepository.test.ts \
  src/ui/elements/VideoPlayerOverlay.test.tsx \
  src/ui/elements/useWatchProgress.test.ts
```

Expected result: TypeScript succeeds and all focused tests pass.

For a browser check, sign in and open:

```text
http://localhost:3000/AVS_BASE/PAGE/DETAILS/GROUP_OF_BUNDLES/1700000832/black-paintings
```

1. Start episode 1, watch or seek beyond 30 seconds, pause, and return to the details page.
2. Reload the page so the next position must come from the API.
3. Click the episode-card Play button and confirm playback resumes near the saved position.
4. Repeat the reload and use the hero Play button; it should resume the first episode from the same API bookmark.

## Revert the patch

If the applied changes have not been edited further, run:

```bash
git apply --reverse ../bookmark-resume-handoff-2026-11-20/bookmark-resume-fix.patch
```

## Changed files

- `src/repositories/content_page/BookmarkRepository.ts`
- `src/repositories/content_page/BookmarkRepository.test.ts`
- `src/ui/content_page/SeriesPlayback.tsx`
- `src/ui/content_page/SeriesPlayback.test.tsx`
- `src/ui/elements/watchCompletion.ts`
