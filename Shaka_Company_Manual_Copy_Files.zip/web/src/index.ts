/** Main entry: Shaka with company React controls; Bitmovin demo stays intact. */
import {
  applyBrandTheme,
  loadBrandConfig,
  type AdsConfig,
  type BrandConfig,
} from '../../packages/shared-sdk/web/brand';
import { EaseLiveComponent } from '../../packages/shared-sdk/web/easeLive';
import { AdController } from './ads/AdController';
import '@white-label/ui-react/tokens.css';
import '@white-label/ui-react/styles.css';
import './app.css';
import { createWebPlayerPlugin } from './plugin/WebPlayerPlugin';
import { ShakaPlayer } from './shaka/ShakaPlayer';
import { ShakaPlaybackBridge } from './shaka/ShakaPlaybackBridge';
import { mountShakaControls } from './shaka/mountShakaControls';
import {
  errorMessage,
  readPlayerMarkup,
  waitForStartGesture,
} from './utils';

async function main(): Promise<void> {
  const { wrapper, video, status, view, adContainer } = readPlayerMarkup();
  let brand: BrandConfig;
  try {
    brand = await loadBrandConfig();
  } catch (error) {
    status.textContent = errorMessage(error, 'Failed to load brand config.');
    return;
  }
  applyBrandTheme(brand.theme);

  // Preserve the existing ?stream= and ?start= overrides.
  const params = new URLSearchParams(window.location.search);
  const streamUrl = params.get('stream') || brand.streamUrl;
  const startParam = Number(params.get('start'));
  const startTime = startParam > 0 ? startParam : undefined;

  // Keep the real Bitmovin example untouched and on demand.
  if (params.get('player') === 'bitmovin') {
    const { runBitmovinDemo } = await import('./demo/bitmovinDemo');
    await runBitmovinDemo({
      wrapper, video, status, view, brand, streamUrl, startTime,
    });
    return;
  }

  // IMPORTANT: exactly one ShakaPlayer owns the original page video element.
  const player = new ShakaPlayer(video);
  player.onError((message) => { status.textContent = message; });
  const companyUi = mountShakaControls({
    wrapper, video, player, title: brand.theme.name,
  });
  // Cleanup UI subscriptions on page exit; leave existing player lifecycle intact.
  window.addEventListener('pagehide', () => { void companyUi.dispose(); }, { once: true });

  const ads = wireAds(player, view, brand.ads, companyUi.bridge);
  const easeLive = new EaseLiveComponent(
    view,
    createWebPlayerPlugin(player, ads),
    brand.easeLive,
    {
      onStatus(next: string) { status.textContent = `Overlay ${next}`; },
      onFatal(message: string) { status.textContent = message; },
    },
  );

  if (!ads) {
    await loadStream(player, easeLive, streamUrl, startTime, status);
    return;
  }

  status.textContent = 'Click the video to start';
  // IMA must be initialized in the user gesture before pre-roll/content load.
  const imaReady = await waitForStartGesture(
    wrapper,
    () => ads.tryInit(adContainer, video),
  );
  if (imaReady && brand.ads?.preRoll) {
    status.textContent = 'Advertisement';
    await ads.playBreak(brand.ads.preRoll.tagUrl, { kind: 'pre' });
  }
  if (imaReady) ads.bindContent(video);
  status.textContent = 'Loading stream...';
  await loadStream(player, easeLive, streamUrl, startTime, status, true);
}

/** Existing AdController remains authoritative for scheduling and IMA. */
function wireAds(
  player: ShakaPlayer,
  view: HTMLElement,
  adsConfig: AdsConfig | undefined,
  bridge: ShakaPlaybackBridge,
): AdController | null {
  if (!adsConfig?.enabled) return null;
  const ads = new AdController(player.getInstance(), adsConfig);
  const markers = {
    hasPreRoll: Boolean(adsConfig.preRoll),
    midRollOffsetsSec: adsConfig.midRoll?.offsetsSec ?? [],
    hasPostRoll: Boolean(adsConfig.postRoll),
  };
  player.setAdBreakMarkers(markers); // Retain current code behavior.
  bridge.setAdBreakMarkers(markers); // NEW: markers for company UI slider.
  ads.onChange((state) => {
    player.setTransportLocked(state.active);
    bridge.setAdActive(state.active);
    document.getElementById('shaka-company-controls')
      ?.toggleAttribute('hidden', state.active);
    view.classList.toggle('ad-break', state.active);
  });
  ads.onWatched((position) => {
    player.markAdBreakWatched(position);
    bridge.markAdBreakWatched(position);
  });
  return ads;
}

/** Start player load first, then Ease Live so it can wait on that same load. */
async function loadStream(
  player: ShakaPlayer,
  easeLive: EaseLiveComponent,
  streamUrl: string,
  startTime: number | undefined,
  status: HTMLElement,
  autoplay = false,
): Promise<void> {
  const loadPromise = player.load(streamUrl, undefined, startTime);
  easeLive.init();
  try {
    await loadPromise;
    status.textContent = 'Player ready';
    if (autoplay) await player.play();
  } catch (error) {
    status.textContent = errorMessage(error, 'Failed to load the stream.');
  }
}

void main();
