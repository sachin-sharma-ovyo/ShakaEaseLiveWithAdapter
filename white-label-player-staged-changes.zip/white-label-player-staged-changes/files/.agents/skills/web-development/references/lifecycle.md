# Lifecycle, ownership and asynchronous races

Read for changes involving mount/load, route transitions, reuse, resources or
cleanup. These are current ownership facts and gaps, followed by recommended
design checks for affected work. A local UI task does not require repairing all
pre-existing lifecycle issues.

## Resource inventory

| Owner / source | Creates or borrows | Existing cleanup |
| --- | --- | --- |
| [ShakaPlayer](../../../../web/src/shaka/ShakaPlayer.ts) | Borrows HTML video; owns Shaka player/UI overlay, global transport key listener, media/SDK callbacks and wrapper listener sets | Removes global key listener, notifies/clears destroy callbacks, clears controls callbacks, calls UI destroy (which destroys Shaka). Anonymous media listeners and state/error sets are not explicitly cleared. |
| [ShakaPlaybackBridge](../../../../web/src/shaka/ShakaPlaybackBridge.ts) | `connect` borrows player/video; `mount` creates/owns a wrapper/video/player; owns settings and media listener disposers | `disconnect` removes recorded media listeners and settings, clears connection/ad state. `destroy` clears host callback sets and destroys/removes only its owned player/wrapper. Marker schedule persists on the instance. |
| [mountShakaControls](../../../../web/src/shaka/mountShakaControls.tsx) | Owns controls DOM layer, React root, borrowed-player bridge; borrows wrapper/video/player | Idempotent `dispose`: unmount React, destroy bridge, remove layer. Visibility callback remains registered on player but is guarded by a disposed flag. Does not destroy playback. |
| [BitmovinPlaybackBridge](../../../../web/src/bitmovin/BitmovinPlaybackBridge.ts) | Owns a fresh inner wrapper, Bitmovin wrapper/SDK, settings and caption renderer | Clears host callback sets before SDK destroy, detaches settings/captions, nulls fields, awaits player destroy, removes captured wrapper. Its inline SDK callbacks rely on SDK destruction rather than explicit `off`. |
| [BitmovinPlayer](../../../../web/src/bitmovin/BitmovinPlayer.ts) | Owns SDK instance and wrapper callback sets | Invokes destroy hooks, clears callback sets, calls SDK destroy. |
| [ShakaSettings](../../../../web/src/shaka/ShakaSettings.ts), [BitmovinSettings](../../../../web/src/bitmovin/BitmovinSettings.ts) | Borrow playback resources; own settings listeners and SDK/media callbacks | Detach clears subscribers and removes registered callbacks. Shaka attach calls detach first; Bitmovin attach assumes correct ownership/order. |
| [BitmovinSubtitles](../../../../web/src/bitmovin/BitmovinSubtitles.ts) | Borrows SDK-created video; creates browser text track/cues | Removes SDK callbacks, empties/disables track, drops references. Text-track objects cannot be removed from video. |
| React controls | Borrow bridge; own subscriptions, local UI state, fullscreen-entry flag; Shaka markers own resize listener/observer | Effects unsubscribe, marker observer disconnects, fullscreen exit attempted if entered by component. No player destruction. |
| [EaseLiveComponent](../../../../packages/shared-sdk/web/easelive/EaseLiveComponent.ts) | Owns overlay SDK instance | Clears its instance field and destroys captured SDK instance. It does not destroy playback. |
| [WebPlayerPlugin](../../../../web/src/plugin/WebPlayerPlugin.ts) | Borrows player/controller/overlay; creates event callbacks and post-ready interval | Interval cleared on player destroy only. Callback registration results are not disposed; no complete plugin-disposal API. |
| [attachEaseLive](../../../../web/src/easelive/index.ts) | Owns component and attachment callback set, borrows player | Clears its own callback set and destroys component; wrapper visibility callback stays registered. |
| [AdController](../../../../web/src/ads/AdController.ts) | Borrows Shaka manager/content media, requests IMA managers; owns queue, timer and ad callback sets | `destroy` invalidates queued work, removes SDK/media listeners, clears callbacks/timer, resolves pending break and stops retained IMA manager. Rebinding removes old media listeners. |
| [ContentPlaybackSession](../../../../web/src/player/ContentPlaybackSession.ts) | Borrows bridge and optional ad lifecycle; owns pending startup gesture and loaded/restart/disposed state | `dispose` cancels the gesture and destroys ads; asynchronous startup/restart continuations check whether the session is still active. |
| [runDemo](../../../../web/src/demo/runDemo.ts), [demo adapters](../../../../web/src/demo/DemoPlayer.ts) | Common page owns session, ended subscription and overlay; adapters own SDK/controls/host DOM | Cached `pagehide` preserves the session; a non-cached exit removes the page listener, disposes session/subscription, destroys overlay, then destroys adapter even if overlay teardown rejects. |

## Demo ownership and cached history navigation

Both players run through `demo/runDemo.ts`. The common page cancels pending
startup and disposes its ad lifecycle/ended subscription on a non-cached exit,
then destroys the overlay and adapter. Shaka's adapter disposes its borrowed-player
controls before destroying the wrapper; Bitmovin's adapter unmounts its React
root, destroys its bridge and removes its host/controls DOM.

`pagehide` with `persisted=true` preserves these resources because Back/Forward
restores the same document without rerunning startup. The listener remains
registered across repeated cached exits, and is removed on the first non-cached
exit. Do not use `once: true` with a persisted-event early return: that would
silently lose final cleanup after restoring a cached page.

`createStartGesture` provides explicit `start` and `cancel` with listener cleanup;
`waitForStartGesture` is its promise-only convenience wrapper. `onPlaybackTime`
still has no disposer, but `AdController` now owns removable media listeners
directly. These page-level helpers are not a complete reusable route/StrictMode
lifecycle; the lower-level SDK/plugin limits below still apply.

## Races to investigate when affected

- **Destroy during load:** both bridge mount methods await loading without a
  cancellation/generation check afterwards. Bitmovin publishes a snapshot after
  await. A stale completion can touch newer instance state on reuse. The overlay
  plugin can emit ready/start a timer after its player was already destroyed.
- **Concurrent teardown and next mount:** Bitmovin creates a fresh wrapper per
  mount so an old SDK teardown cannot directly mutate the next SDK's container.
  This isolation helps but does not prove callback/promise cancellation. Prefer
  a fresh bridge per playback session unless reuse has been verified.
- **Load failure/creation failure:** constructors remove some created DOM on
  immediate failure, but rejected async load does not automatically dispose the
  bridge, controls or overlay. Host failure paths still need cleanup.
- **Subscriptions before mount/reconnect:** Shaka `connect` calls `disconnect`;
  settings detach clears listeners, so a pre-connect settings subscription can
  be lost. Bridge host callback sets persist through disconnect but are cleared
  on destroy. Settings need resubscription after detach/reconnect.
- **Overlay-only teardown:** the timer and player callbacks can outlive an SDK
  overlay and can retain the old SDK. Re-attaching can duplicate notifications.
- **Ads finishing late:** controller disposal invalidates queued jobs and clears
  listeners/timers, but generation is not an SDK event correlation ID and a
  started ad has no completion watchdog. See [advertising](advertising.md) for
  remaining stale-event and restoration-ordering limits.
- **Destroy rejection:** bridge wrapper removal follows an awaited SDK destroy
  rather than `finally`; rejection can leave DOM. Repeated calls may appear to
  resolve while an earlier destruction is still in flight because fields were
  already cleared. Do not claim a shared teardown promise is implemented.
- **Fullscreen resolution:** promise completion can set the entry flag after
  unmount, beyond the cleanup check. External fullscreen changes are not tracked.

## Design approach for affected changes (proposed)

For each resource, decide who creates it, who may borrow it, and the exact event
or operation that disposes it. Give new subscriptions a disposer at the boundary
that creates them. Remove listeners with the same function and capture options;
clear timers/observers and drop callbacks before SDK teardown can emit events.

For asynchronous work, capture session resources rather than reading mutable
fields after await; use cancellation or generation checks to prevent a stale
session publishing state, appending DOM or starting new work. Consider pending
ready/load, queued ads and fullscreen promises, not only successful unmount.
If destroy needs idempotent concurrent semantics, retain/return its in-flight
promise and ensure cleanup also runs on rejection. These are design options to
choose for the task, not a required repository-wide refactor.

A host normally unsubscribes/unmounts controls, disposes overlay/plugin work,
stops/disposes any ad orchestration it owns, destroys playback and removes its
shell. Exact ordering must respect which resource is borrowed and which SDK can
still emit events. The remaining wrapper/plugin disposal gaps require explicit
work when the task depends on those guarantees. Prove no callbacks/DOM/timers survive
using focused cases in [verification](verification.md).
