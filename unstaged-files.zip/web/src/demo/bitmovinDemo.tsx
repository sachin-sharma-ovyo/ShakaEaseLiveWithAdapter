/**
 * Demo page, Bitmovin mode (`?player=bitmovin`). Loaded on demand by `index.ts`.
 *
 * Same startup order as the Shaka demo: start the stream load, then create Ease Live so the
 * adapter can wait on that load. The controls are the library's `BitmovinControls`, rendered with
 * React on top of the video and overlay (video 0, overlay 2, controls 3).
 */
import '@white-label/ui-react/tokens.css';
import '@white-label/ui-react/styles.css';
import '../bitmovin/BitmovinControls.css';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { EaseLiveComponent, type EaseLiveConfig } from '../../../packages/shared-sdk/web/easelive';
import { BitmovinControls, type BitmovinControlsProps } from '../bitmovin/BitmovinControls';
import { BitmovinPlaybackBridge } from '../bitmovin/BitmovinPlaybackBridge';
import { createWebPlayerPlugin } from '../plugin/WebPlayerPlugin';

export interface DemoPage extends Pick<BitmovinControlsProps,
  'seriesTitle' | 'genres' | 'seasonNumber' | 'episodeNumber'> {
  wrapper: HTMLElement;
  video: HTMLVideoElement;
  status: HTMLElement;
  view: HTMLElement;
  title: string;
  easeLiveConfig: EaseLiveConfig;
  streamUrl: string;
  startTime?: number;
}

export async function runBitmovinDemo({
  wrapper,
  video,
  status,
  view,
  title,
  seriesTitle,
  genres,
  seasonNumber,
  episodeNumber,
  easeLiveConfig,
  streamUrl,
  startTime,
}: DemoPage): Promise<void> {
 const licenseKey = "04c16f7d-156e-4e95-8cc6-729de4121ed8" ;
  if (!licenseKey) {
    status.textContent = 'Set BITMOVIN_KEY in web/.env (see web/.env.example), then restart npm start.';
    return;
  }

  // Bitmovin creates its own <video>.
  video.remove();
  const host = document.createElement('div');
  host.id = 'bitmovin-host';
  wrapper.prepend(host);

  const controlsLayer = document.createElement('div');
  controlsLayer.id = 'bitmovin-controls';
  controlsLayer.dataset.theme = 'dark';
  controlsLayer.dataset.device = 'desktop';
  wrapper.appendChild(controlsLayer);

  const bridge = new BitmovinPlaybackBridge({ licenseKey });
  const loadPromise = bridge.mount(host, streamUrl, undefined, startTime);
  bridge.onEnded(() => {
    status.textContent = 'Playback ended';
  });
  const player = bridge.getPlayer();
  if (!player) {
    await loadPromise.catch((error: unknown) => {
      status.textContent = error instanceof Error ? error.message : 'Failed to create the player.';
    });
    return;
  }

  player.onError((message) => {
    status.textContent = message;
  });
  // Ease Live stage clicks toggle the controls through the adapter.
  player.onControlsVisibility((visible) => {
    controlsLayer.hidden = !visible;
  });

  createRoot(controlsLayer).render(
    <BitmovinControls bridge={bridge} title={title} fullscreenTarget={{ current: wrapper }}
      onBack={() => window.history.back()}
      seriesTitle={seriesTitle}
      genres={genres}
      seasonNumber={seasonNumber}
      episodeNumber={episodeNumber}
    />,
  );

  const startTimecode = easeLiveConfig.startTimeCode ?? Date.now();

  const easeLive = new EaseLiveComponent(
    view,
    createWebPlayerPlugin(player, null, startTimecode),
    easeLiveConfig,
    {
      onStatus(next) {
        status.textContent = `Overlay ${next}`;
      },
      onFatal(message) {
        status.textContent = message;
      },
    },
  );

  easeLive.init();

  try {
    await loadPromise;
    status.textContent = 'Player ready';
  } catch (error) {
    status.textContent = error instanceof Error ? error.message : 'Failed to load the stream.';
  }
}
