# Transfer the final folder-5 formatting files

Use this archive in place of the earlier `pr-formatting-folder5.zip`.
The chosen reference is the working-tree code in `Downloads/white-label-player 5`.
The goal is to match that folder, as requested; a PR target branch may use different
formatting and can therefore still show whitespace differences against this reference.

## Complete files included

Each file contains its entire current contents. Copy to the same relative target path:

- `web/src/index.ts`
- `web/src/bitmovin/BitmovinControls.tsx`
- `web/src/demo/bitmovinDemo.tsx`
- `web/src/shaka/ShakaControls.tsx`
- `web/src/app.css`

## What matches folder 5

- index.ts is byte-for-byte identical to folder 5, including optional punctuation and
  the reference's end-of-file layout.
- BitmovinControls.tsx follows the complete reference layout, including metadata
  destructuring/prop ordering, ternaries, empty callback spacing and comments.
  Only the current device type, default and passed value are retained from folder 3.
- bitmovinDemo.tsx follows the reference layout. Its existing license assignment is
  retained; the stray space before its semicolon is absent.
- ShakaControls.tsx matches folder 5 with the requested comma-to-semicolon correction
  on the onBack interface member.
- app.css matches folder 5 with the requested final newline added.

The reference was read only. Existing device/license configuration, metadata values,
30-second seek steps, callbacks and CSS behavior remain intact. Bookmarks remain removed.
No code was staged, committed or pushed by this task.

## Copy the complete files into the other repository

1. Extract this ZIP into a separate temporary folder.
2. In the target repository, inspect `git status --short` and back up any local work in
   the five files before replacing them.
3. Open each extracted file beside the same relative path in the target repository.
   These files are the current feature version from folder 3, with folder-5 formatting.
4. If the target has the same functional feature version, replace the matching file or
   copy its entire contents into the target file. Copy all five paths individually.
5. If the target has different logic or configuration, use your editor's compare view
   and transfer formatting only. Preserve target license configuration, device selection,
   callbacks, metadata fields and CSS declarations rather than overwriting them.
6. Retain the target's matching metadata types, demo metadata and Shaka mount helper;
   those feature dependencies are outside this formatting archive.
7. Compare the transferred index.ts directly to your folder-5 reference. It should match
   exactly. For Bitmovin, the only differences against folder 5 should be the existing
   three device configuration/type lines, if you use these complete files unchanged.

Do not apply an automatic formatter after copying: it could undo the requested reference
indentation, line wrapping and empty callback spacing.

## Optional patch transfer

`formatting-only.patch` is the cumulative diff from this checkout's existing staged PR
version to the final formatted files. It includes layout, comments, metadata ordering
and punctuation changes, with the current functional values preserved.

From the target repository root, replacing the extracted path:

```sh
git apply --check /path/to/extracted/formatting-only.patch
git apply /path/to/extracted/formatting-only.patch
```

Run the second command only if the first succeeds. If the target revision or line
endings differ, use the complete-file comparison method instead of forcing the patch.

## Verify in the target repository

```sh
git diff --check
git diff -- web/src/index.ts web/src/bitmovin/BitmovinControls.tsx web/src/demo/bitmovinDemo.tsx web/src/shaka/ShakaControls.tsx web/src/app.css
npm run typecheck
npm run build
npm run build:demo
```

Check that no functional settings, callbacks, calculations or CSS declarations changed.
Whitespace-ignoring diffs can still display line wrapping, comments, metadata ordering
and optional punctuation; review these separately from functional expressions.

Inside the extracted folder, verify source integrity:

```sh
shasum -a 256 -c SHA256SUMS.txt
```

## Checks completed

- Exact reference-file comparison, with the documented functional and PR-fix exceptions.
- TypeScript expressions/types compared before and after, accounting for independent
  metadata binding and JSX-prop ordering.
- Ten before/after React metadata renders produced identical HTML.
- CSS declarations and selector semantics unchanged.
- Typecheck, library build and demo build passed.
- Demo build retains three webpack size/performance warnings.
- Existing staged changes preserved.

Real playback, ads, DRM, Ease Live programs and physical devices were not rerun for
this formatting-only task. See REFERENCE-MATCH.json and VERIFICATION.json for details.
