import type { ContentMetadata } from '../../../packages/shared-sdk/web/content/ContentMetadata';

/** Demo response. Replace this object with content-service metadata when available. */
export const contentMetadata: ContentMetadata = {
  streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
  advertisingInfoList: [
    {
      advertisingContentId: '1',
      networkID: '1',
      cuePointList: [
        {
          customSlotId: 'intro',
          sequence: 1,
          timePositionClass: 'PREROLL',
          contentEndTimePosition: 0,
          adFormat: 'EMBEDDED',
          timeToNextAdUnit: 0,
          contentTimePosition: 0,
        },
        {
          customSlotId: 'mid-roll-1',
          sequence: 0,
          timePositionClass: 'MIDROLL',
          contentEndTimePosition: 0,
          adFormat: 'CLEAN',
          timeToNextAdUnit: 0,
          contentTimePosition: 3600,
        },
        {
          customSlotId: 'end_credits',
          sequence: 0,
          timePositionClass: 'POSTROLL',
          contentEndTimePosition: 4,
          adFormat: 'CLEAN',
          timeToNextAdUnit: 0,
          contentTimePosition: 7200,
        },
      ],
    },
  ],
};
